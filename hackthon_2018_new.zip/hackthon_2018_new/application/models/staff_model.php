<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class staff_model extends CI_Model
{
    private $table_name			= 'users';
    public function __construct()
	{
	    $this->load->database(); //LOADS THE DATABASE AND CREATES DATABASE OBJECT
       	$ci =& get_instance();
		$this->table_name	= $ci->config->item('db_table_prefix', 'tank_auth').$this->table_name;
	}
    
    
   /**
	 * Create new user record
	 *
	 * @param	array
	 * @param	bool
	 * @return	array
	 */
	function create_staff($data, $activated = TRUE)
	{
	 
		$data['created'] = date('Y-m-d H:i:s');
		$data['activated'] = $activated ? 1 : 0;
      	if ($this->db->insert($this->table_name, $data)) {
			$user_id = $this->db->insert_id();
			
			return array('user_id' => $user_id);
		}
		return NULL;
	}
    
    
    
    /**
       * View staff 
       * @param user id
       * @return user details
       * */ 
    public function view_staff($user_id)    
    {
        $data=array('users.id'=>$user_id);
        $this->db->select('users.*' );
        $this->db->select('locations.location_name,locations.location_id');
        $this->db->select('designation.designation_name,designation.designation_id');
        $this->db->select('auth_level.auth_level_name,auth_level.auth_level_name');
        $this->db->from('users');
        $this->db->join('locations', 'users.location_id = locations.location_id','LEFT');
        $this->db->join('designation', 'users.designation = designation.designation_id','LEFT');
        $this->db->join('auth_level', 'users.auth_level = auth_level.auth_level_id','LEFT');
        $this->db->where($data);
        $query = $this->db->get();
        
        if ($query->num_rows() == 1) 
        return $query->result_array();
	           return NULL;
    	
    }
     /**
	 * Update users basic information
	 *
	 * @param	string
	 * @param	string
     * @param	string
	 * @return	bool
	 */      
    public function update_staff_profile($user_id)
    {

        									
        $data = array(
           'first_name' => $this->input->post('first_name') ,
           'last_name' =>$this->input->post('last_name'),
           'username' =>$this->input->post('username'),
           'location_id' =>$this->input->post('location'),
           'designation' =>$this->input->post('designation'),
           'auth_level' =>$this->input->post('auth_level'),
           'role' =>$this->input->post('role')
          );
       
        $this->db->where('users.id', $user_id);
        if($this->db->update('users', $data))
        {
            return true; //returning true if query runs correctly
        } 
        else
        {
            return false; // return false if something goes wrong

        }

    }
    /**
	 * Check if username available for registering
	 *
	 * @param	string
	 * @return	bool
	 */
	function is_username_available($username,$uid)
	{
		$this->db->select('1', FALSE);
        $this->db->where('id !=',$uid);
		$this->db->where('LOWER(username)=', strtolower($username));
        $this->db->where('is_deleted', "0");
		$query = $this->db->get($this->table_name);
		return $query->num_rows() == 0;
	}
    
    
      /**
       * Disable staff 
       * @param user id
       * @return void
       * */ 
    public function disable_staff($staff_id)
    {
        $data["banned"] = "1";
        $this->db->where('id',$staff_id);
        if($this->db->update('users',$data))
        return true;
        return false;
    }
    
      /**
       * Enable staff 
       * @param user id
       * @return void
       * */ 
    public function enable_staff($staff_id)
    {
        $data["banned"] = "0";
        $this->db->where('id',$staff_id);
        if($this->db->update('users',$data))
        return true;
        return false;
    }
    
    
    
    
      /**
       * Delete user 
       * @param user id
       * @return void
       * */ 
    public function delete_staff($staff_id,$admin_id)
    {
        $data["is_deleted"] = "1";
        $data["deleted_by"] = $admin_id;
        $this->db->where('id',$staff_id);
        if($this->db->update('users',$data))
        return true;
        return false;
    }
    
    
      /**
       * Reset staff account to temp pass
       * @param $staff_id
       * @return bool
       * */ 
    public function reset_account($staff_id,$tpassword)
    {
        $data["is_password_created"] = "0";
        $data["temp_password"] = $tpassword;
        $this->db->where('id',$staff_id);
        if($this->db->update('users',$data))
        return true;
        return false;
    }
    /**
       * Get all designation 
       * @param 
       * @return bool
       * */ 
      public function get_designation()        
    {
        $query=$this->db->get('designation');
        if($query->num_rows()>0)
		return $query->result_array();
		return false;
    }
   /**
       * Get all authority level
       * @param 
       * @return bool
       * */ 
      public function get_auth_level()        
    {
        $query=$this->db->get('auth_level');
        if($query->num_rows()>0)
		return $query->result_array();
		return false;
    }
    
 
   
}

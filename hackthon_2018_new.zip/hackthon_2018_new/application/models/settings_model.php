<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Settings
 *
 * This model represents user Setting and profile data. It operates the following tables:
 * - users ,
 * - user profiles
 *
 */
class Settings_model extends CI_Model
{
	private $table_name		= 'users';			// user accounts
	

	function __construct()
	{
		parent::__construct();
                $ci =& get_instance();
		
	}

	/**
	 * Get user record by Id
	 *
	 * @param	int
	 * @param	bool
	 * @return	object
	 */
	function get_user_by_id($user_id)
	{
            
            $this->db->select('*');
            $this->db->from($this->table_name);
            //$this->db->join('user_profiles','users.id = user_profiles.user_id');
            $this->db->where('id', $user_id);
            $query = $this->db->get();
			if ($query->num_rows() == 1) return $query->row();
			return NULL;
           
	}
        
     /**
	 * Update users basic information
	 *
	 * @param	string
	 * @param	string
     * @param	string
	 * @return	bool
	 */      
    public function update_user_profile($user_id,$first_name,$last_name)
    {

        									
        $data = array(
           'first_name' => $first_name ,
           'last_name' => $last_name 
          
          );
       
        $this->db->where('id', $user_id);
        if($this->db->update('users', $data))
        {
            return true; //returning true if query runs correctly
        } 
        else
        {
            return false; // return false if something goes wrong

        }

    }
    
    public function get_print_settings()
    {
        $this->db->where('print_setting_id', 1);
        $query = $this->db->get('print_settings');
		if ($query->num_rows() == 1) return $query->row();
		return NULL;
    }
        
   public function update_print_settings()
   {

        $data = array(
           'top_margin' => $this->input->post('top_margin') ,
           'left_margin' => $this->input->post('left_margin')  
        );
       
        $this->db->where('print_setting_id', 1);
        if($this->db->update('print_settings', $data))
        return true; //returning true if query runs correctly
        else
        return false; // return false if something goes wrong
   }     
       
   public function update_quarter_settings()
   {

        $data = array(
           'first_quarter_starting_month' => $this->input->post('firstQuarterStartingMonth') ,
           'second_quarter_starting_month' => $this->input->post('SecondQuarterStartingMonth') ,
           'third_quarter_starting_month' => $this->input->post('ThirdQuarterStartingMonth') ,
           'forth_quarter_starting_month' => $this->input->post('forthQuarterStartingMonth') 
                
        );
       
        $this->db->where('print_setting_id', 1);
        if($this->db->update('print_settings', $data))
        return true; //returning true if query runs correctly
        else
        return false; // return false if something goes wrong
   }   
   

}
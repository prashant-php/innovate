<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class membership extends CI_controller {

    function __construct() {
        parent::__construct();

        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('security');
        $this->load->library('tank_auth');
        $this->load->library('datatables');
        $this->load->language('tank_auth');
        $this->load->model('membership_model');
        //$this->load->library('ciqrcode');   
    }
    
    /*
     * this function will load Membership Signup form
     * param void
     * retrun void
     */
    public function index()
    {
        $data["admin_data"] = $this->verify_for_direct_request();
        $data["title"] = "Customer Signup";
        $this->load->view('includes/admin_header', $data);
        $this->load->view('membership/customer_profile', $data);
        $this->load->view('includes/admin_footer', $data);
    }
    
    /*
     * 
     * for add customer
     * param void
     * return array
     */
    
    public function add_customer()
    {
       $data["admin_data"] = $this->verify_for_ajax_request();

        $this->form_validation->set_rules('f_name', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('l_name', 'Last Name', 'trim|required|xss_clean'); 
        
        $this->form_validation->set_rules('membership_num', 'Parkson Card Number', 'trim|required|max_length[16]|xss_clean|numeric|min_length[16]|callback_check_pnc[\'membership_num\']|callback_validate_parkson_card_num["membership_num"]|callback_is_pcn_duplicate["membership_num"]');
        $this->form_validation->set_rules('Bonuslink_num', 'Bonuslink Number', 'trim|max_length[16]|xss_clean|numeric|min_length[16]|callback_check_bl["Bonuslink_num"]|callback_validate_bonus_link_num["Bonuslink_num"]|callback_is_bl_duplicate["Bonuslink_num"]');
        
        if(!$this->input->post('passport_num') || $this->input->post('nationality')=='Malaysian' || $this->input->post('nationality')=='malaysian' ){
        $this->form_validation->set_rules('nric_num_1', 'NRIC Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('nric_num_2', 'NRIC Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('nric_num_3', 'NRIC Number', 'trim|required|xss_clean|callback_is_nric_duplicate');
        }
        
        if((!$this->input->post('nric_num_1') && !$this->input->post('nric_num_2') && !$this->input->post('nric_num_3') ) || ( strtolower($this->input->post('nationality'))!='malaysian' ) )
        {
            $this->form_validation->set_rules('passport_num', 'Passport Number', 'trim|required|xss_clean|callback_is_passport_duplicate["passport_num"]');
        }
         
        $this->form_validation->set_rules('nationality', 'Nationality', 'trim|required|xss_clean');
        $this->form_validation->set_rules('address_1', 'Address', 'trim|required|xss_clean');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required|xss_clean');
       
        //Email & mobile validation removed as per requested by parkson on 10 FEB (asana)
        //if(!filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL)){   
        //$this->form_validation->set_rules('mobile_num_1', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //$this->form_validation->set_rules('mobile_num_2', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //}
          
        //if(!$this->input->post('mobile_num_1') && !$this->input->post('mobile_num_2'))
        //$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required|xss_clean');
        
        $this->form_validation->set_rules('mobile_num_1', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('mobile_num_2', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean');
        
        $this->form_validation->set_rules('race', 'Race', 'trim|required|xss_clean');
       
        if($this->input->post('race')=='Other')
        $this->form_validation->set_rules('custome_race', 'Other Race', 'trim|required|xss_clean');
        
        

        if ($this->form_validation->run())
		{ 
             //validate duplicates
            $is_duplicates = $this->check_uniqueness(0);
            if($is_duplicates !== true)
            {
                $result["status"] = 0;
                $result["message"] = $is_duplicates; 
                echo json_encode($result);
                die();  
            } 
                        
			//code for success
                        if($this->membership_model->add_customer()){
                   
                                 $result["status"] = 1;
                                  $result["message"] = $this->lang->line('add_customer');
                              } else {
                                  $result["status"] = 0;
                                  $result["message"] = $this->lang->line('add_customer_err');
                              }
                              echo json_encode($result);
                              die();  
                       
		}
		else
		{
                   
             $data = validation_errors();
             $result["status"] = 0;
             $result["message"] = $data;
             echo json_encode($result);
             die();
		}
    }
   function generate_password(){
      
    if(isset($_POST['dob'])&& !empty($_POST['dob']))
    $dob = date('Y',strtotime($_POST['dob']));
      
      
    $questions_answer_mapping = array(
        $_POST['security-question-1'] => $_POST['answer_1'],
        $_POST['security-question-2'] => $_POST['answer_2'],
        $_POST['security-question-3'] => $_POST['answer_3'],
    );
    $security_answers = array(1, 2, 3, 4, 5);
	$r = 3;
	$n = count($security_answers);
	$possible_combinations = $this->printCombination($security_answers,$n, $r);
   // echo "<pre>";
//    print_r($_POST);
//    die;
    $security_questions = array($_POST['security-question-1'],$_POST['security-question-2'],$_POST['security-question-3']);
    sort($security_questions);
    $security_questions = implode($security_questions);
    //echo $security_questions;die;
    if(('123' == $security_questions)&& ($_POST['project_on_working'] == "Technology")){
        $password_sentence = $questions_answer_mapping[2] . " is a ". $_POST['project_on_working']. " addict since " . $dob;
        //$data = validation_errors();
             $result["status"] = 1;
             $result["message"] = $password_sentence;
             echo json_encode($result);
             die();
    }
    
   }
   function printCombination($arr =[],$n, $r){
       $data = array();
       $this->combinationUtil($arr, $data, 0, $n-1, 0, $r);
   }
   function combinationUtil($arr, $data,$start,$end,$index,$r){
       if($index == $r){       
	   //print_r($data);
	   return;
       }
       for($i=$start;(($i<=$end) && ($end-$i+1 >= $r-$index));$i++){
	   $data[$index] = $arr[$i];
	   $this->combinationUtil($arr,$data,$i+1,$end,$index+1,$r);
       }
   }
   function check_uniqueness($customer_id)
    {
        $nric = trim($_POST["nric_num_1"]).trim($_POST["nric_num_2"]).trim($_POST["nric_num_3"]);
        $res = $this->membership_model->search_unique_server_side($nric,$_POST["Bonuslink_num"],$_POST["passport_num"],$_POST["membership_num"],$customer_id);
        if($res=='OK') return true;
        else
        return $res;  
    }
    
    function check_pnc($original)
    {
        if($original[0]!="0" || $original[1]!="2" || $original[2]!="0" || $original[3]!="1" )
        {
            $this->form_validation->set_message('check_pnc','Parkson Card Number should start with 0201');
            return false;
        }
        return true;
    }
    
    function check_bl($original)
    {
        if(strlen(trim($original))==16){
        if($original[0]!="6" || $original[1]!="0" || $original[2]!="1" || $original[3]!="8" )
        {
            $this->form_validation->set_message('check_bl','Bonuslink Number should start with 6018');
            return false;
        }
        return true;
        }
        else
        return true;
    }
    
   
  

 function check_uniqueness2($customer_id)
    {
        $nric = trim($_POST["NRIC_no_1"]).trim($_POST["NRIC_no_2"]).trim($_POST["NRIC_no_3"]);
        $res = $this->membership_model->search_unique_server_side($nric,$_POST["bonus_link_no"],$_POST["passport_no"],$_POST["membership_no"],$customer_id);
        if($res=='OK') return true;
        else
        return $res;  
    }
    

function validate_parkson_card_num($algo_parkson_card_num) {
    
    $odd_value_array = array();// empty array
    $even_value_array = array();// empty array
    
    //extract all string element one by one and push into array
    for($i=0; $i< strlen($algo_parkson_card_num)-1;$i++) // to take only 15 digit in count
    {
        if($i%2)// means $i== even so digit is odd because array subscript start with 0
        array_push($even_value_array, $algo_parkson_card_num{$i});
        else
        array_push($odd_value_array, $algo_parkson_card_num{$i});   
    }
    
    //Add all the odd numbers
    $count_total_1 = array_sum($odd_value_array);
    //Add all the even numbers
    $count_total_2 = array_sum($even_value_array);
    
    //Result = (Count Total 1 *3) + Count Total 2
    $result = ( $count_total_1 *3) + $count_total_2 ;
    
    //Round Result = (Result %10)
    $round_result = (int)($result/10);
    
    //Check Digit = 10 - (Result - (Round Result * 10))
    $check_digit =  10 - ($result - ($round_result * 10));
    $check_digit = ($check_digit >=10)? 0:$check_digit;
    
    //set error messsage for sever side validation
    if($algo_parkson_card_num[15] != $check_digit)
    $this->form_validation->set_message('validate_parkson_card_num', 'Invalid parkson card number. Check digit do not validate.');
    
    return $algo_parkson_card_num[15] == $check_digit ;           
}
          
       
       
public function validate_bonus_link_num($algo_bonus_link_num) {

        if($algo_bonus_link_num !=''){ //check for blank bonus link number
        
        $odd_value_array = array();// empty array
        $even_value_array = array();// empty array
        
        //extract all string element one by one and push into array
        for($i=0; $i< strlen($algo_bonus_link_num)-1;$i++) // to take only 15 digit in count
        {
            if($i%2)// means $i== even so digit is odd because array subscript start with 0
            array_push($even_value_array, $algo_bonus_link_num{$i});
            else
            array_push($odd_value_array, $algo_bonus_link_num{$i});   
        }
        
        
        //process with odd array
        $multi_total = 0;
        $count_total_1 =0;
        
        foreach ($odd_value_array as $v)
        {
            $multi_total = $v *2;
            if($multi_total >=9)
            {
            // Count Total1 = Count Total 1 + (Multi Total - 9)
            $count_total_1 = $count_total_1 +($multi_total-9);
            }  
            else
            {
            //Count Total1 = Count Total 1 +Multi Total
            $count_total_1 = $count_total_1 +$multi_total;
            }
        }
        
        //count_total_2 is simple addition of all even values
        //subtract value of last digit
        $count_total_2 = array_sum($even_value_array) ;
        
        //Result = CountTotal1    + CountTotal2
        $result = $count_total_1+$count_total_2;
        
        //Round Result = Result + (10 -   (Result /10)    )
        $round_result = $result +(10 - ($result%10));
        
        //Check Digit = Round Result - Result
        $check_digit = $round_result -$result;
        
        $check_digit = ($check_digit >=10)?0:$check_digit;
        
        //set error messsage for sever side validation
        if($algo_bonus_link_num[15] != $check_digit)
        $this->form_validation->set_message('validate_bonus_link_num', 'Invalid Bonuslink number. Check digit do not validate.');
        
        return $algo_bonus_link_num[15] == $check_digit;
        
        }
}

    /*
     * 
     * for add customer
     * param void
     * return array
     */
    
    public function edit_customer_byadmin()
    {
        if (!$this->tank_auth->is_admin()  ) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }
      
        
       $data["admin_data"] = $this->verify_for_ajax_request();

      
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss_clean'); 
        
        $this->form_validation->set_rules('membership_no', 'Parkson Card Number', 'trim|required|max_length[16]|xss_clean|numeric|min_length[16]|callback_check_pnc[\'membership_no\']|callback_validate_parkson_card_num["membership_no"]|callback_is_pcn_duplicate["membership_no"]');
        $this->form_validation->set_rules('bonus_link_no', 'Bonuslink Number', 'trim|max_length[16]|xss_clean|numeric|min_length[16]|callback_check_bl["bonus_link_no"]|callback_validate_bonus_link_num["bonus_link_no"]|callback_is_bl_duplicate["bonus_link_no"]');
        
        if(!$this->input->post('passport_no')  || $this->input->post('nationality')=='Malaysian' || $this->input->post('nationality')=='malaysian' ){
        $this->form_validation->set_rules('NRIC_no_1', 'NRIC Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('NRIC_no_2', 'NRIC Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('NRIC_no_3', 'NRIC Number', 'trim|required|xss_clean|callback_is_nric_duplicate');
        }
        
        if( (!$this->input->post('NRIC_no_1') && !$this->input->post('NRIC_no_2') && !$this->input->post('NRIC_no_3') ) || ( strtolower($this->input->post('nationality'))!='malaysian' ) )
        {
            $this->form_validation->set_rules('passport_no', 'Passport Number', 'trim|required|xss_clean|callback_is_passport_duplicate["passport_no"]');
        }
         
        $this->form_validation->set_rules('nationality', 'Nationality', 'trim|required|xss_clean');
        $this->form_validation->set_rules('address_1', 'Address', 'trim|required|xss_clean');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required|xss_clean');
       
        //if(!filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL)){   
        //$this->form_validation->set_rules('mobile_1', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //$this->form_validation->set_rules('mobile_2', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //}
          
        //if(!$this->input->post('mobile_1') && !$this->input->post('mobile_2'))
        //$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required|xss_clean');
        
        $this->form_validation->set_rules('mobile_1', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('mobile_2', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean');
        
        $this->form_validation->set_rules('race', 'Race', 'trim|required|xss_clean');
       
        if($this->input->post('race')=='Other')
        $this->form_validation->set_rules('custome_race', 'Other Race', 'trim|required|xss_clean');
        

        if ($this->form_validation->run())
		{ 
                      //get the customer id  
                       $customer_id = $this->input->post('customer_id');
                 
                   //validate duplicates
            $is_duplicates = $this->check_uniqueness2($customer_id);
            if($is_duplicates !== true)
            {
                $result["status"] = 0;
                $result["message"] = $is_duplicates; 
                echo json_encode($result);
                die();  
            }       
                       //get all value form db by customer id and format it
                       $dbArr = $this->membership_model->view_customer($customer_id);
                       $newdbArr = $dbArr[0];
                       
                        //compate difference if change
                          
                          $formArr = $this->input->post();
                          
                          $formArr['mobile'] = $formArr['mobile_1'].$formArr['mobile_2'];
                          $formArr['NRIC_no'] = $formArr['NRIC_no_1'].$formArr['NRIC_no_2'].$formArr['NRIC_no_3'];
                   
                          
                           if($formArr['dob'] =='')
                            { 
                               $formArr['dob']='0000-00-00';
                            }
                            else
                            {
                               $formArr['dob']=date('Y-m-d',  strtotime($formArr['dob']));
                            }
                          
                           if($formArr['race'] == 'Other')
                           {
                              $formArr['race'] = $formArr['custome_race'] ;
                             
                           }
                            
                          $formArr['state'] = $formArr['m_state'] ? $formArr['m_state'] : $formArr['state'];
                         
                          unset($formArr['custome_race']);
                          unset($formArr['mobile_1']);
                          unset($formArr['mobile_2']);
                          
                          unset($formArr['NRIC_no_1']);
                          unset($formArr['NRIC_no_2']);
                          unset($formArr['NRIC_no_3']);
                          
                          unset($formArr['m_state']);
                          unset($formArr['edit_customer_byadmin']);
                          unset($formArr['p_card_holder_id']);
                          unset($formArr['p_card_number']);
                          unset($formArr['p_card_holder']); 
                          
                         $diff = array_diff_assoc($formArr, $newdbArr);
                       
                         if(!empty($diff))
                         {
                             
                             
                              if($return_data = $this->membership_model->edit_customer($customer_id,$diff)){
                                
                                if($return_data["DOB_error"]==1 || $return_data["NRIC_error"]==1  )
                                {
                                    $result["status"] = 1;
                                    $result["message"]=$this->lang->line('edit_customer');
                                    if($return_data["DOB_error"]==1) 
                                    $result["message"] .="<br /><strong style='color:red;' >".$this->lang->line('DOB_error_msg')."</strong>";  
                                
                                    if($return_data["NRIC_error"]==1)
                                    $result["message"] .="<br /><strong style='color:red;' >".$this->lang->line('NIRC_error_msg')."</strong>";  
                                
                                }
                                else{
                                    $result["status"] = 1;
                                    $result["message"] = $this->lang->line('edit_customer');  
                                }
                                     
                              }  
                              else
                              {
                                   $result["status"] = 0;
                                   $result["message"] = $this->lang->line('edit_customer_err');
                              }
                              echo json_encode($result);
                              die();
                         }
                         else
                         {
                                   $result["status"] = 2;
                                   $result["message"] = $this->lang->line('edit_customer_empty');
                         }
                              echo json_encode($result);
                              die();
		}
		else
		{
                   
		 
                     $result["status"] = 0;
                     $result["message"] = validation_errors();
                    
		}
                              echo json_encode($result);
                              die();
    }
    
    
    public function edit_customer_bymanager()
    {
        if (!$this->tank_auth->is_manager()  ) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }
      
       $data["admin_data"] = $this->verify_for_ajax_request();
       $this->form_validation->set_rules('bonus_link_no', 'Bonuslink Number', 'trim|max_length[16]|xss_clean|numeric|min_length[16]|callback_check_bl["bonus_link_no"]|callback_validate_bonus_link_num["bonus_link_no"]|callback_is_bl_duplicate["bonus_link_no"]');
       $this->form_validation->set_rules('address_1', 'Address', 'trim|required|xss_clean');
       $this->form_validation->set_rules('mobile_1', 'Mobile Number', 'trim|numeric|xss_clean');
       $this->form_validation->set_rules('mobile_2', 'Mobile Number', 'trim|numeric|xss_clean');
       $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean');
       
       if ($this->form_validation->run())
		{ 
           //get the customer id  
           $customer_id = $this->input->post('customer_id');
                 
            //validate duplicates
            $is_duplicates = $this->check_uniqueness3($customer_id);
            if($is_duplicates !== true)
            {
                $result["status"] = 0;
                $result["message"] = $is_duplicates; 
                echo json_encode($result);
                die();  
            }       
                       //get all value form db by customer id and format it
                       $dbArr = $this->membership_model->view_customer($customer_id);
                       $newdbArr = $dbArr[0];
                       
                        //compate difference if change
                          
                          $formArr = $this->input->post();
                          $formArr['state'] = $formArr['m_state'] ? $formArr['m_state'] : $formArr['state'];
                          $formArr['mobile'] = $formArr['mobile_1'];
                          $formArr['mobile'] .= $formArr['mobile_2'];
                          unset($formArr['m_state']);
                          unset($formArr['edit_customer_bymanager']);
                          unset($formArr['p_card_holder_id']);
                          unset($formArr['p_card_number']);
                          unset($formArr['p_card_holder']); 
                          unset($formArr['mobile_1']);
                          unset($formArr['mobile_2']);
                          
                         $diff = array_diff_assoc($formArr, $newdbArr);
                       
                         if(!empty($diff))
                         {
                             
                             
                              if($return_data = $this->membership_model->edit_customer($customer_id,$diff)){
                                
                                if($return_data["DOB_error"]==1 || $return_data["NRIC_error"]==1  )
                                {
                                    $result["status"] = 1;
                                    $result["message"]=$this->lang->line('edit_customer');
                                    if($return_data["DOB_error"]==1) 
                                    $result["message"] .="<br /><strong style='color:red;' >".$this->lang->line('DOB_error_msg')."</strong>";  
                                
                                    if($return_data["NRIC_error"]==1)
                                    $result["message"] .="<br /><strong style='color:red;' >".$this->lang->line('NIRC_error_msg')."</strong>";  
                                
                                }
                                else{
                                    $result["status"] = 1;
                                    $result["message"] = $this->lang->line('edit_customer');  
                                }
                                     
                              }  
                              else
                              {
                                   $result["status"] = 0;
                                   $result["message"] = $this->lang->line('edit_customer_err');
                              }
                              echo json_encode($result);
                              die();
                         }
                         else
                         {
                                   $result["status"] = 2;
                                   $result["message"] = $this->lang->line('edit_customer_empty');
                         }
                              echo json_encode($result);
                              die();
		}
		else
		{
                   
		 
                     $result["status"] = 0;
                     $result["message"] = validation_errors();
                    
		}
                              echo json_encode($result);
                              die();
    }
    
   
    function check_uniqueness3($customer_id)
    {
        $nric = "";
        $res = $this->membership_model->search_unique_server_side($nric,@$_POST["bonus_link_no"],0,0,$customer_id);
        if($res=='OK') return true;
        else
        return $res;  
    }

   
    
    public function edit_customer_bystaff()
    {
        if (!$this->tank_auth->is_staff() ) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }
        
         $data["admin_data"] = $this->verify_for_ajax_request();
         $this->form_validation->set_rules('address_1', 'Address', 'trim|required|xss_clean');
         
       // if(!filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL)){   
        //$this->form_validation->set_rules('mobile_1', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //$this->form_validation->set_rules('mobile_2', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //}
          
        //if(!$this->input->post('mobile_1') && !$this->input->post('mobile_2'))
        //$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required|xss_clean');
        
        $this->form_validation->set_rules('mobile_1', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('mobile_2', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean');
       
      
      
        $this->form_validation->set_rules('bonus_link_no', 'Bonuslink Number', 'trim|max_length[16]|xss_clean|numeric|min_length[16]|callback_check_bl["bonus_link_no"]|callback_validate_bonus_link_num["bonus_link_no"]');  
       if ($this->form_validation->run())
		{ 
                      //get the customer id  
                       $customer_id = $this->input->post('customer_id');
                         //validate duplicates
            $is_duplicates = $this->check_uniqueness3($customer_id);
            if($is_duplicates !== true)
            {
                $result["status"] = 0;
                $result["message"] = $is_duplicates; 
                echo json_encode($result);
                die();  
            }            
                       //get all value form db by customer id and format it
                       $dbArr = $this->membership_model->view_customer($customer_id);
                       $newdbArr = $dbArr[0];
                       
                        //compate difference if change
                          $formArr = $this->input->post();
                          
                          //mix mobile_1 and mobile_2 in mobile
                          
                          $formArr['mobile'] = $formArr['mobile_1'];
                          $formArr['mobile'] .= $formArr['mobile_2'];
                          
                          $formArr['state'] = $formArr['m_state'] ? $formArr['m_state'] : $formArr['state'];
                          
                          unset($formArr['edit_customer_bystaff']);
                          unset($formArr['mobile_1']);
                          unset($formArr['mobile_2']);
                          unset($formArr['m_state']);
                          
                          
                         $diff = array_diff_assoc($formArr, $newdbArr);
                       
                         if(!empty($diff))
                         {
                              if($this->membership_model->edit_customer($customer_id,$diff)){
                                     $result["status"] = 1;
                                     $result["message"] = $this->lang->line('edit_customer');  
                              }  
                              else
                              {
                                   $result["status"] = 0;
                                   $result["message"] = $this->lang->line('edit_customer_err');
                              }
                              echo json_encode($result);
                              die();
                         }
                         else
                         {
                                   $result["status"] = 2;
                                   $result["message"] = $this->lang->line('edit_customer_empty');
                         }
                              echo json_encode($result);
                              die();
		}
		else
		{
                   
		     $data = validation_errors();
                     $result["status"] = 0;
                     $result["message"] = $data;
                    
		}
                              echo json_encode($result);
                              die();   
          
          
          
          
          
    }
    
    
/*
 * search bonuslink num exist in db or not 
 * param int
 * retrun array
 */
    
    public function search_unique($customer_id=0)
    {
        $this->verify_for_ajax_request();
                             
                             $result_db = $this->membership_model->search_unique($customer_id);
                             if( $result_db == 'OK'){
                                   $result["status"] = 0;
                                                              } 
                              else
                              {
                                  $result["status"] = 1;
                                  $result["message"] = $result_db;
                              }
                                   echo json_encode($result);
                              die();
    }
    
    
    /*
     * load customer_list page
     * parma void 
     * return null
     */
    public function customer_list()
    {
         $data["admin_data"] = $this->verify_for_direct_request();
         $data["title"] = "Membership List";
        
        //get list of loction with id
        $data['location'] = $this->membership_model->get_location_list();
        $this->load->view('includes/admin_header', $data);
        $this->load->view('membership/customer_list', $data);
        $this->load->view('includes/admin_footer', $data);
    }
     public function archive_customer_list()
    {
         $data["admin_data"] = $this->verify_for_direct_request();
         $data["title"] = "Membership List";
        
        //get list of loction with id
        $data['location'] = $this->membership_model->get_location_list();
        $this->load->view('includes/admin_header', $data);
        $this->load->view('membership/archive_customer_list', $data);
        $this->load->view('includes/admin_footer', $data);
    }
    
    
     /*
     * load customer_list page
     * parma void 
     * return null
     */
    public function customer_list_for_find_dialog_box($c_id=0)
    {
         $data["admin_data"] = $this->verify_for_direct_request();
         $data["title"] = "Membership List";
         $data["current_user"] = $c_id;
        //get list of loction with id
        $data['location'] = $this->membership_model->get_location_list();
        $this->load->view('membership/customer_list_for_find', $data);
    }
    
    
    /*
     * get all cutomer form db
     * parma void
     * retrun void
     */
    public function get_cutomer_list()
    {
       $this->verify_for_ajax_request();
       $f_name = trim(@$_REQUEST['f_name']);
       $l_name = trim(@$_REQUEST['l_name']);
       $email = trim(@$_REQUEST['email']);
       $NRIC_no = trim(@$_REQUEST['NRIC_no']);
       $mobile_no = trim(@$_REQUEST['mobile_no']);
       $passport_no = trim(@$_REQUEST['passport_no']);
      
       $membership_no = trim(@$_REQUEST['membership_no']);
       $card_no = trim(@$_REQUEST['card_no']);
       
       $bonus_card_no = trim(@$_REQUEST['bonus_card_no']);
       $address = trim(@$_REQUEST['address']);
       $city = trim(@$_REQUEST['city']);
       $card_min_val = trim(@$_REQUEST['card_min_val']);
       $card_max_val = trim(@$_REQUEST['card_max_val']);
       $date_form = trim(@$_REQUEST['date_form']);
       $date_to = trim(@$_REQUEST['date_to']);
       $location = trim(@$_REQUEST['location']); 
       $company_name = trim(@$_REQUEST['company_name']);
     
       $condition = " customers.is_archive = 0 ";
       if($f_name) $condition.=" AND customers.first_name LIKE '%$f_name%' ";
       if($l_name) $condition.=" AND customers.last_name LIKE '%$l_name%' ";
       if($email) $condition.=" AND customers.email LIKE '%$email%' ";
       
        if($NRIC_no) $condition.=" AND customers.NRIC_no LIKE '%$NRIC_no%' ";
       if($mobile_no) $condition.=" AND customers.mobile LIKE '%$mobile_no%' ";
       if($passport_no) $condition.=" AND customers.passport_no LIKE '%$passport_no%' ";
       
       if($membership_no) $condition.=" AND customers.membership_no LIKE '%$membership_no%' ";
       if($card_no) $condition.=" AND customers.card_no LIKE '%$card_no%' ";
       if($bonus_card_no) $condition.=" AND customers.bonus_link_no LIKE '%$bonus_card_no%' ";
       if($address) $condition.=" AND customers.address_1 LIKE '%$address%' ";
       
       if($city) $condition.=" AND customers.city LIKE '%$city%' ";
       if($location) $condition.=" AND customers.location_id = $location ";
       if($company_name) $condition.=" AND customers.company_name LIKE '%$company_name%' ";
       if($card_min_val && $card_max_val )  $condition.=" AND customers.card_no >= $card_min_val AND customers.card_no <= $card_max_val ";
       if($date_form && $date_to ) 
       {
           $date_form = date('Y-m-d',strtotime($date_form));
           $date_to = date('Y-m-d',strtotime($date_to));
           $condition.=" AND date(customers.created) >= '$date_form' AND  date(customers.created) <= '$date_to' ";
       }
       
      $this->datatables->select('customers.created,customers.first_name,customers.last_name,customers.membership_no,customers.membership_type,customers.membership_tier,customers.valid_thru,staff_id, customers.customer_id')
       ->from('customers'); 
       if($condition)
       $this->datatables->where($condition,null, false);        
       echo $this->datatables->generate();  
    }
    
   /** get customer list without using ignited table
    * @param void
    * @return json
    **/
    public function get_customer_list(){
        $this->verify_for_ajax_request();
       $f_name = trim(@$_REQUEST['f_name']);
       $l_name = trim(@$_REQUEST['l_name']);
       $email = trim(@$_REQUEST['email']);
       $NRIC_no = trim(@$_REQUEST['NRIC_no']);
       $mobile_no = trim(@$_REQUEST['mobile_no']);
       $passport_no = trim(@$_REQUEST['passport_no']);
      
       $membership_no = trim(@$_REQUEST['membership_no']);
       $card_no = trim(@$_REQUEST['card_no']);
       
       $bonus_card_no = trim(@$_REQUEST['bonus_card_no']);
       $address = trim(@$_REQUEST['address']);
       $city = trim(@$_REQUEST['city']);
       $card_min_val = trim(@$_REQUEST['card_min_val']);
       $card_max_val = trim(@$_REQUEST['card_max_val']);
       $date_form = trim(@$_REQUEST['date_form']);
       $date_to = trim(@$_REQUEST['date_to']);
       $location = trim(@$_REQUEST['location']); 
       $company_name = trim(@$_REQUEST['company_name']);
       $tier = trim(@$_REQUEST['membership_tier']); 
       $type = trim(@$_REQUEST['membership_type']);
     
       $condition = " customers.is_archive = 0 ";
       if($f_name) $condition.=" AND customers.first_name LIKE '%$f_name%' ";
       if($l_name) $condition.=" AND customers.last_name LIKE '%$l_name%' ";
       if($email) $condition.=" AND customers.email LIKE '%$email%' ";
       
        if($NRIC_no) $condition.=" AND customers.NRIC_no LIKE '%$NRIC_no%' ";
       if($mobile_no) $condition.=" AND customers.mobile LIKE '%$mobile_no%' ";
       if($passport_no) $condition.=" AND customers.passport_no LIKE '%$passport_no%' ";
       
       if($membership_no) $condition.=" AND customers.membership_no LIKE '%$membership_no%' ";
       if($card_no) $condition.=" AND customers.card_no LIKE '%$card_no%' ";
       if($bonus_card_no) $condition.=" AND customers.bonus_link_no LIKE '%$bonus_card_no%' ";
       if($address) $condition.=" AND customers.address_1 LIKE '%$address%' ";
       
       if($city) $condition.=" AND customers.city LIKE '%$city%' ";
       if($location) $condition.=" AND customers.location_id = $location ";
       if($company_name) $condition.=" AND customers.company_name LIKE '%$company_name%' ";
       if($card_min_val && $card_max_val )  $condition.=" AND customers.card_no >= $card_min_val AND customers.card_no <= $card_max_val ";
       if($date_form && $date_to ) 
       {
           $date_form = date('Y-m-d',strtotime($date_form));
           $date_to = date('Y-m-d',strtotime($date_to));
           $condition.=" AND date(customers.created) >= '$date_form' AND  date(customers.created) <= '$date_to' ";
       }
       if($tier) $condition.=" AND customers.membership_tier = '$tier' ";
       if($type) $condition.=" AND customers.membership_type = '$type' ";
       
         //$this->datatables->select('customers.created,customers.first_name,customers.last_name,customers.membership_no,customers.membership_type,customers.membership_tier,customers.valid_thru, customers.customer_id')
       //->from('customers');   
              
                $data = array();
                $request= $_REQUEST;
                $columns = array( 
                      // datatable column index  => database column name
	                    0 =>'customers.created', 
	                    1 => 'customers.first_name',
                        2 => 'customers.last_name',
                        3 => 'customers.membership_no',
                        4 => 'customers.membership_type',
                        5 => 'customers.membership_tier',
                        6 => 'customers.valid_thru',
                        7 => 'users.first_name'
                       );
                        
                $totalRows = $this->membership_model->get_total_records();
                $totalFiltered = $totalRows;
                $result_set = $this->membership_model->get_filtered_records($condition,$request['sSearch'],
                                                                                  $columns[$request['iSortCol_0']],
                                                                                  $request['sSortDir_0'],
                                                                                  $request['iDisplayStart'],$request['iDisplayLength']);  
                
                
             
                
                $totalFiltered = $result_set['filtered_records'];
                $data = $result_set['data'];
                $json_data = array(
			                        "sColumns"            => 'Created, First_name, Last_name,Membership_no,Membership_type,Membership_tier,Valid_thru,Captured_by,Customer_id',   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			                        "iTotalRecords"    => intval( $totalRows ),  // total number of records
                                    "iTotalDisplayRecords" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			                        "aaData"            => $data   // total data array
			                        );

                echo json_encode($json_data);  // send data as json format
             
             
             
       } 
    
     /*
     * get all  Archive cutomer form db
     * parma void
     * retrun void
     */
    public function get_archive_cutomer_list()
    {
       $this->verify_for_ajax_request();
       $f_name = trim($_REQUEST['f_name']);
       $l_name = trim($_REQUEST['l_name']);
       $email = trim($_REQUEST['email']);
       $NRIC_no = trim($_REQUEST['NRIC_no']);
       $mobile_no = trim($_REQUEST['mobile_no']);
       $passport_no = trim($_REQUEST['passport_no']);
      
       $membership_no = trim($_REQUEST['membership_no']);
       $card_no = trim($_REQUEST['card_no']);
       
       $bonus_card_no = trim($_REQUEST['bonus_card_no']);
       $address = trim($_REQUEST['address']);
       $city = trim($_REQUEST['city']);
       $card_min_val = trim($_REQUEST['card_min_val']);
       $card_max_val = trim($_REQUEST['card_max_val']);
       $date_form = trim($_REQUEST['date_form']);
       $date_to = trim($_REQUEST['date_to']);
       $location = trim($_REQUEST['location']);
       
       $condition = "is_archive = 1  ";
       if($f_name) $condition.=" AND customers.first_name LIKE '%$f_name%' ";
       if($l_name) $condition.=" AND customers.last_name LIKE '%$l_name%' ";
       if($email) $condition.=" AND customers.email LIKE '%$email%' ";
       
        if($NRIC_no) $condition.=" AND customers.NRIC_no LIKE '%$NRIC_no%' ";
       if($mobile_no) $condition.=" AND customers.mobile LIKE '%$mobile_no%' ";
       if($passport_no) $condition.=" AND customers.passport_no LIKE '%$passport_no%' ";
       
       if($membership_no) $condition.=" AND customers.membership_no LIKE '%$membership_no%' ";
       if($card_no) $condition.=" AND customers.card_no LIKE '%$card_no%' ";
       if($bonus_card_no) $condition.=" AND customers.bonus_link_no LIKE '%$bonus_card_no%' ";
       if($address) $condition.=" AND customers.address_1 LIKE '%$address%' ";
       
       if($city) $condition.=" AND customers.city LIKE '%$city%' ";
       if($location) $condition.=" AND customers.location_id = $location ";
       if($card_min_val && $card_max_val )  $condition.=" AND customers.card_no >= $card_min_val AND customers.card_no <= $card_max_val ";
       if($date_form && $date_to ) 
       {
           $date_form = date('Y-m-d',strtotime($date_form));
           $date_to = date('Y-m-d',strtotime($date_to));
           $condition.=" AND date(customers.created) >= '$date_form' AND  date(customers.created) <= '$date_to' ";
       }
       
      $this->datatables->select('customers.created,customers.first_name,customers.last_name,customers.membership_no,customers.membership_type,customers.membership_tier,customers.valid_thru, users.first_name as staff_fname , customers.customer_id, users.last_name as staff_lname')
                ->join('users', 'users.id = customers.staff_id')
                ->where($condition)
                ->from('customers'); 
        echo $this->datatables->generate();  
    }
    
    
     /**
     * get all cutomer form db
     * parma void
     * retrun void
     */
    public function get_cutomer_list_for_find($c_id)
    {
       $this->verify_for_ajax_request();
      
       $f_name = trim($_REQUEST['Ff_name']);
       $l_name = trim($_REQUEST['Fl_name']);
       $email = trim($_REQUEST['Femail']);
       $mobile_no = trim($_REQUEST['Fmobile_no']);
       $address = trim($_REQUEST['Faddress']);
       $city = trim($_REQUEST['Fcity']);
      
       $membership_no = trim($_REQUEST['Fmembership_no']);
       $card_no = trim($_REQUEST['Fcard_no']);
       $reg_no = trim($_REQUEST['Freg_no']);
       $NRIC_no = trim($_REQUEST['FNRIC_no']);
       $passport_no = trim($_REQUEST['Fpassport_no']);
       
       
       
      
       
       $condition = "is_archive != 1 AND  membership_type ='primary' ";
       if($c_id)
       $condition .=" AND customer_id != ".$c_id;
       
       if($f_name) $condition.=" AND customers.first_name LIKE '%$f_name%' ";
       if($l_name) $condition.=" AND customers.last_name LIKE '%$l_name%' ";
       
       if($NRIC_no) $condition.=" AND customers.NRIC_no LIKE '%$NRIC_no%' ";
       if($mobile_no) $condition.=" AND customers.mobile LIKE '%$mobile_no%' ";
       if($passport_no) $condition.=" AND customers.passport_no LIKE '%$passport_no%' ";
       
       if($membership_no) $condition.=" AND customers.membership_no LIKE '%$membership_no%' ";
       if($card_no) $condition.=" AND customers.card_no LIKE '%$card_no%' ";
       
      
       
      $this->datatables->select('customers.first_name,customers.last_name,customers.membership_no, customers.card_no, customers.registration_no, customers.created,customers.valid_thru,customers.customer_id')
               ->where($condition)
               ->from('customers'); 
        echo $this->datatables->generate();  
    }
    
    /*
     * function for load customer all details
     * param int
     * return array
     */
    public function view_customer($cid)
    {
       $this->verify_for_ajax_request();
       $data["details"] = $this->membership_model->view_customer($cid);
       $data["history"]=  $this->membership_model->edit_history($cid);       
       $data["print_history"] = $this->membership_model->print_history($cid);
       $this->load->view('membership/view_customer',$data);  
    }

     /*
     * function for archive customer 
     * param int
     * return array
     */
    public function archive_customer($cid)
    {
       
           $this->verify_for_ajax_request();
           $is_deleted = $this->membership_model->archive_customer($cid);
                    if($is_deleted)
                    {
                     $result["status"] = 1; 
                     $result["message"] = $this->lang->line('customer_delete_success');
                    }
                    else
                    {
                       $result["status"] = 0; 
                       $result["message"] = $this->lang->line('customer_delete_failure');
                    } 
            echo json_encode($result);
            die(); 
    }
     /**
     * Restore customer-prashant 
     * @param customer_id
     *  @return bool
     */
    public function restore_customer($cid)
    {
       
           $this->verify_for_ajax_request();
           $is_deleted = $this->membership_model->restore_customer($cid);
                    if($is_deleted)
                    {
                     $result["status"] = 1; 
                     $result["message"] = $this->lang->line('customer_restore_success');
                    }
                    else
                    {
                       $result["status"] = 0; 
                       $result["message"] = $this->lang->line('customer_restore_failure');
                    } 
            echo json_encode($result);
            die(); 
    }
    
    
    
    function print_customer_details($cid)
    {
       $this->verify_for_direct_request();
       $data["details"] =  $this->membership_model->view_customer($cid);
       
        $tpl_path = 'membership/view_customer-PDF.php';
        $tpl_data['site_title'] = 'Parkson Membership';
        
        if(!file_exists('temp'))
        mkdir('temp','775');
        $thefullpath =  "temp/".$data["details"][0]["first_name"]."_".$data["details"][0]["last_name"]."_".$data["details"][0]["customer_id"].".pdf";
        require_once(APPPATH.'third_party/html2pdf/html2pdf.class.php');
        $this->load->library('parser');
       
        $content = $this->parser->parse($tpl_path, $data, TRUE);
        
     
        
        $html2pdf = new HTML2PDF('L','A4','en', true, 'UTF-8');
        
        $html2pdf->pdf->SetAuthor($tpl_data['site_title']);
        $html2pdf->pdf->SetTitle($tpl_data['site_title']);
        $html2pdf->pdf->SetSubject($tpl_data['site_title']);
        $html2pdf->pdf->SetKeywords($tpl_data['site_title']);
        $html2pdf->pdf->SetProtection(array('print'), '');//allow only view/print
        $html2pdf->WriteHTML($content);
        $html2pdf->Output($thefullpath, 'O'); 
        
        unlink($thefullpath);
    }
    
    
     function print_customer_card($cid)
    {
       $this->verify_for_direct_request();
       $data["details"] =  $this->membership_model->view_customer($cid);
       
        $tpl_path = 'membership/view_card-PDF.php';
        $tpl_data['site_title'] = 'Parkson Membership';
        
        if(!file_exists('auto_generated'))
        mkdir('auto_generated','775');
        $thefullpath =  "auto_generated/".$data["details"][0]["first_name"]."_".$data["details"][0]["customer_id"].".pdf";
        
        require_once(APPPATH.'third_party/html2pdf/html2pdf.class.php');
        $html2pdf = new HTML2PDF('L',array(54,85),'en', true, 'UTF-8');
        
         $this->load->model('settings_model');
         $print_settings = $this->settings_model->get_print_settings();
         $top = (@$print_settings->top_margin) ? $print_settings->top_margin : 24;
         $left = (@$print_settings->left_margin) ? $print_settings->left_margin : 4.2;
         
            // set document information
            $html2pdf->pdf->SetCreator(PDF_CREATOR);
            $html2pdf->pdf->SetAuthor('Parkson');
            $html2pdf->pdf->SetTitle('Parkson Membership');
            $html2pdf->pdf->SetSubject('Parkson Membership');
            $html2pdf->pdf->SetKeywords('Parkson Membership');
            
            // remove default header/footer
            $html2pdf->pdf->setPrintHeader(false);
            $html2pdf->pdf->setPrintFooter(false);
            
            // set default monospaced font
            $html2pdf->pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
            
            // set margins
            $html2pdf->pdf->SetMargins($left, $top, PDF_MARGIN_RIGHT);
            
            // set auto page breaks
            $html2pdf->pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
            
            // ---------------------------------------------------------
            
            // set font
            $html2pdf->pdf->SetFont('calibri', 'BI',11);
            
            // add a page
            $html2pdf->pdf->AddPage();
            // MultiCell($w, $h, $txt, $border=0, $align='J', $fill=0, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0)
            
            if($data["details"][0]["name_on_card"])
            $txt = htmlspecialchars(strtoupper($data["details"][0]["name_on_card"]));
            else
            $txt = htmlspecialchars(strtoupper($data["details"][0]["first_name"]." ".$data["details"][0]["last_name"]));
            $html2pdf->pdf->MultiCell(55, 5, $txt, 0, 'L', 1, 0, '', '', true);
            //$html2pdf->pdf->MultiCell(55, 5, $txt, 0, 'L', 1, 0, 4, 25, true);
            // ---------------------------------------------------------
            
            //Close and output PDF document
            $html2pdf->pdf->Output($data["details"][0]["first_name"]."_".$data["details"][0]["last_name"]."_".$data["details"][0]["customer_id"].'.pdf', 'I');
            $this->membership_model->add_print_out($cid);
      }
      
      function print_qr_code($cid)
      {
           
       $this->verify_for_direct_request();
       $data["details"] =  $this->membership_model->view_customer($cid);
     
       $vaild_thru=date('d-m-Y',strtotime($data["details"][0]["valid_thru"]));   
            //genrate QR Code
            header("Content-Type: image/png");
            $params['data'] = "Customer Name:".$data["details"][0]["title"]." ".$data["details"][0]["first_name"]." ".$data["details"][0]["last_name"]."\n"."Card No.:".$data["details"][0]["card_no"]."\n"."Valid Thru:".$vaild_thru."\n"."Card Type:".ucfirst($data["details"][0]["membership_tier"]);
            $params['level'] = 'M';
            $params['size'] = 3;
            $qr_code_image="tes_".uniqid().".png";
            $output_dir = 'temp/qr-code/';
             if(!file_exists($output_dir))
               	mkdir($output_dir,0755, true) or die("cannot make dir");       
            $params['savename'] =  $output_dir.$qr_code_image;          
            $this->ciqrcode->generate($params);
        chmod($output_dir.$qr_code_image, 0775); 
        require_once(APPPATH.'third_party/html2pdf/html2pdf.class.php');
        $html2pdf = new HTML2PDF('L',array(54,85),'en', true, 'UTF-8');
        
         $this->load->model('settings_model');
         $print_settings = $this->settings_model->get_print_settings();
         $top = (@$print_settings->top_margin) ? $print_settings->top_margin : 24;
         $left = (@$print_settings->left_margin) ? $print_settings->left_margin : 4.2;
         
            // set document information
            $html2pdf->pdf->SetCreator(PDF_CREATOR);
            $html2pdf->pdf->SetAuthor('Parkson');
            $html2pdf->pdf->SetTitle('Parkson Membership');
            $html2pdf->pdf->SetSubject('Parkson Membership');
            $html2pdf->pdf->SetKeywords('Parkson Membership');
            
            // remove default header/footer
            $html2pdf->pdf->setPrintHeader(false);
            $html2pdf->pdf->setPrintFooter(false);
            
            // set default monospaced font
            $html2pdf->pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
            
            // set margins
            $html2pdf->pdf->SetMargins($left, $top, PDF_MARGIN_RIGHT);
            
            // set auto page breaks
            $html2pdf->pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
            
            // ---------------------------------------------------------
            
          
            $content =   '<img src="temp/qr-code/'.$qr_code_image.'" />';

            $html2pdf->WriteHTML($content);
            //Close and output PDF document
            $html2pdf->pdf->Output($data["details"][0]["first_name"]."_".$data["details"][0]["last_name"]."_".$data["details"][0]["customer_id"].'.pdf', 'I');
             unlink($output_dir.$qr_code_image);//delete qr code image
           
      
      }
    

    /*
     * function for load customer detail according to loggedin user type
     * param int 
     * return array
     */
    public function edit_customer($cid)
    {
        $this->verify_for_ajax_request();
           $data["details"] = $this->membership_model->view_customer($cid);
           
           //break nric_num into three field 000000-00-0000
            
                  $NRIC_no = $data["details"][0]["NRIC_no"];
                  unset( $data["details"][0]["NRIC_no"]);
                 $data["details"][0]["NRIC_no_1"] = substr($NRIC_no, 0, 6); 
                 $data["details"][0]["NRIC_no_2"] = substr($NRIC_no, 6, 2);
                 $data["details"][0]["NRIC_no_3"] = substr($NRIC_no, 8, 4);
                 
                 
                
                
           //break mobile_num into 2 field 000-0000000
                  $mobile =  $data["details"][0]["mobile"];
                  unset($data["details"][0]["mobile"]);
                  if(strlen($mobile)>10)
                  {
                    $data["details"][0]["mobile_1"] = substr($mobile, 0, 4);
                    $data["details"][0]["mobile_2"] = substr($mobile, 4, 8);
                  }
                  else{
                    $data["details"][0]["mobile_1"] = substr($mobile, 0, 3);
                    $data["details"][0]["mobile_2"] = substr($mobile, 3, 7);
                  }
                  
                  
           
           
        if($this->tank_auth->is_admin()) {
            
        $data["admin_data"] = $this->verify_for_direct_request();
        $data["title"] = "Update Membership";
        $this->load->view('includes/admin_header', $data);
        $this->load->view('membership/editby_admin_customer',$data);
        $this->load->view('includes/admin_footer', $data);
        }
        
        //if($this->tank_auth->is_manager()) {
//            
//        $data["admin_data"] = $this->verify_for_direct_request();
//        $data["title"] = "Update Membership";
//        $this->load->model('staff_model');
//        $data["manager_details"] = $this->staff_model->view_staff($this->tank_auth->get_user_id());
//        $this->load->view('includes/admin_header', $data);
//        $this->load->view('membership/editby_manager_customer',$data);
//        $this->load->view('includes/admin_footer', $data);
//        }
//        else {
//        if($this->tank_auth->is_staff())
//        $this->load->view('membership/editby_staff_customer',$data);
//        }       
    }

    /**
     * view editd history-prashant
     * @param edit_history_id(edit_history table)
     * */
     public function view_edit_history($history_id)
     {
        $this->verify_for_ajax_request();
        $data["details"] = $this->membership_model->view_edit_history($history_id);
   
        $this->load->view('membership/view_edit_history', $data);
     }
     
   //check weather a selected primary have less that 9 supp reocrds
      public function is_supp_limit_reached($customer_id)
        {
             $this->verify_for_ajax_request();
             $result_db = $this->membership_model->is_supp_limit_reached($customer_id);
             if($result_db){
                  $result["status"] = 1;
                  $result["message"] = $this->lang->line('supp_limit_reached');
              }
               else
              {
                  $result["status"] = 0;
                  
              }
               echo json_encode($result);
               die();
        }

   
    /**
     * function to generate csv according to range of date
     */
     public function generate_csv()
    {
       $data["admin_data"] = $this->verify_for_direct_request();
        
       $this->verify_for_direct_request();
        
       $this->form_validation->set_rules('export_date_form', 'From Date', 'trim|required|xss_clean');
       $this->form_validation->set_rules('export_date_to', 'To Date', 'trim|required|xss_clean');
        
           if ($this->form_validation->run())
           {
              //get date range
               $export_form_date =  date('Y-m-d',  strtotime($this->input->post('export_date_form')));
               $export_form_to =   date('Y-m-d',  strtotime($this->input->post('export_date_to'))) ;
               
            //load csv helper
             $this->load->helper('csv');
             //function call that generate query for csv file 
             $quer = $this->membership_model->generate_query_csv($export_form_date,$export_form_to);
           
                if($quer->num_rows() == '0')
                {
                     $msgdata = array(
                                        'text'  => $this->lang->line('result_empty'),
                                       'class'     => 'danger'
                                        );
                                        $this->session->set_flashdata($msgdata);
                         redirect('membership/customer_list');
                }
            
            $seq = (int)file_get_contents('counter.txt');
            $seq = str_pad($seq, 2, '0', STR_PAD_LEFT); 
            $file_name = date('ymd')."_$seq".'PM.csv';
            $path = 'temp/'.$file_name;
            $seq++;
            file_put_contents('counter.txt', $seq);
            
          
            query_to_csv($quer,TRUE,$path);
               
            if (ini_get('zlib.output_compression')) {
                ini_set('zlib.output_compression', 'Off');
            }
                $this->load->helper('download');
                $file_data = file_get_contents($path);
                unlink($path);
                force_download($file_name, $file_data);  
            }
            else {
               $msgdata = array(
                'text'  => $this->lang->line('date_empty'),
               'class'     => 'danger'
                );
                $this->session->set_flashdata($msgdata);
            }
        //    redirect('membership/customer_list'); 
    }
/**
     * function to generate csv according to range of date
     */
     public function generate_customer_history_csv()
    {
       $data["admin_data"] = $this->verify_for_direct_request();      
//      echo "<pre>";
//      print_r($_POST);
//      die;
       $this->verify_for_direct_request();
        
       $this->form_validation->set_rules('history_export_date_form', 'From Date', 'trim|required|xss_clean');
       $this->form_validation->set_rules('history_export_date_to', 'To Date', 'trim|required|xss_clean');
        
           if ($this->form_validation->run())
           {
              //get date range
               $export_form_date =  date('Y-m-d',  strtotime($this->input->post('history_export_date_form')));
               $export_form_to =   date('Y-m-d',  strtotime($this->input->post('history_export_date_to'))) ;
               
            //load csv helper
             $this->load->helper('csv');
             //function call that generate query for csv file 
             $quer = $this->membership_model->generate_query_csv_for_customer_history($export_form_date,$export_form_to);
         
                if($quer->num_rows() == '0')
                {
                     $msgdata = array(
                                        'text'  => $this->lang->line('result_empty'),
                                       'class'     => 'danger'
                                        );
                                        $this->session->set_flashdata($msgdata);
                         redirect('membership/customer_list');
                }
            
            $seq = (int)file_get_contents('counter_history.txt');
            $seq = str_pad($seq, 2, '0', STR_PAD_LEFT); 
            $file_name = date('ymd')."_$seq".'.csv';
            $path = 'temp/'.$file_name;
            $seq++;
            file_put_contents('counter_history.txt', $seq);
            
          
            query_to_csv_customer_history($quer,TRUE,$path);
               
            if (ini_get('zlib.output_compression')) {
                ini_set('zlib.output_compression', 'Off');
            }
                $this->load->helper('download');
                $file_data = file_get_contents($path);
                unlink($path);
                force_download($file_name, $file_data);  
            }
            else {
               $msgdata = array(
                'text'  => $this->lang->line('date_empty'),
               'class'     => 'danger'
                );
                $this->session->set_flashdata($msgdata);
            }
        //    redirect('membership/customer_list'); 
    }

        /**
         * membership::view_customer_supplementry()
         * 
         * @param mixed $cid
         * @return void
         */
        function view_customer_supplementry($cid)
        {
            $this->verify_for_ajax_request();
            $data["details"] = $this->membership_model->view_customer_supplementry($cid);        
            $this->load->view('membership/view_customer_supplementry',$data);            
        }


        /**
     * Verify if user is logged in and is admin (for direct requests)
     * 
     * */
    private function verify_for_direct_request() {
        if (!$this->tank_auth->is_logged_in()) {
            redirect('/auth/login/');
            die();
        }
        if (!$this->tank_auth->is_admin() && !$this->tank_auth->is_staff() ) {
            redirect('/auth/login/');
            die();
        }
        
        return $this->session->all_userdata();
    }
   
     /**
     * Verify if user is logged in and is admin (for ajax requests)
     * 
     * */
    private function verify_for_ajax_request() {
        if (!$this->tank_auth->is_logged_in()) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }

        if (!$this->tank_auth->is_admin() && !$this->tank_auth->is_staff() ) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }
    }
    
    
    
    
    
    
    ## ADDITIONAL DUPLICATE CHECKES AT SERVER SIDE##
    function is_pcn_duplicate($pcn)
    {   
        $customer_id = (@$_POST["customer_id"]) ? $_POST["customer_id"] : 0 ; 
        $res = $this->membership_model->is_pcn_duplicate($pcn,$customer_id);
        if($res){
         $this->form_validation->set_message('is_pcn_duplicate','Parkson Card Number already exists.<br />');   
         return false;   
        } 
        else
        return true;  
    }  
    
     function is_bl_duplicate($bonuslink)
    {   
        $customer_id = (@$_POST["customer_id"]) ? $_POST["customer_id"] : 0 ; 
        $res = $this->membership_model->is_bl_duplicate($bonuslink,$customer_id);
        if($res){
         $this->form_validation->set_message('is_bl_duplicate','Bonuslink Number already exists.<br />');   
         return false;   
        } 
        else
        return true;  
    }   
    
    
     function is_passport_duplicate($passport)
    {   
        $customer_id = (@$_POST["customer_id"]) ? $_POST["customer_id"] : 0 ; 
        $res = $this->membership_model->is_passport_duplicate($passport,$customer_id);
        if($res){
         $this->form_validation->set_message('is_passport_duplicate','Passport Number already exists.<br />');   
         return false;   
        } 
        else
        return true;  
    }   
    
    
      function is_nric_duplicate()
    {   
        $customer_id = (@$_POST["customer_id"]) ? $_POST["customer_id"] : 0 ;
        if($customer_id)
        $nric = trim($_POST["NRIC_no_1"]).trim($_POST["NRIC_no_2"]).trim($_POST["NRIC_no_3"]); 
        else
        $nric = trim($_POST["nric_num_1"]).trim($_POST["nric_num_2"]).trim($_POST["nric_num_3"]); 
        
        $res = $this->membership_model->is_nric_duplicate($nric,$customer_id);
        if($res){
         $this->form_validation->set_message('is_nric_duplicate','NRIC Number already exists.<br />');   
         return false;   
        } 
        else
        return true;  
    }   
    
    
    
}


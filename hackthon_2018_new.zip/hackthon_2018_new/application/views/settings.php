<?php



$first_name = array(
	'name'	=> 'first_name',
	'id'	=> 'first_name',
	'value' => @$profile_info->first_name,
	'maxlength'	=> 80,
	'size'	=> 30,
     'class'=>'form-control',
    'placeholder'=>'First Name'
);
$last_name = array(
	'name'	=> 'last_name',
	'id'	=> 'last_name',
	'value' => @$profile_info->last_name,
	'maxlength'	=> 80,
	'size'	=> 30,
     'class'=>'form-control',
    'placeholder'=>'Last Name'
);


$top_margin = array(
	'name'	=> 'top_margin',
	'id'	=> 'top_margin',
	'value' => @$print_settings->top_margin,
	'maxlength'	=> 80,
	'size'	=> 30,
     'class'=>'form-control',
    'placeholder'=>'Margin from Top'
);

$left_margin = array(
	'name'	=> 'left_margin',
	'id'	=> 'left_margin',
	'value' => @$print_settings->left_margin,
	'maxlength'	=> 80,
	'size'	=> 30,
     'class'=>'form-control',
    'placeholder'=>'Margin from Left'
);


$password = array(
	'name'	=> 'old_password',
	'id'	=> 'old_password',
	'maxlength'	=> 80,
	'class'=>'form-control',
    'placeholder'=>'Current Password'
);

$new_password = array(
	'name'	=> 'new_password',
	'id'	=> 'new_password',
	'maxlength'	=> 80,
	'class'=>'form-control',
    'placeholder'=>'New Password'
);

$confirm_new_password = array(
	'name'	=> 'confirm_new_password',
	'id'	=> 'confirm_new_password',
	'maxlength'	=> 80,
	'class'=>'form-control',
    'placeholder'=>'Confirm New Password'
);

$firstQuarterStartingMonth  =  array(
                                     1 =>  'January',
                                     2 =>   'February',
                                     3 =>   'March',
                                     4 =>    'April',
                                     5 =>  'May',
                                     6 =>   'June',
                                     7 =>   'July ',
                                     8 =>    'August',
                                     9 =>   'September',
                                     10 =>   'October',
                                     11 =>   'November',
                                     12 =>    'December',
                                     );
$SecondQuarterStartingMonth  =  array(
                                     1 =>  'January',
                                     2 =>   'February',
                                     3 =>   'March',
                                     4 =>    'April',
                                     5 =>  'May',
                                     6 =>   'June',
                                     7 =>   'July ',
                                     8 =>    'August',
                                     9 =>   'September',
                                     10 =>   'October',
                                     11 =>   'November',
                                     12 =>    'December',
                                     );
$ThirdQuarterStartingMonth  =  array(
                                     1 =>  'January',
                                     2 =>   'February',
                                     3 =>   'March',
                                     4 =>    'April',
                                     5 =>  'May',
                                     6 =>   'June',
                                     7 =>   'July ',
                                     8 =>    'August',
                                     9 =>   'September',
                                     10 =>   'October',
                                     11 =>   'November',
                                     12 =>    'December',
                                     );
$forthQuarterStartingMonth  =  array(
                                     1 =>  'January',
                                     2 =>   'February',
                                     3 =>   'March',
                                     4 =>    'April',
                                     5 =>  'May',
                                     6 =>   'June',
                                     7 =>   'July ',
                                     8 =>    'August',
                                     9 =>   'September',
                                     10 =>   'October',
                                     11 =>   'November',
                                     12 =>    'December',
                                     );

?> 
<!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>Settings
                    <small>Change your basic and login settings.</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo site_url(''); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Settings</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                <div class="row">
               
      
      
        <div class="col-lg-12">
        <div id="add_user_res"></div>
        <div class="well-lg">
        <h4>Change Basic Information</h4>
         <?php echo form_open(site_url().'/settings/profile_edit',  array('class'=>'form-horizontal','role'=>'form','id'=>'basic_form')); ?>
        <div class="form-group">
            
            <div class="col-lg-6">
                <label class="control-label">First Name</label>
              <?php echo form_input($first_name); ?> 
                <span style="color: red;"><?php echo form_error($first_name['name']); ?><?php echo isset($errors[$first_name['name']])?$errors[$first_name['name']]:''; ?></span>
            </div>
            <div class="col-lg-6">
                <label class="control-label">Last Name</label>
              <?php echo form_input($last_name); ?> 
                 <span style="color: red;"><?php echo form_error($last_name['name']); ?><?php echo isset($errors[$last_name['name']])?$errors[$last_name['name']]:''; ?></span>
            </div>
            
          </div>
         <div class="form-group form-actions">
            <div class="col-lg-12 text-right">
              <button type="submit" class="btn btn-success pull-right">Save Changes</button>
              <img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id="loader" class="pull-right" style="display: none;margin-right: 5px;"/>
                  
            </div>
          </div>
        <?php echo form_close(); ?>
        
        
        
       
            <hr />
            <h4>Change Password</h4>
            <?php echo form_open(site_url().'/auth/change_password',  array('class'=>'form-horizontal margin-top-20','role'=>'form','id'=>'password_form')); ?>
                                    <div class="form-group">
                                        
                                        <div class="col-lg-12">
                                            <label class="control-label">Current Password</label>
                                          <?php echo form_password($password); ?> 
                                            <span style="color: red;"><?php echo form_error($password['name']); ?><?php echo isset($errors[$password['name']])?$errors[$password['name']]:''; ?></span>
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        
                                        <div class="col-lg-12">
                                            <label class="control-label">New Password</label>
                                          <?php echo form_password($new_password); ?> 
                                            <span style="color: red;"><?php echo form_error($new_password['name']); ?><?php echo isset($errors[$new_password['name']])?$errors[$new_password['name']]:''; ?></span>
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        
                                        <div class="col-lg-12">
                                            <label class="control-label">Confirm New Password</label>
                                          <?php echo form_password($confirm_new_password); ?> 
                                            <span style="color: red;"><?php echo form_error($confirm_new_password['name']); ?><?php echo isset($errors[$confirm_new_password['name']])?$errors[$confirm_new_password['name']]:''; ?></span>
                                        </div>
                                      </div>
                                     
                                        
                                     
                                      
                                      <div class="form-group form-actions">
                                        <div class="col-lg-12 text-right">
                                        <button type="submit" class="btn btn-success pull-right">Change Password</button>
                                        <img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id="loader_pass" class="pull-right" style="display: none;margin-right: 5px;"/>
               
                                        </div>
                                      </div>
            <?php echo form_close(); ?>	
           
           <?php 
           if ($this->tank_auth->is_admin()) {
           ?>
            <hr />
            <h4>Print To Card Settings</h4>
         <?php echo form_open(site_url().'/settings/profile_edit',  array('class'=>'form-horizontal','role'=>'form','id'=>'print_to_card')); ?>
        <div class="form-group">
            
            <div class="col-lg-6">
                <label class="control-label">Margin From Top</label>
              <?php echo form_input($top_margin); ?> 
                <span style="color: red;"><?php echo form_error($top_margin['name']); ?><?php echo isset($errors[$top_margin['name']])?$errors[$top_margin['name']]:''; ?></span>
            </div>
            <div class="col-lg-6">
                <label class="control-label">Margin From Left</label>
              <?php echo form_input($left_margin); ?> 
                 <span style="color: red;"><?php echo form_error($left_margin['name']); ?><?php echo isset($errors[$left_margin['name']])?$errors[$left_margin['name']]:''; ?></span>
            </div>
            
          </div>
         <div class="form-group form-actions">
            <div class="col-lg-12 text-right">
              <button type="submit" class="btn btn-success pull-right">Save Changes</button>
              <img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id="print_to_card_loader" class="pull-right" style="display: none;margin-right: 5px;"/>
                  
            </div>
          </div>
        <?php echo form_close();
        }
         ?>		
        
                <?php 
           if ($this->tank_auth->is_admin()) {
           ?>
            <hr />
            <h4>Quarter Date Setting</h4>
         <?php echo form_open(site_url(),  array('class'=>'form-horizontal','role'=>'form','id'=>'quarter_setting_form')); ?>
        <div class="form-group">
            
            <div class="col-lg-6">
                <label class="control-label">First Quarter</label>
              <?php echo form_dropdown('firstQuarterStartingMonth', $firstQuarterStartingMonth, @$print_settings->first_quarter_starting_month, 'class="form-control " id="firstQuarterStartingMonth" '); ?> 
            </div>
            <div class="col-lg-6">
                <label class="control-label">Second Quarter</label>
              <?php echo form_dropdown('SecondQuarterStartingMonth', $SecondQuarterStartingMonth, @$print_settings->second_quarter_starting_month, 'class="form-control " id="SecondQuarterStartingMonth" '); ?> 
            </div>
            
             <div class="col-lg-6">
                <label class="control-label">Third Quarter</label>
                <?php echo form_dropdown('ThirdQuarterStartingMonth', $ThirdQuarterStartingMonth, @$print_settings->third_quarter_starting_month, 'class="form-control " id="ThirdQuarterStartingMonth" '); ?> 
            </div>
            <div class="col-lg-6">
                <label class="control-label">Forth Quarter</label>
                <?php echo form_dropdown('forthQuarterStartingMonth', $forthQuarterStartingMonth, @$print_settings->forth_quarter_starting_month, 'class="form-control " id="forthQuarterStartingMonth" '); ?> 
            </div>
            
          </div>
         <div class="form-group form-actions">
            <div class="col-lg-12 text-right">
                 <button type="submit" class="btn btn-success pull-right">Save Changes</button>
                  <img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id=quarter_setting_loader" class="pull-right" style="display: none;margin-right: 5px;"/>  
            </div>
          </div>
        <?php echo form_close();
        }
         ?>
            
            
        </div>
        </div>
      </div>
                        
                       
                         
                </section><!-- /.content -->
            </aside><!-- /.right-side -->








<script>


$(document).ready(function(){
    //var regex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     
   $("#basic_form").submit(function(e){
    
     if($.trim($('#first_name').val())==""){
        $('#first_name').css('border','1px solid red');
        $('#first_name').focus();return false;
    }
    else{
       $('#first_name').css('border','1px solid #cccccc');  
    }
    
     if($.trim($('#last_name').val())==""){
        $('#last_name').css('border','1px solid red');
        $('#last_name').focus();return false;
    }
    else{
       $('#last_name').css('border','1px solid #cccccc');  
    }
     
    
    
   
    
    $('#loader').fadeIn();
    var values = $('#basic_form').serialize();
    
    $.ajax({
    url:'<?php echo site_url('settings/profile_edit'); ?>',
    dataType:'json',
    type:'POST',
    data:values,
    success:function(result){
     
     if(result.status==1)
     {
        
        $('#add_user_res').html('<div class="alert alert-success" id="disappear_add"  >'+result.message+'</div>'); 
        setTimeout(function(){$('#disappear_add').fadeOut('slow')},3000)
        $('#loader').fadeOut();
        //$('#basic_form')[0].reset();
        
        
     }
     else
     {
        
        $('#add_user_res').empty().html('<div class="alert alert-danger">'+result.message+'</div>');
        $('#loader').fadeOut();
     } 
     
      
    }
   });
   
    return false;
    });
    
    
    
    //print_to_card
    $("#print_to_card").submit(function(e){
    
     if($.trim($('#top_margin').val())==""){
        $('#top_margin').css('border','1px solid red');
        $('#top_margin').focus();return false;
    }
    else{
       $('#top_margin').css('border','1px solid #cccccc');  
    }
    
     if($.trim($('#left_margin').val())==""){
        $('#left_margin').css('border','1px solid red');
        $('#left_margin').focus();return false;
    }
    else{
       $('#left_margin').css('border','1px solid #cccccc');  
    }
     
    
    $('#print_to_card_loader').fadeIn();
    var values = $('#print_to_card').serialize();
    
    $.ajax({
    url:'<?php echo site_url('settings/update_print_settings'); ?>',
    dataType:'json',
    type:'POST',
    data:values,
    success:function(result){
    
     if(result.status==1)
     {
        
        $('#add_user_res').html('<div class="alert alert-success" id="disappear_add"  >'+result.message+'</div>'); 
        setTimeout(function(){$('#disappear_add').fadeOut('slow')},3000)
        $('#print_to_card_loader').fadeOut();
      }
     else
     {
        
        $('#add_user_res').empty().html('<div class="alert alert-danger">'+result.message+'</div>');
        $('#print_to_card_loader').fadeOut();
     } 
     $('html, body').animate({scrollTop : 0},800);
    }
   });
   
    return false;
    });
    
    //quarter date setting 
    //print_to_card
    $("#quarter_setting_form").submit(function(e){
    
    $('#quarter_setting_loader').fadeIn();
    var values = $('#quarter_setting_form').serialize();
    
    $.ajax({
    url:'<?php echo site_url('settings/update_quarter_settings'); ?>',
    dataType:'json',
    type:'POST',
    data:values,
    success:function(result){
    
     if(result.status==1)
     {
        $('#add_user_res').empty().html('<div class="alert alert-success" id="disappear_add"  >'+result.message+'</div>'); 
      }
     else
     {
        $('#add_user_res').empty().html('<div class="alert alert-danger" id="disappear_add" >'+result.message+'</div>');
     } 
      setTimeout(function(){$('#disappear_add').fadeOut('slow')},3000)
     $('#quarter_setting_loader').fadeOut();
     $('html, body').animate({scrollTop : 0},800);
    }
   });
   
    return false;
    });
    
    
    
    //change password
    
     $("#password_form").submit(function(e){
    
     if($.trim($('#old_password').val())==""){
        $('#old_password').css('border','1px solid red');
        $('#old_password').focus();return false;
    }
    else{
       $('#old_password').css('border','1px solid #cccccc');  
    }
    
     if($.trim($('#new_password').val())==""){
        $('#new_password').css('border','1px solid red');
        $('#new_password').focus();return false;
    }
    else{
       $('#new_password').css('border','1px solid #cccccc');  
    }
    
    
     if($.trim($('#confirm_new_password').val())==0 || $.trim($('#confirm_new_password').val())!=$.trim($('#new_password').val()) )
        {
           $('#confirm_new_password').css('border','2px solid red'); 
           $('#confirm_new_password').focus();
           return false; 
        }
        else
        {
             $('#confirm_new_password').css('border','1px solid #cccccc'); 
        }
    
    
   
    
    $('#loader_pass').fadeIn();
    var values = $('#password_form').serialize();
    
    $.ajax({
    url:'<?php echo site_url('auth/change_password'); ?>',
    dataType:'json',
    type:'POST',
    data:values,
    success:function(result){
     console.log(result);  
     if(result.status==1)
     {
        
        $('#add_user_res').html('<div class="alert alert-success" id="disappear_add"  >'+result.message+'</div>'); 
        setTimeout(function(){$('#disappear_add').fadeOut('slow')},3000)
        $('#loader_pass').fadeOut();
        //$('#basic_form')[0].reset();
        
        
     }
     else
     {
        
        $('#add_user_res').empty().html('<div class="alert alert-danger">'+result.message+'</div>');
        
        $('#loader_pass').fadeOut();
        $('#password_form')[0].reset();
     } 
     
      
    }
   });
   
    return false;
    });
 
});
</script>
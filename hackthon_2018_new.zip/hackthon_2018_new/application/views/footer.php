</div>
		<!-- FOOTER -->
		<footer class="footer">
			<div class="container">
			
				<p  class="text-center">
					&copy; 2014 
                    <br />
                    
					<a href="#">Privacy Policy</a>
					&middot;
					<a href="#">Terms and Conditions </a>
				</p>
			</div>
		</footer>
      
       
		
	</body>

</html>
<?php
if($details)
{
    $date_format = $this->config->item('date_format', 'tank_auth');
   
?>
<style>
#container
{
    width:100%;
}
#customer_details, #card_details, #other_details
{
   border: 1px solid #ccc; 
}

#customer_details td, #card_details td, #other_details td
{
    width: 230px;
    border-top: 1px solid #ccc;
    padding: 5px;
    text-align: left;
}

.heading
{
    text-align: center;background: #eee;padding: 5px;
}

</style>
<page backtop="2mm" backbottom="2mm" backleft="7mm" backright="6mm"> 
<table>
<tr>
<td style="width: 830px;">
<img src="./assets/images/logo.jpg" style="width: 150px;" />
</td>
<td style="text-align: right;">Customer Membership Details</td>
</tr>
</table>

<table id="container">
    <tr>
        <td style="vertical-align: top;">
                <table id="customer_details" class="table table-bordered table-striped table-condensed" >
                <tr>
                <th colspan="4" class="text-center heading">Personal Details</th>
                </tr>
                <tr>
                    <td><strong>Name:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["title"])." ". htmlspecialchars($details[0]["first_name"]); ?></td>
                    
                </tr>
               
                <tr>
                     <td><strong>Last Name:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["last_name"]); ?></td></tr>
                <tr>
                    <td><strong>Gender:</strong></td>
                    <td><?php echo htmlspecialchars(ucfirst($details[0]["gender"])); ?></td>
                    
                </tr>
                <tr>
                    <td><strong>DOB:</strong></td>
                    <td><?php echo date($date_format,strtotime($details[0]["dob"])); ?></td>
                
                </tr>
                <tr>
                    <td><strong>Nationality:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["nationality"]); ?></td>
                    
                </tr>
                <tr>
                <td><strong>Race:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["race"]); ?></td>
                
                </tr>
               <tr>
                    <td><strong>NRIC Number:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["NRIC_no"]); ?></td>
                    
                </tr>
                <tr>
                <td><strong>Passport Number:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["passport_no"]); ?></td>
                
                </tr>
                <tr>
                    <td><strong>Moblie Number:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["mobile"]); ?></td>
                    
                </tr>
                <tr>
                <td><strong>Email:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["email"]); ?></td>
                
                </tr>
                 <tr>
                    <td><strong>Address 1:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["address_1"]); ?></td>
                    
                </tr>
                <tr>
                <td><strong>Address 2:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["address_2"]); ?></td>
                
                </tr>
                 <tr>
                    <td><strong>Address 3:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["address_3"]); ?></td>
                    
                </tr>
                <tr>
                <td><strong>Post Code:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["postcode"]); ?></td>
                
                </tr>
                 <tr>
                    <td><strong>Country:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["country"]); ?></td>
                    
                </tr>
                <tr>
                
                <td><strong>State:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["state"]); ?></td>
                    
                </tr>
                <tr>
                <td><strong>City:</strong></td>
                    <td><?php echo htmlspecialchars($details[0]["city"]); ?></td>
                    
                </tr>
            </table>
        </td>
        <td  style="vertical-align: top;">
        
        <table class="table table-bordered table-striped table-condensed" id="card_details">
        
         <tr>
        
        <th colspan="4" class="text-center heading">Card Details</th>
        </tr>
        
        <tr>
            <td><strong>Parkson Card Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["membership_no"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Member Since:</strong></td>
            <td><?php echo date($date_format,strtotime($details[0]["member_since"])); ?></td>
        </tr>
        <tr>
            <td><strong>Membership Tier:</strong></td>
            <td><?php echo htmlspecialchars(ucfirst($details[0]["membership_tier"])); ?></td>
            
        </tr>
        <tr>
        <td>
            <strong>Card Status:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["card_status"]); ?></td>
        </tr>
        <tr>
            <td><strong>Valid Thru:</strong></td>
            <td><?php echo date($date_format,strtotime($details[0]["valid_thru"])); ?></td>
            
        </tr>
        <tr>
            <td><strong>Member Type :</strong></td>
            <td><?php echo htmlspecialchars(ucfirst($details[0]["membership_type"])); ?></td>
         </tr>
         <tr>
            <td><strong>Membership Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["card_no"]); ?></td>
            
        </tr>
        <tr>
            <td><strong>Bonuslink Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["bonus_link_no"]); ?></td>
         </tr>
         <?php
          if($details[0]["membership_type"]=='supplementary'){
         ?>
         <tr>
            <td><strong>Parent Holder Name:</strong></td>
            <td><?php echo htmlspecialchars($details[1]["p_holder_fname"]." ".$details[1]["p_holder_lname"]); ?></td>
         </tr>
         <tr>
            <td><strong>Parent Card Number:</strong></td>
            <td><?php echo htmlspecialchars($details[1]["p_card_no"]); ?></td>
         </tr>
         <?php } ?>
        <tr>
            <td><strong>Subscribe To Mobile Alert:</strong></td>
            <td><?php if($details[0]["mobile_alert"]==1) echo "Yes"; else echo "NO"; ?></td>
            
        </tr>
        <tr>
            <td><strong>Subscribe To Newsletter:</strong></td>
           <td><?php if($details[0]["newsletter"]==1) echo "Yes"; else echo "NO"; ?></td>
        
        </tr>
        
    </table>
    <br />
    <table id="other_details" class="table table-bordered table-striped table-condensed">
         <tr>
            <th colspan="4" class="text-center heading">Other Details</th>
        </tr>
         <tr>
            <td><strong>Store:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["location_name"]."-".$details[0]["store_code"]); ?></td>
         </tr>
         <tr>
            <td><strong>Captured By:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["staff_fname"]." ".$details[0]["staff_lname"]." (".$details[0]["username"].")"); ?></td>
         </tr>
          <tr>
            <td><strong>Captured On:</strong></td>
            <td><?php echo date($date_format.' H:i:s',strtotime($details[0]["created"])); ?></td>
         </tr>
         <tr>
            <td><strong>Last Modified On:</strong></td>            
            <td><?php if($details[0]["last_modified"]!="" && $details[0]["last_modified"]!='0000-00-00 00:00:00') echo date($date_format.' H:i:s',strtotime($details[0]["last_modified"])); else echo "-"; ?></td>
         </tr>
          <tr>
            <td><strong>Remarks:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["remarks"]); ?></td>
         </tr>
         <tr>
            <td><strong>Company Name:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["company_name"]); ?></td>
         </tr>
    </table>
        </td>
    </tr>
</table>
<br /><br />
<p style="text-align: center;color: #666;"><small>&copy; Copyright 2014. All Rights Reserved.</small></p>

   </page>
 
<?php
}
?>

<?php
if($details)
{
    $date_format = $this->config->item('date_format', 'tank_auth');
    $date_format = 'd-m-Y';
   
?>

<div class="clearfix"></div>

<table class="table table-bordered table-striped table-condensed" >
       <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Parkson Card Number</th>
        
        
        </tr>
        <?php foreach($details as $value){ ?>
        <tr>
                <td><?php echo htmlspecialchars($value["title"])." ". htmlspecialchars($value["first_name"]); ?></td>
                <td><?php echo htmlspecialchars($value["last_name"]); ?></td>
                <td><?php echo htmlspecialchars($value["membership_no"]); ?></td>
                
        </tr>
        <?php } ?>
        </table>
   
    
   
    <div class="clearfix"></div>

<?php } else{ ?>
        <div class="alert alert-danger">No Records Found.</div>
<?php } ?>
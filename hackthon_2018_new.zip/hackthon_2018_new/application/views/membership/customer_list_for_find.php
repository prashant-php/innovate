<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$f_name = array(
    'name' => 'f_name',
    'id' => 'find_f_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'First Name',
);
$l_name = array(
    'name' => 'l_name',
    'id' => 'find_l_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'Last Name',
);
$email = array(
    'name' => 'email',
    'id' => 'find_email',
    'class' => 'form-control input-sm',
    'placeholder' => 'Email Address',
);
$NRIC_no = array(
    'name' => 'NRIC_no ',
    'id' => 'find_NRIC_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'NRIC Number',
);
$mobile_no = array(
    'name' => 'mobile_no',
    'id' => 'find_mobile_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Moblie Number',
);
$passport_no = array(
    'name' => 'passport_no',
    'id' => 'find_passport_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Passport Number',
);

$membership_no = array(
    'name' => 'membership_no',
    'id' => 'Fmembership_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Parkson Card Number',
);

$card_no = array(
    'name' => 'card_no',
    'id' => 'Fcard_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Membership Number',
);


$reg_no = array(
    'name' => 'reg_no',
    'id' => 'Freg_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Registration Form Number',
);

$address = array(
    'name' => 'address',
    'id' => 'find_address',
    'class' => 'form-control input-sm',
    'placeholder' => 'Address',
);
$city = array(
    'name' => 'city',
    'id' => 'find_city',
    'class' => 'form-control input-sm',
    'placeholder' => 'City',
);


?>

    
         <div class="row">
            <div class="col-md-12" class="btn">
               
                    <div id="alert_area"></div> 
                    
                    <div class="adv_search_box" id="adv_search">
                    <?php echo form_open(site_url('membership/customer_list'), array('class' => '', 'role' => 'form', 'id' => 'customer_search_form')); ?>
                      <div class="form-group col-md-2">
                            <label class="control-label">First Name </label>
                            <?php echo form_input($f_name); ?> 
                       </div> 
                      
                       <div class="form-group col-md-2">
                             <label class="control-label">Last Name </label>
                             <?php echo form_input($l_name); ?> 
                      </div>  
                       <div class="form-group col-md-2">
                            <label class="control-label">Email</label>
                             <?php echo form_input($email); ?>
                       </div>
                     <div class="form-group col-md-2">
                            <label class="control-label">Mobile No</label>
                             <?php echo form_input($mobile_no); ?>
                    </div>
                     <div class="form-group col-md-2">
                             <label class="control-label">Address</label>
                             <?php echo form_input($address); ?>
                      </div>  
                       <div class="form-group col-md-2">
                            <label class="control-label">City</label>
                             <?php echo form_input($city); ?>
                       </div>
                    <div class="clearfix"></div>
                    
                     <div class="form-group col-md-2">
                            <label class="control-label">Parkson Card Number</label>
                             <?php echo form_input($membership_no); ?>
                       </div>
                        <div class="form-group col-md-2">
                            <label class="control-label">Membership Number</label>
                             <?php echo form_input($card_no); ?>
                       </div>
                       <div class="form-group col-md-2">
                            <label class="control-label">Registration Form Number</label>
                             <?php echo form_input($reg_no); ?>
                       </div>
                    <div class="form-group col-md-2">
                            <label class="control-label">NRIC </label>
                            <?php echo form_input($NRIC_no); ?> 
                       </div> 
                       <div class="form-group col-md-2">
                             <label class="control-label">Passport No </label>
                             <?php echo form_input($passport_no); ?> 
                      </div>  
                      
                      
                     <div class="form-group col-md-2">
                     <br />
                    <input type="submit" name='search_customer' id='search_customer' class="btn btn-primary pull-right " value="Search"/>
                     </div>
                    <div class="clearfix"></div>
                    <?php echo form_close(); ?>                   
                  </div>  
                   <div class="clearfix"></div> 
                    <table id="find_ajax_datatable" class="table table-bordered table-hover table-condensed dataTable">
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th style="width: 220px;">Parkson Card Number</th>
                                <th>Membership Number</th>
                                <th style="width: 200px;">Registration Form Number</th>
                                <th style="width: 150px;">Creation Date</th>
                                <th style="width: 150px;">Expiration Date</th>
                                <th style="width: 50px;">Actions</th>
                             </tr>
                        </thead>
                    </table>
                </div>
            </div>
       
<div class="clearfix"></div>
<script>
    var months = new Array(12);
        months[1] = "January";
        months[2] = "February";
        months[3] = "March";
        months[4] = "April";
        months[5] = "May";
        months[6] = "June";
        months[7] = "July";
        months[8] = "August";
        months[9] = "September";
        months[10] = "October";
        months[11] = "November";
        months[12] = "December";
    
    
    $(document).ready(function () {
        $('#progress').hide();
        var f_name = 0;
        var l_name = 0;
        var email = 0;
        var find_NRIC_no = 0;
        var mobile_no = 0;
        var passport_no = 0;
        
        var membership_no = 0;
        var card_no = 0;
        var reg_no = 0;
        
        var address = 0;
        var city = 0;
       
        find_ajax_datatable = $('table#find_ajax_datatable').dataTable({
            "bServerSide": true,
            "sAjaxSource": "<?php echo site_url('membership/get_cutomer_list_for_find'); ?>"+'/'+<?php echo $current_user; ?>,
            "sPaginationType": "full_numbers",
             "fnServerData": function (sSource, aoData, fnCallback)
            {
                $('#loader1').show();
                aoData.push({name: "Ff_name", value: f_name});
                aoData.push({name: "Fl_name", value: l_name});
                aoData.push({name: "Femail", value: email});
                aoData.push({name: "Fmobile_no", value: mobile_no});
                aoData.push({name: "Faddress", value: address});
                aoData.push({name: "Fcity", value: city});
                
                aoData.push({name: "Fmembership_no", value: membership_no});
                aoData.push({name: "Fcard_no", value: card_no});
                aoData.push({name: "Freg_no", value: reg_no});
                
                aoData.push({name: "FNRIC_no", value: find_NRIC_no});
                aoData.push({name: "Fpassport_no", value: passport_no});
                
                
                $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": sSource,
                    "data": aoData,
                    "success": fnCallback
                });
            },
            "fnDrawCallback": function () {
                $('#loader1').fadeOut();
            },
            "fnRowCallback": function (nRow, aData, iDisplayIndex) {
               

              var links = "";

              links += '<a href="#" data-customer_id="' + aData[7] + '"  data-name="' + aData[0]+" "+aData[1] + '" data-card_no="' + aData[2] + '"  title="Select Member" class="btn btn-success btn-xs select_member" style="margin-right:5px;" ><span class="fa fa-check"></span></a>';
              $('td:eq(7)', nRow).html(links);

                var dateSplit = aData[5].split("-");
                day = dateSplit[2].split(' ');
                var curr_date = day[0];
                
                if(dateSplit[1].replace(/^0+/, '').length=="1")
                dateSplit[1]= dateSplit[1].replace(/^0+/, '');
                var curr_month = months[dateSplit[1]]; //Months are zero based
                var curr_year = dateSplit[0];
                $('td:eq(5)', nRow).html(curr_date + " " + curr_month + " " + curr_year);
              
                var dateSplit = aData[6].split("-");
                day = dateSplit[2].split(' ');
                var curr_date = day[0];
                var curr_month = months[dateSplit[1]]; //Months are zero based
                var curr_year = dateSplit[0];
                $('td:eq(6)', nRow).html(curr_month + " " + curr_year);

                return nRow;
            },
         
             
        });
    
    $(document).on('submit','#customer_search_form',function(e){
    e.preventDefault();
    
    f_name = $("#find_f_name").val();
    l_name = $("#find_l_name").val();
    email =$("#find_email").val();
    find_NRIC_no =$("#find_NRIC_no").val();
    mobile_no = $("#find_mobile_no").val();
    passport_no =$("#find_passport_no").val();
    
    membership_no = $("#Fmembership_no").val();
    card_no = $("#Fcard_no").val();
    reg_no = $("#Freg_no").val();
    
    address = $("#find_address").val();
    city = $("#find_city").val();
    
    
    find_ajax_datatable.fnDraw();
   
   })
   
   
    $('#find_ajax_datatable_filter input')
    .unbind('keypress keyup')
    .bind('keyup', function(e){
      if ($(this).val().length >= 3 && e.keyCode == 13)
      find_ajax_datatable.fnFilter($(this).val());
      else return true;
    });
    
   
   
});

</script>        
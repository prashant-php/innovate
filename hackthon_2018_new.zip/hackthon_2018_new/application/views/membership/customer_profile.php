<?php
$name_title = array(
    'Mr' => 'Mr',
    'Mrs' => 'Mrs',
    'Ms' => 'Ms',
   
);

$security_question_1 = array(
    '0' => '--Security Question--',
    '1' => 'Where did you go the first time you flew on a plane?',
    '2' => 'What is the last name of your favorite elementary school teacher?',
    '3' => 'What is your favorite children’s book?',
    '4' => 'In what city did your parents meet?',
    '5' => 'Who has gifted you the first watch?'
);
$security_question_2 = array(
    '0' => '--Security Question--',
    '1' => 'Where did you go the first time you flew on a plane?',
    '2' => 'What is the last name of your favorite elementary school teacher?',
    '3' => 'What is your favorite children’s book?',
    '4' => 'In what city did your parents meet?',
    '5' => 'Who has gifted you the first watch?'
);
$security_question_3 = array(
    '0' => '--Security Question--',
    '1' => 'Where did you go the first time you flew on a plane?',
    '2' => 'What is the last name of your favorite elementary school teacher?',
    '3' => 'What is your favorite children’s book?',
    '4' => 'In what city did your parents meet?',
    '5' => 'Who has gifted you the first watch?'
);
$project_on_working = array(
    '0' => '--Department--',
    'Technology' => 'Technology',
    'IT' => 'IT',
    'Admin' => 'Admin',
    'Finance' => 'Finance',
);


$f_name = array(
    'name' => 'f_name',
    'id' => 'f_name',
    'class' => 'form-control',
    'value' => set_value('f_name'),
    'placeholder' => 'First Name'
    
); 

 


$custome_race = array(
    'name' => 'custome_race',
    'id' => 'custome_race',
    'class' => 'form-control',
    'value' => set_value('custome_race'),
    'placeholder' => 'Other Race'
);
        
        
$l_name = array(
    'name' => 'l_name',
    'id' => 'l_name',
    'class' => 'form-control',
    'placeholder' => 'Last Name',
    'value' => set_value('l_name')    
);





$dob = array(
    'name' => 'dob',
    'id' => 'dob',
    'class' => 'form-control',
    'placeholder' => 'Date Of Birth',
    'readonly' => 'readonly'
);
$password = array(
    'name' => 'password',
    'id' => 'password',
    'class' => 'form-control',
    'placeholder' => 'Password',
    'readonly' => 'readonly'
);

$currentDate =  time();



$answer_1 = array(
    'name' => 'answer_1',
    'id' => 'answer_2',
    'class' => 'form-control',
    'placeholder' => 'Answer',
    //'readonly' => 'readonly',
    //'value' => date('m-Y',time())
);
$answer_2 = array(
    'name' => 'answer_2',
    'id' => 'answer_2',
    'class' => 'form-control',
    'placeholder' => 'Answer',
    //'readonly' => 'readonly',
    //'value' => date('m-Y',time())
);
$answer_3 = array(
    'name' => 'answer_3',
    'id' => 'answer_3',
    'class' => 'form-control',
    'placeholder' => 'Answer',
    //'readonly' => 'readonly',
    //'value' => date('m-Y',time())
);





        








$address_1 = array(
    'name' => 'address_1',
    'id' => 'address_1',
    'class' => 'form-control',
    'placeholder' => 'Address',
    'onblur' => 'required_validation(this.id)',
    'value' => set_value('address_1'),
);
$address_2 = array(
    'name' => 'address_2',
    'id' => 'address_2',
    'class' => 'form-control',
    'placeholder' => 'Address',
);

$address_3 = array(
    'name' => 'address_3',
    'id' => 'address_3',
    'class' => 'form-control',
    'placeholder' => 'Address',
);






$post_code = array(
    'name' => 'post_code',
    'id' => 'post_code',
    'class' => 'form-control',
    'placeholder' => 'Post Code',
);


$city = array(
    'name' => 'city',
    'id' => 'city',
    'class' => 'form-control',
    'placeholder' => 'City',
);
$state = array(
    'name' => 'state',
    'id' => 'state',
    'class' => 'form-control hide',
    'placeholder' => 'State',
);



$email = array(
    'name' => 'email',
    'id' => 'email',
    'class' => 'form-control',
    'placeholder' => 'Email',
    'value' => set_value('email'),
);

$mobile_num_1 = array(
    'name' => 'mobile_num_1',
    'id' => 'mobile_num_1',
    'class' => 'form-control',
    'placeholder' => 'Code',
    'value' => set_value('mobile_num_1'),
    'maxlength' => '4'
);

$mobile_num_2 = array(
    'name' => 'mobile_num_2',
    'id' => 'mobile_num_2',
    'class' => 'form-control',
    'placeholder' => 'Number',
    'value' => set_value('mobile_num_2'),
    'maxlength' => '8'
);






$malaysian_states = array(
    "0" => '--Select State--',
    'AP' => 'Andhra Pradesh',
'AR' => 'Arunachal Pradesh',
'AS' => 'Assam',
'BR' => 'Bihar',
'CT' => 'Chhattisgarh',
'GA' => 'Goa',
'GJ' => 'Gujarat',
'HR' => 'Haryana',
'HP' => 'Himachal Pradesh',
'JK' => 'Jammu and Kashmir',
'JH' => 'Jharkhand',
'KA' => 'Karnataka',
'KL' => 'Kerala',
'MP' => 'Madhya Pradesh',
'MH' => 'Maharashtra',
'MN' => 'Manipur',
'ML' => 'Meghalaya',
'MZ' => 'Mizoram',
'NL' => 'Nagaland',
'OR' => 'Odisha',
'PB' => 'Punjab',
'RJ' => 'Rajasthan',
'SK' => 'Sikkim',
'TN' => 'Tamil Nadu',
'TG' => 'Telangana',
'TR' => 'Tripura',
'UT' => 'Uttarakhand',
'UP' => 'Uttar Pradesh',
'WB' => 'West Bengal',
'AN' => 'Andaman and Nicobar Islands',
'CH' => 'Chandigarh',
'DN' => 'Dadra and Nagar Haveli',
'DD' => 'Daman and Diu',
'DL' => 'Delhi',
'LD' => 'Lakshadweep',
'PY' => 'Puducherry',
    );

$company_name = array(
    'name' => 'company_name',
    'id' => 'company_name',
    'class' => 'form-control',
    'value' => set_value('company_name'),
    'placeholder' => 'Company Name',
    'maxlength' => '100'
); 



?>
<noscript>
	<h3 style="margin-left: 230px;">JavaScript is disabled! Please enable JavaScript in your web browser.</h3>
    <style type="text/css">
		.right-side { display:none; }
	</style>
</noscript>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">                
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
<?php echo @$title; ?>
            <img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id="progress" class="hidden" />
        </h1>
    </section>
    <div class="clearfix"></div>
    
    <!-- Main content -->
    <section class="content">
<div class="row">
            <div class="col-md-12">
                <div class="well-lg" style="overflow: auto;">
                    <div id="alert_area_bonus_err"></div> 
                    <div id="alert_area_frm"></div> 
                    <?php echo form_open(site_url('membership/add_customer'), array('class' => 'form-horizontal', 'role' => 'form', 'id' => 'customer_profile_form')); ?>
                   
                   <div class="col-md-6 padding-left-none" id="form_left_section">
                   <div class="form-group">
                        <div class="col-lg-2 padding-right-none" >
                            <label class="control-label">Title</label>
                            <?php echo form_dropdown('title', $name_title, 'Mr', "class=form-control id=title style=padding:0px;font-size:12px;  "); ?> 
                        </div>
                        <div class="col-lg-3 padding-right-none">
                            <label class="control-label">Name*</label>
                            <?php echo form_input($f_name); ?> 
                            <span style="color: red;"><?php echo form_error($f_name['name']); ?><?php echo isset($errors[$f_name['name']]) ? $errors[$f_name['name']] : ''; ?> </span>
                        </div>
                        <div class="col-lg-3 padding-left-none">
                            <label class="control-label">&nbsp;</label>
                            <?php echo form_input($l_name); ?> 
                            <span style="color: red;"><?php echo form_error($l_name['name']); ?><?php echo isset($errors[$l_name['name']]) ? $errors[$l_name['name']] : ''; ?> </span>
                        </div>
                      
                          
                         
                     </div><!-- form-group -->
                 
                    
                    
                     
                     
                     <div class="clearfix"></div>
                     <div class="form-group">
                        <div class="col-lg-6">
                            <label class="control-label ">Gender*</label>
                            <div class="clearfix"></div>
                           <label class="radio-inline">
                              <?php echo form_radio('gender', 'male', true,'id="gender_male"'); ?> Male
                            </label>
                            <label class="radio-inline">
                              <?php echo form_radio('gender', 'female',false,'id="gender_female"'); ?> Female
                            </label>
                          <span style="color: red;"><?php echo form_error('gender'); ?><?php echo isset($errors['gender']) ? $errors['gender'] : ''; ?></span>
                        </div>
                        <div class="col-lg-6">
                            <label class="control-label">Date Of Birth</label>
                            <?php echo form_input($dob); ?> 
                        </div>
                        
                       
                    </div>
                     
                     
                    <div class="form-group">
                        <div class="col-lg-6">
                            <label class="control-label">Mobile Number</label>
                            <div class="row">
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-4 padding-right-none"><?php echo form_input($mobile_num_1); ?></div>
                            <div class="col-md-8 col-sm-8 col-lg-8 col-xs-8 padding-left-none"><?php echo form_input($mobile_num_2); ?></div>
                            </div>
                            <span style="color: red;">
                                <?php echo form_error($mobile_num_1['name']); ?><?php echo isset($errors[$mobile_num_1['name']]) ? $errors[$mobile_num_1['name']] : ''; ?>
                                <?php echo form_error($mobile_num_2['name']); ?><?php echo isset($errors[$mobile_num_2['name']]) ? $errors[$mobile_num_2['name']] : ''; ?>
                            </span>
                        </div>
                        
                        <div class="col-lg-6">
                        <label class="control-label">Email</label>
                            <?php echo form_input($email); ?> 
                            <span style="color: red;"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']]) ? $errors[$email['name']] : ''; ?></span>
                        </div>
                     </div> <!-- form-group -->  
                    
                      
                    
                        
                    
                     <div class="form-group">
                        <div class="col-lg-6">
                            <label class="control-label">Address 1*</label>
<?php echo form_input($address_1); ?> 
                            <span style="color: red;"><?php echo form_error($address_1['name']); ?><?php echo isset($errors[$address_1['name']]) ? $errors[$address_1['name']] : ''; ?></span>
                        </div>
                        <div class="col-lg-6">
                            <label class="control-label">Address 2</label>
<?php echo form_input($address_2); ?> 
                        </div>
                    </div> 
                    <div class="form-group">
                    
                        <div class="col-lg-8">
                            <label class="control-label">Address 3</label>
<?php echo form_input($address_3); ?> 
                        </div>
                        <div class="col-lg-4">
                            <label class="control-label">Post Code </label>
<?php echo form_input($post_code); ?> 
                        </div>
                      </div>   <!-- form-group -->       
                      
                       <div class="form-group">
                        <div class="col-lg-4">
                            <label class="control-label">Country  </label>


<select name="country" id="country" class="form-control">
    <option value="Afghanistan">Afghanistan</option>
    <option value="Albania">Albania</option>
    <option value="Algeria">Algeria</option>
    <option value="American Samoa">American Samoa</option>
    <option value="Andorra">Andorra</option>
    <option value="Angola">Angola</option>
    <option value="Anguilla">Anguilla</option>
    <option value="Antartica">Antarctica</option>
    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
    <option value="Argentina">Argentina</option>
    <option value="Armenia">Armenia</option>
    <option value="Aruba">Aruba</option>
    <option value="Australia">Australia</option>
    <option value="Austria">Austria</option>
    <option value="Azerbaijan">Azerbaijan</option>
    <option value="Bahamas">Bahamas</option>
    <option value="Bahrain">Bahrain</option>
    <option value="Bangladesh">Bangladesh</option>
    <option value="Barbados">Barbados</option>
    <option value="Belarus">Belarus</option>
    <option value="Belgium">Belgium</option>
    <option value="Belize">Belize</option>
    <option value="Benin">Benin</option>
    <option value="Bermuda">Bermuda</option>
    <option value="Bhutan">Bhutan</option>
    <option value="Bolivia">Bolivia</option>
    <option value="Bosnia and Herzegowina">Bosnia and Herzegowina</option>
    <option value="Botswana">Botswana</option>
    <option value="Bouvet Island">Bouvet Island</option>
    <option value="Brazil">Brazil</option>
    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
    <option value="Brunei Darussalam">Brunei Darussalam</option>
    <option value="Bulgaria">Bulgaria</option>
    <option value="Burkina Faso">Burkina Faso</option>
    <option value="Burundi">Burundi</option>
    <option value="Cambodia">Cambodia</option>
    <option value="Cameroon">Cameroon</option>
    <option value="Canada">Canada</option>
    <option value="Cape Verde">Cape Verde</option>
    <option value="Cayman Islands">Cayman Islands</option>
    <option value="Central African Republic">Central African Republic</option>
    <option value="Chad">Chad</option>
    <option value="Chile">Chile</option>
    <option value="China">China</option>
    <option value="Christmas Island">Christmas Island</option>
    <option value="Cocos Islands">Cocos (Keeling) Islands</option>
    <option value="Colombia">Colombia</option>
    <option value="Comoros">Comoros</option>
    <option value="Congo">Congo</option>
    <option value="Congo">Congo, the Democratic Republic of the</option>
    <option value="Cook Islands">Cook Islands</option>
    <option value="Costa Rica">Costa Rica</option>
    <option value="Cota D'Ivoire">Cote d'Ivoire</option>
    <option value="Croatia">Croatia (Hrvatska)</option>
    <option value="Cuba">Cuba</option>
    <option value="Cyprus">Cyprus</option>
    <option value="Czech Republic">Czech Republic</option>
    <option value="Denmark">Denmark</option>
    <option value="Djibouti">Djibouti</option>
    <option value="Dominica">Dominica</option>
    <option value="Dominican Republic">Dominican Republic</option>
    <option value="East Timor">East Timor</option>
    <option value="Ecuador">Ecuador</option>
    <option value="Egypt">Egypt</option>
    <option value="El Salvador">El Salvador</option>
    <option value="Equatorial Guinea">Equatorial Guinea</option>
    <option value="Eritrea">Eritrea</option>
    <option value="Estonia">Estonia</option>
    <option value="Ethiopia">Ethiopia</option>
    <option value="Falkland Islands">Falkland Islands (Malvinas)</option>
    <option value="Faroe Islands">Faroe Islands</option>
    <option value="Fiji">Fiji</option>
    <option value="Finland">Finland</option>
    <option value="France">France</option>
    <option value="France Metropolitan">France, Metropolitan</option>
    <option value="French Guiana">French Guiana</option>
    <option value="French Polynesia">French Polynesia</option>
    <option value="French Southern Territories">French Southern Territories</option>
    <option value="Gabon">Gabon</option>
    <option value="Gambia">Gambia</option>
    <option value="Georgia">Georgia</option>
    <option value="Germany">Germany</option>
    <option value="Ghana">Ghana</option>
    <option value="Gibraltar">Gibraltar</option>
    <option value="Greece">Greece</option>
    <option value="Greenland">Greenland</option>
    <option value="Grenada">Grenada</option>
    <option value="Guadeloupe">Guadeloupe</option>
    <option value="Guam">Guam</option>
    <option value="Guatemala">Guatemala</option>
    <option value="Guinea">Guinea</option>
    <option value="Guinea-Bissau">Guinea-Bissau</option>
    <option value="Guyana">Guyana</option>
    <option value="Haiti">Haiti</option>
    <option value="Heard and McDonald Islands">Heard and Mc Donald Islands</option>
    <option value="Holy See">Holy See (Vatican City State)</option>
    <option value="Honduras">Honduras</option>
    <option value="Hong Kong">Hong Kong</option>
    <option value="Hungary">Hungary</option>
    <option value="Iceland">Iceland</option>
    <option value="India" selected>India</option>
    <option value="Indonesia">Indonesia</option>
    <option value="Iran">Iran (Islamic Republic of)</option>
    <option value="Iraq">Iraq</option>
    <option value="Ireland">Ireland</option>
    <option value="Israel">Israel</option>
    <option value="Italy">Italy</option>
    <option value="Jamaica">Jamaica</option>
    <option value="Japan">Japan</option>
    <option value="Jordan">Jordan</option>
    <option value="Kazakhstan">Kazakhstan</option>
    <option value="Kenya">Kenya</option>
    <option value="Kiribati">Kiribati</option>
    <option value="Democratic People's Republic of Korea">Korea, Democratic People's Republic of</option>
    <option value="Korea">Korea, Republic of</option>
    <option value="Kuwait">Kuwait</option>
    <option value="Kyrgyzstan">Kyrgyzstan</option>
    <option value="Lao">Lao People's Democratic Republic</option>
    <option value="Latvia">Latvia</option>
    <option value="Lebanon">Lebanon</option>
    <option value="Lesotho">Lesotho</option>
    <option value="Liberia">Liberia</option>
    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
    <option value="Liechtenstein">Liechtenstein</option>
    <option value="Lithuania">Lithuania</option>
    <option value="Luxembourg">Luxembourg</option>
    <option value="Macau">Macau</option>
    <option value="Macedonia">Macedonia, The Former Yugoslav Republic of</option>
    <option value="Madagascar">Madagascar</option>
    <option value="Malawi">Malawi</option>
    <option value="Malaysia">Malaysia</option>
    <option value="Maldives">Maldives</option>
    <option value="Mali">Mali</option>
    <option value="Malta">Malta</option>
    <option value="Marshall Islands">Marshall Islands</option>
    <option value="Martinique">Martinique</option>
    <option value="Mauritania">Mauritania</option>
    <option value="Mauritius">Mauritius</option>
    <option value="Mayotte">Mayotte</option>
    <option value="Mexico">Mexico</option>
    <option value="Micronesia">Micronesia, Federated States of</option>
    <option value="Moldova">Moldova, Republic of</option>
    <option value="Monaco">Monaco</option>
    <option value="Mongolia">Mongolia</option>
    <option value="Montserrat">Montserrat</option>
    <option value="Morocco">Morocco</option>
    <option value="Mozambique">Mozambique</option>
    <option value="Myanmar">Myanmar</option>
    <option value="Namibia">Namibia</option>
    <option value="Nauru">Nauru</option>
    <option value="Nepal">Nepal</option>
    <option value="Netherlands">Netherlands</option>
    <option value="Netherlands Antilles">Netherlands Antilles</option>
    <option value="New Caledonia">New Caledonia</option>
    <option value="New Zealand">New Zealand</option>
    <option value="Nicaragua">Nicaragua</option>
    <option value="Niger">Niger</option>
    <option value="Nigeria">Nigeria</option>
    <option value="Niue">Niue</option>
    <option value="Norfolk Island">Norfolk Island</option>
    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
    <option value="Norway">Norway</option>
    <option value="Oman">Oman</option>
    <option value="Pakistan">Pakistan</option>
    <option value="Palau">Palau</option>
    <option value="Panama">Panama</option>
    <option value="Papua New Guinea">Papua New Guinea</option>
    <option value="Paraguay">Paraguay</option>
    <option value="Peru">Peru</option>
    <option value="Philippines">Philippines</option>
    <option value="Pitcairn">Pitcairn</option>
    <option value="Poland">Poland</option>
    <option value="Portugal">Portugal</option>
    <option value="Puerto Rico">Puerto Rico</option>
    <option value="Qatar">Qatar</option>
    <option value="Reunion">Reunion</option>
    <option value="Romania">Romania</option>
    <option value="Russia">Russian Federation</option>
    <option value="Rwanda">Rwanda</option>
    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
    <option value="Saint LUCIA">Saint LUCIA</option>
    <option value="Saint Vincent">Saint Vincent and the Grenadines</option>
    <option value="Samoa">Samoa</option>
    <option value="San Marino">San Marino</option>
    <option value="Sao Tome and Principe">Sao Tome and Principe</option> 
    <option value="Saudi Arabia">Saudi Arabia</option>
    <option value="Senegal">Senegal</option>
    <option value="Seychelles">Seychelles</option>
    <option value="Sierra">Sierra Leone</option>
    <option value="Singapore">Singapore</option>
    <option value="Slovakia">Slovakia (Slovak Republic)</option>
    <option value="Slovenia">Slovenia</option>
    <option value="Solomon Islands">Solomon Islands</option>
    <option value="Somalia">Somalia</option>
    <option value="South Africa">South Africa</option>
    <option value="South Georgia">South Georgia and the South Sandwich Islands</option>
    <option value="Span">Spain</option>
    <option value="SriLanka">Sri Lanka</option>
    <option value="St. Helena">St. Helena</option>
    <option value="St. Pierre and Miguelon">St. Pierre and Miquelon</option>
    <option value="Sudan">Sudan</option>
    <option value="Suriname">Suriname</option>
    <option value="Svalbard">Svalbard and Jan Mayen Islands</option>
    <option value="Swaziland">Swaziland</option>
    <option value="Sweden">Sweden</option>
    <option value="Switzerland">Switzerland</option>
    <option value="Syria">Syrian Arab Republic</option>
    <option value="Taiwan">Taiwan, Province of China</option>
    <option value="Tajikistan">Tajikistan</option>
    <option value="Tanzania">Tanzania, United Republic of</option>
    <option value="Thailand">Thailand</option>
    <option value="Togo">Togo</option>
    <option value="Tokelau">Tokelau</option>
    <option value="Tonga">Tonga</option>
    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
    <option value="Tunisia">Tunisia</option>
    <option value="Turkey">Turkey</option>
    <option value="Turkmenistan">Turkmenistan</option>
    <option value="Turks and Caicos">Turks and Caicos Islands</option>
    <option value="Tuvalu">Tuvalu</option>
    <option value="Uganda">Uganda</option>
    <option value="Ukraine">Ukraine</option>
    <option value="United Arab Emirates">United Arab Emirates</option>
    <option value="United Kingdom">United Kingdom</option>
    <option value="United States">United States</option>
    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
    <option value="Uruguay">Uruguay</option>
    <option value="Uzbekistan">Uzbekistan</option>
    <option value="Vanuatu">Vanuatu</option>
    <option value="Venezuela">Venezuela</option>
    <option value="Vietnam">Viet Nam</option>
    <option value="Virgin Islands (British)">Virgin Islands (British)</option>
    <option value="Virgin Islands (U.S)">Virgin Islands (U.S.)</option>
    <option value="Wallis and Futana Islands">Wallis and Futuna Islands</option>
    <option value="Western Sahara">Western Sahara</option>
    <option value="Yemen">Yemen</option>
    <option value="Yugoslavia">Yugoslavia</option>
    <option value="Zambia">Zambia</option>
    <option value="Zimbabwe">Zimbabwe</option>
</select>
                        </div>
                        <div class="col-lg-4">
                            <label class="control-label">State  </label>
                            <?php echo form_input($state); ?> 
                            <?php echo form_dropdown('m_state', $malaysian_states, '', "class=form-control id=m_state"); ?> 
                        </div>
                        <div class="col-lg-4">
                            <label class="control-label">City</label>
<?php echo form_input($city); ?> 
                        </div>
                        
                        
                        
                    </div>  <!-- form-group -->   
                   </div><!-- col-md-6 -->
                   
                   
                   <div class="col-md-6 padding-right-none">
                       
                         <div class="form-group hide">
                            
                             <div class="col-lg-6 pull-right">
                            <label class="control-label">Registration Form Number </label>
                             <?php echo form_input($registration_num); ?> 
                             </div>
                             
                              
                        
                        </div><!-- form-group -->
                        
                        <div class="form-group">
                         
                      
                        <div class="col-md-6">
                                <label class="control-label">Security Question*</label>
                                <?php echo form_dropdown('security-question-1', $security_question_1, '0', "class=form-control id=securtiy-question-1 onblur=required_validation(this.id)"); ?>  
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Answer*  </label>
                            <?php echo form_input($answer_1); ?> 
                            </div>
                     </div>
                      <div class="clearfix"></div>
                         <div class="form-group">
                         
                      
                        <div class="col-md-6">
                                <label class="control-label">Security Question*</label>
                                <?php echo form_dropdown('security-question-2', $security_question_2, '0', "class=form-control id=securtiy-question-2 onblur=required_validation(this.id)"); ?>  
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Answer*  </label>
                            <?php echo form_input($answer_2); ?> 
                            </div>
                     </div>
                      <div class="clearfix"></div>
                       <div class="form-group">
                         
                      
                        <div class="col-md-6">
                                <label class="control-label">Security Question*</label>
                                <?php echo form_dropdown('security-question-3', $security_question_3, '0', "class=form-control id=securtiy-question-3 onblur=required_validation(this.id)"); ?>  
                         </div>
                        <div class="col-md-6">
                            <label class="control-label">Answer*  </label>
                            <?php echo form_input($answer_3); ?> 
                            </div>
                     </div>
                      <div class="clearfix"></div>
                         <div class="form-group">
                         
                      
                        <div class="col-md-6">
                                <label class="control-label">Project*</label>
                                <?php echo form_dropdown('project_on_working', $project_on_working, '0', "class=form-control id=project_on_working onblur=required_validation(this.id)"); ?>  
                        </div>
                            
                     </div>
                      <div class="clearfix"></div>
                        <div class="form-group">
                        <div class="col-lg-9">
                            <label class="control-label">Password*</label>
                            <?php echo form_input($password); ?> 
                            <span style="color: red;"><?php echo form_error($password['name']); ?><?php echo isset($errors[$password['name']]) ? $errors[$password['name']] : ''; ?> </span>
                        </div>
                        <div class="col-lg-3">
			    <input type="submit" name='gernerate_password' id='generate_password' class="btn btn-success pull-right" value="Generate"/>
                            <img src="<?php echo base_url('assets/images/loading.gif'); ?>" class="pull-right" id="password_progress" style="margin-right: 5px; display: none;">
                      
                        </div>
                        </div>
                       
                     
                     
                    
                    
                     
                    <div class="clearfix"></div>
               
                    
                    
                    
                     </div><!-- col-md-6 -->  
                     
                    
                   
                  
  
           
                   <div class="clearfix"></div>
                    <div class="form-group form-actions">
                        <div class="col-lg-12">
                           <input type="submit" name='add_location' id='add_location' class="btn btn-success pull-right" value="Save"/>
                            <img src="<?php echo base_url('assets/images/loading.gif'); ?>" class="pull-right" id="sub_progress" style="margin-right: 5px; display: none;">
                      
                        </div>
                        <div class="clearfix"></div>
                    </div>






<?php echo form_close(); ?>
                </div>

            </div>

        </div>
    </section><!-- /.content -->
</aside><!-- /.right-side -->


<div class="modal fade" id="generatePasswordModel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width: 90%;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Find Membership</h4>
      </div>
      <div class="modal-body">
        <div id="find_response"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script src="<?php echo base_url('assets/js/moment.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.mask.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>
<script>

var ajaxInProgress = false;

    $(function () {
        $("#dob").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            yearRange: "-100:+0",
            maxDate:new Date(<?php echo (date('Y',time())-18); ?>,11,31),
             showButtonPanel: true
           });
        
        
         
  check_for_malaysian();   
  
  //prevent enter key 
  $('#membership_num').keypress(function(event) {
        if (event.keyCode == 13) {
            event.preventDefault();
        }
    });
    
   $('#Bonuslink_num').keypress(function(event) {
        if (event.keyCode == 13) {
            event.preventDefault();
        }
   });
      
    
    
  });

  
   $(document).on('click', '#member_type_supplementary', function (e) {
        $('#find_primary_men_holder').show();
        $('#parent_card').slideDown('fast');
        
    });

    $(document).on('click', '#member_type_primary', function (e) {
        $('#find_primary_men_holder').hide();
        $('#parent_card').slideUp('fast');
    });

   
   
    function bonuslink_validation()
    {
        var Bonuslink_num = $.trim($('#Bonuslink_num').val());
        if ( Bonuslink_num.length > 0) {
              if ( Bonuslink_num.length > 16) {
                    $('#Bonuslink_num').css('border', '1px solid red');
                    $('#Bonuslink_num').focus();
                    return false;
                }
                else {
                    $('#Bonuslink_num').css('border', '1px solid #cccccc');
                    return true;
                }
      }
      else {
        $('#Bonuslink_num').css('border', '1px solid #cccccc');
        return true;
      }             
    }

    function email_validation(id)
    {
        
        var el_val = $.trim($("#" + id).val());
        if (el_val == "" || el_val == 0){ 
        $("#" + id).css('border', '1px solid red');
        return false;
        }
           
            var atpos = el_val.indexOf("@");
            var dotpos = el_val.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= el_val.length) {
                $("#" + id).css('border', '1px solid red');
                return false;
            }
            else
            {
                $("#" + id).css('border', '1px solid #cccccc');
                 return true;
            }
        
    }

    function mobile_validaton(id)
    {
        var el_val = $.trim($("#" + id).val());
       
            if (el_val == "" || el_val == 0) 
            {
                $("#" + id).css('border', '1px solid red');
                return false;
            }
            else
            {
                $("#" + id).css('border', '1px solid #cccccc');
                return true;
            }
       
    }
    
    function passport_validaton()
    {
        var el_val = $.trim($("#passport_num").val());
       
            if (el_val == "" || el_val == 0) 
            {
                $("#passport_num").css('border', '1px solid red');
                return false;
            }
            else
            {
                $("#passport_num").css('border', '1px solid #cccccc');
                return true;
            }
       
    }
    
function required_validation( id )
{
    if(typeof id==='string')
    var id = [id];
    var bad = 0;
     $.each(id,function(i){
       // alert(id[i]);
         var el_val = $.trim($("#" + id[i]).val());
        if (el_val == "" || el_val == 0) {
            $("#" + id[i]).css('border', '1px solid red');
            bad =1;
        }
        else {
            $("#" + id[i]).css('border', '1px solid #cccccc');
            
             //auto fill dob on the basis on NRIC1
             //if we have got a perfect 6, then we will autofill DOB
             if(id[i]=='nric_num_1' && el_val.length==6) {
                    var nric_1_val = $.trim($('#nric_num_1').val());
                    var year = String(19)+ String(nric_1_val[0])+String(nric_1_val[1]);
                    var month = parseInt(String(nric_1_val[2])+String(nric_1_val[3]));
                    var day = String(nric_1_val[4])+String(nric_1_val[5]);
                    $('#dob').val(day+"-"+month+"-"+year);   
            }
            
            
            //auto fill gender on the basis on NRIC3
             //if we have got a perfect 6, then we will autofill DOB
             if(id[i]=='nric_num_3' && el_val.length==4) {
                    var nric_3_val = $.trim($('#nric_num_3').val());
                    if(parseInt(nric_3_val)%2==0)
                    $('#gender_female').trigger('click');
                    else
                    $('#gender_male').trigger('click');
            }
            return true;
        }
    });
    
    if(bad==1) return false;
    return true;
  
}


/**
* 

 * @param {array} id
 * @returns {bool} */
function parkson_card_num( id) 
{
    
       
         var el_val = $.trim( $("#" + id).val() );
        if ( el_val.length > 16 || el_val == "" || el_val == 0) {
            $("#" + id).css('border', '1px solid red');
           
           return false;
        }
        else {
            $("#" + id).css('border', '1px solid #cccccc');
             return true;
            }
   
}




function  nric_width()
{
        var nric_1 = $.trim($('#nric_num_1').val().length);
        var nric_2 = $.trim($('#nric_num_2').val().length);
        var nric_3 = $.trim($('#nric_num_3').val().length);
        var bad = 0;
        if (nric_1 != 6) {
            $('#nric_num_1').css('border', '1px solid red');
            bad = 1;
        }
        else {
            $('#nric_num_1').css('border', '1px solid #cccccc');
        }

         if (nric_2 != 2) {
            $('#nric_num_2').css('border', '1px solid red');
            bad = 1;
        }
        else {
            $('#nric_num_2').css('border', '1px solid #cccccc');
        }
        
         if (nric_3 != 4) {
            $('#nric_num_3').css('border', '1px solid red');
            bad = 1;
        }
        else {
            $('#nric_num_3').css('border', '1px solid #cccccc');
        }
        

       if(bad==1) return false;
      return true;
  
}






$(document).on('submit', '#customer_profile_form', function (e) {
       
        e.preventDefault();
        //validate form
        
        if($('#race').val()=='Other')
        {
             var required = ['f_name','l_name','nationality','address_1','custome_race','member_since'];
        }
        else
        {
             var required = ['f_name','l_name','nationality','address_1','race','member_since'];
        }
       
//        if($('#member_type_supplementary').is(':checked'))
//        {
//            required.push('p_card_holder');
//            required.push('p_card_number');
//        }
                        
        var r1 =   required_validation(required);
       
        
//      if(!passport_validaton() || $.trim($('#nationality').val())=='Malaysian' || $.trim($('#nationality').val())=='malaysian' ) {//only one is required between NRIC and PASSPORT 
//        var r5 =   nric_width();
//      }
//      else{
//        var r5 = true;
//        $('#nric_num_1').css('border', '1px solid #cccccc');
//        $('#nric_num_2').css('border', '1px solid #cccccc');
//        $('#nric_num_3').css('border', '1px solid #cccccc');
//      }
      
//      if(!r5)
//      {
//         var r8 =   passport_validaton();
//      }
//      else{
//        $("#passport_num").css('border', '1px solid #cccccc');    
//        var r8 = true;
//      }
     
      
      var r6 = parkson_card_num('membership_num');
      var r9 = bonuslink_validation();
      
      if(!r1 || !r5 || !r6 || !r8 || !r9)
      return false;
     
    // 
//      //checking age for under 100 age
//      if($.trim($('#dob').val()).length > 0){
//       var val = $('#dob').val()//dd-mm-yyyy
//       var split_date = val.split('-');
//       var dd = split_date[0] ;
//       var mm = split_date[1];
//       var yyyy = split_date[2]; 
//       var r8 =  validateDate(yyyy+"-"+mm+"-"+dd);
//       if(!r8)
//       return false;
//       }
      
      
      
        var from_values = $(this).serialize();
        if(ajaxInProgress) return;
        ajaxInProgress = true;
        $('#sub_progress').show();
        
        $.ajax({
            url: '<?php echo site_url('membership/add_customer') ?>',
            dataType: 'json',
            type: 'POST',
            data: from_values,
            success: function (result)
            {

                if (result.status == 1) {
                    $('#alert_area_frm').empty().html('<div class="alert alert-success  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    setTimeout(function () {
                        $('#disappear1').fadeOut('slow')
                    }, 3000);
                    $('#customer_profile_form')[0].reset();
                    $('#valid_thru').val('12-2017'); 
                    $('#member_since').val('<?php echo date('m-Y',time()); ?>');
                }
                else
                {
                    $('#alert_area_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    
                }
                $('html, body').animate({scrollTop : 0},800);
                $('#sub_progress').fadeOut();
                ajaxInProgress = false;
            },
            error:function () {
              ajaxInProgress = false;
            }
        });
    });


//for hide/show of state dropdown vs text box
$(document).on('change','#country',function(){
   
   if(this.value=='Malaysia')
  {
    $('#state').val('');
    $('#state').addClass('hide');
    $('#m_state').removeClass('hide');
  } 
  else
  {
      $('#m_state').val('0');
      $('#m_state').addClass('hide');
      $('#state').removeClass('hide');
  }
   
});

//find membership dialog box
$(document).on('click','#generate_password',function(e){
    var from_values = $("#customer_profile_form").serialize();
    e.preventDefault();
    $.ajax({
       url:'<?php echo site_url('membership/generate_password/') ?>',
       dataType: 'json',
            type: 'POST',
            data: from_values,
       success:function(result)
       {
        console.log(result);
        $('#find_response').empty().html(result.message);
       } 
    });
    $('#generatePasswordModel').modal('show');
    
});

//select a member from find dialog
$(document).on('click','.select_member',function(e){
    e.preventDefault();
    
    var return_val;
    $.ajax({
        url: '<?php echo site_url('membership/is_supp_limit_reached') ?>/'+$(this).data('customer_id'),
        dataType: 'json',
        async: false,
        success: function (result)
        {
            if (result.status == 1) {
                return_val = false;
                $('#alert_area_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                $('html, body').animate({scrollTop : 0},800);
            }
            else{
                $('#alert_area_frm').empty();
                return_val = true;
            }
         }
    });
    if(!return_val) {
        
     $('#findModal').modal('hide');
     $('#p_card_holder').val('');
     $('#p_card_number').val('');
     $('#p_card_holder_id').val('');
     return false;
    }
    
    $('#p_card_holder').val($(this).data('name'));
    $('#p_card_number').val($(this).data('card_no'));
    $('#p_card_holder_id').val($(this).data('customer_id'));
    $('#findModal').modal('hide');
    
});


//fill dob into nric_1 
$(document).on('change','#dobx',function(e){
   var val = $(this).val();//00-00-0000
   var split_date = val.split('-');
   var dd = split_date[0] ;
   var mm = split_date[1];
   var yy = split_date[2].charAt(2)+split_date[2].charAt(3); 
   $('#nric_num_1').val(yy+mm+dd);
});

//fill parkson card num value into card field
$(document).on('keyup','#membership_num',function(){
    $('#card_num').val($(this).val());
})

//manually input Race on seletection other
$(document).on('change','#race',function(){
   var country = $(this).val();
   if(country =='Other')
   {
       $(this).parent().removeClass('col-lg-6');
       $(this).parent().addClass('col-lg-3');
        $('#custome_race_div').show();
       
   }
   else
   {
       $('#custome_race_div').hide();
        $(this).parent().removeClass('col-lg-3');
        $(this).parent().addClass('col-lg-6');
   }
    
})



function validateDate(date){
    var HYearsAgo = moment().subtract(100, "years");
    var minimumAge = moment().subtract(18, "years");
    var birthday = moment(date,"YYYY-MM-DD");
    var message;
    if (!birthday.isValid()) {
        message = "Invalid Date of Birth";
        $('#alert_area_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +message + '</div>');
        $('html, body').animate({scrollTop : 0},800);
        return false;                   
    }
    else if (HYearsAgo.isAfter(birthday)) {
        message = "Customer's age should be under 100 years.";
        $('#alert_area_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +message + '</div>');
        $('html, body').animate({scrollTop : 0},800);
        return false;     
    }
    else if (minimumAge.isBefore(birthday)) {
        message = "Customer should be at least 18 years old.";
        $('#alert_area_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +message + '</div>');
        $('html, body').animate({scrollTop : 0},800);
        return false;     
    }
    else {
        $('#alert_area_frm').empty();
       return true;                                                                                                                                                                                                                                   
    }
}


//Malysian Nationality

function check_for_malaysian()
{
    if($.trim($('#nationality').val())=='Malaysian' || $.trim($('#nationality').val())=='malaysian')
    {
        $('.pass_section').addClass('hide');
        $('.pass_or').addClass('hide');
    }
    else
    {
        $('.pass_section').removeClass('hide');
        $('.pass_or').removeClass('hide');
    }
}

$(document).on('keyup','#nationality',check_for_malaysian);


</script>

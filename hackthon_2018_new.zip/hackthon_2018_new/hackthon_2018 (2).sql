-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2018 at 04:19 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hackthon_2018`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_level`
--

CREATE TABLE `auth_level` (
  `auth_level_id` int(11) NOT NULL,
  `auth_level_code` int(11) NOT NULL,
  `auth_level_name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_level`
--

INSERT INTO `auth_level` (`auth_level_id`, `auth_level_code`, `auth_level_name`, `created`, `created_by`, `is_deleted`, `deleted_by`) VALUES
(1, 1, 'Operation Manager/Senior Str Manager', '2014-11-07 00:00:00', 1, 0, 0),
(2, 2, 'Asst Store Manager / Store Manager', '2014-11-07 00:00:00', 1, 0, 0),
(3, 3, 'Authorize Floor Executive', '2014-11-07 00:00:00', 1, 0, 0),
(4, 4, 'Floor Executive/Supervisor', '2014-11-07 00:00:00', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL COMMENT 'Mr/Mrs/Ms?Dato’/Tan Sri/Puan Sri/ Tun/Che’Puan',
  `userid` varchar(256) NOT NULL,
  `account_no` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('male','female','','') NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `address_3` varchar(255) NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(256) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `location_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `is_archive` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=>not archive 1=> for archive',
  `restore_by` int(11) NOT NULL,
  `archive_by` int(11) NOT NULL DEFAULT '0' COMMENT '0=>for not archive user_id=> for archive by'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `title`, `userid`, `account_no`, `balance`, `dob`, `gender`, `address_1`, `address_2`, `address_3`, `postcode`, `city`, `state`, `country`, `mobile`, `email`, `password`, `first_name`, `last_name`, `location_id`, `staff_id`, `created`, `last_modified`, `is_archive`, `restore_by`, `archive_by`) VALUES
(25942, 'Mr', '', 0, 0, '2000-12-27', 'male', '4344', '', '', '', '', 'GA', 'India', '', 'prashant@gmail.com', 'NIATAS@2000', 'prashant', 'sharma', 18, 1, '2018-05-10 09:58:17', '0000-00-00 00:00:00', 0, 0, 0),
(25943, 'Mr', '', 0, 0, '2000-12-20', 'male', '4344', '', '', '', '', 'MP', 'India', '', 'prha@gmail.com', 'NIATAS@2000', 'prasahnt', 'sharma', 18, 1, '2018-05-10 10:04:15', '0000-00-00 00:00:00', 0, 0, 0),
(25944, 'Mr', '', 0, 0, '2000-12-13', 'male', '4344', '', '', '', '', 'JH', 'India', '', 'prashant@gmail.com', 'NIATAS@2000', 'Prashant', 'Sharma', 18, 1, '2018-05-10 10:20:29', '0000-00-00 00:00:00', 0, 0, 0),
(25945, 'Mr', 'dfffff', 4535434, 34534, '2000-12-27', 'male', '454', '', '', '', '', 'AR', 'India', '', 'prasht@gmail.com', 'NIATAS@2000', 'P', 's', 18, 1, '2018-05-10 16:15:23', '0000-00-00 00:00:00', 0, 0, 0),
(25946, 'Mr', 'dfffff', 4535434, 34534, '2000-12-27', 'male', '454', '', '', '', '', 'AR', 'India', '', 'prasht@gmail.com', 'NIATAS@2000', 'P', 's', 18, 1, '2018-05-10 16:16:11', '0000-00-00 00:00:00', 0, 0, 0),
(25947, 'Mr', 'dfffff', 4535434, 34534, '2000-12-27', 'male', '454', '', '', '', '', 'AR', 'India', '', 'prasht@gmail.com', 'NIATAS@2000', 'P', 's', 18, 1, '2018-05-10 16:16:43', '0000-00-00 00:00:00', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_challenge_question`
--

CREATE TABLE `customer_challenge_question` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `challenge_question` varchar(110) NOT NULL,
  `answer` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_challenge_question`
--

INSERT INTO `customer_challenge_question` (`id`, `customer_id`, `challenge_question`, `answer`) VALUES
(0, 25947, 'Where did you go the first time you flew on a plane?', 'bangalore'),
(0, 25947, 'What is the last name of your favorite elementary school teacher?', 'neeta'),
(0, 25947, 'What is your favorite children’s book?', 'klsffgklhf');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `designation_id` int(11) NOT NULL,
  `designation_name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `deleted_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`designation_id`, `designation_name`, `created`, `is_deleted`, `created_by`, `deleted_by`) VALUES
(1, 'Operation Manager', '2014-11-07 00:00:00', 0, 1, 0),
(2, 'Senior Store Manager', '2014-11-07 00:00:00', 0, 1, 0),
(3, 'Senior Store Manager', '2014-11-07 11:29:08', 0, 1, 0),
(4, 'Store Manager', '2014-11-07 11:29:08', 0, 1, 0),
(5, 'Assistant Store Manager', '2014-11-07 11:29:08', 0, 1, 0),
(6, 'Floor Manager', '2014-11-07 11:29:08', 0, 1, 0),
(7, 'Assistant Floor Manager', '2014-11-07 11:29:08', 0, 1, 0),
(8, 'Senior Floor Executive', '2014-11-07 11:29:09', 0, 1, 0),
(9, 'Floor Executive', '2014-11-07 11:29:09', 0, 1, 0),
(10, 'Senior Supervisor', '2014-11-07 11:29:09', 0, 1, 0),
(11, 'Supervisor', '2014-11-07 11:29:09', 0, 1, 0),
(12, 'Assistant Supervisor', '2014-11-07 11:29:09', 0, 1, 0),
(13, 'Customer Service Manager', '2014-11-07 11:29:09', 0, 1, 0),
(14, 'Customer Service Executive', '2014-11-07 11:29:09', 0, 1, 0),
(15, 'Customer Service Supervisor', '2014-11-07 11:29:09', 0, 1, 0),
(16, 'Customer Service Assistant', '2014-11-07 11:29:09', 0, 1, 0),
(17, 'Assistant Chief Cashier', '2014-11-07 11:29:09', 0, 1, 0),
(18, 'Senior Cashier', '2014-11-07 11:29:09', 0, 1, 0),
(19, 'Cashier', '2014-11-07 11:29:09', 0, 1, 0),
(20, 'Sales Assistant', '2014-11-07 11:29:09', 0, 1, 0),
(21, 'Admin/Account Executive', '2014-11-07 11:29:09', 0, 1, 0),
(22, 'Account Clerk', '2014-11-07 11:29:09', 0, 1, 0),
(23, 'Computer Coordinator', '2014-11-07 11:29:09', 0, 1, 0),
(24, 'Admin /Account Supervisor', '2014-11-07 11:29:09', 0, 1, 0),
(25, 'xxxx', '2015-01-29 11:17:36', 1, 233, 1),
(26, 'xxx', '2015-06-27 15:23:45', 0, 357, 0);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `store_code` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `location_name`, `store_code`, `created`, `created_by`, `is_deleted`, `deleted_by`, `address`) VALUES
(1, 'Parkson Sg Wang Plaza', '120', '2014-11-11 11:54:33', 1, 0, 0, 'PARKSON GRAND SG WANG PLAZA, LG, GF & 1ST FLOOR, SUNGEI WANG PLAZA, 111, JALAN BUKIT BINTANG, 55100 KUALA LUMPUR.'),
(2, 'Parkson  Subang Parade', '122', '2014-11-11 11:54:42', 1, 0, 0, 'PARKSON GRAND SUBANG PARADE GF & 1st Floor Subang Parade No.5 , Jalan SS 16/1, Subang Jaya 47500 Petaling Jaya Selangor Darul Ehsan.'),
(3, 'Parkson Klang Parade', '123', '2014-11-11 11:54:50', 1, 0, 0, 'PARKSON GRAND KLANG PARADE  GF & 1ST FLOOR, KLANG PARADE 2112 JALAN MERU, 41050 KLANG SELANGOR DARUL EHSAN'),
(4, 'Parkson Selayang Mall', '125', '2014-11-11 11:55:00', 1, 0, 0, 'PARKSON SELAYANG MALL LG-1st Floor, Selayang Mall Shopping Centre Jalan SU9, Taman Selayang Utama 68100 Batu Caves, Selangor Darul Ehsan'),
(5, 'Parkson Alamanda', '126', '2014-11-11 11:55:08', 1, 0, 0, 'PARKSON ALAMANDA  LOT G101, GROUND FLOOR ALAMANDA PUTRAJAYA SHOPPING CENTRE JALAN ALAMANDA,PRESINT 1 62000 PUTRAJAYA,WILAYAH PERSEKUTUAN.'),
(6, 'Parkson KLCC', '130', '2014-11-11 11:55:17', 1, 0, 0, 'PARKSON GRAND KLCC  GF, 1ST & 2ND FLOOR, SURIA KLCC, KUALA LUMPUR CITY CENTRE, 50088 KUALA LUMPUR.'),
(7, 'Parkson B.Utama', '131', '2014-11-11 11:55:26', 1, 0, 0, 'PARKSON BANDAR UTAMA Lot G320,F320,F320, 1 Utama Shopping Center Lebuh Bandar Utama, Bandar Utama 47800 Petaling Jaya, Selangor Darul Ehsan.'),
(8, 'Parkson Pavilion', '132', '2014-11-11 11:55:50', 1, 0, 0, 'Parkson Pavilion Lot 3.54,4.42,6.26&6.38A Pavilion Kuala Lumpur No.168 Jalan Bukit Bintang 55100 Kuala Lumpur'),
(9, 'Parkson Sunway Pyramid', '133', '2014-11-11 11:55:59', 1, 0, 0, 'PARKSON SUNWAY PYRAMID Lot G1.22, LL1.26, & LL2.21, LL3.05 Sunway Pyramid No.3, Jalan PJS 11/15, Bandar Sunway 46150 Petaling Jaya ,Selangor.'),
(10, 'Parkson Festival City', '136', '2014-11-11 11:56:07', 1, 0, 0, 'PARKSON FESTIVAL CITY NO 67, JALAN TAMAN IBU KOTA TAMAN DANAU KOTA SETAPAK 5300 KUALA LUMPUR'),
(11, 'Parkson Setia City Mall', '137', '2014-11-11 11:56:18', 1, 0, 0, 'PARKSON SETIA CITY MALL  UG-DS01 & L1-DS02 SETIA CITY MALL NO 7 PERSIARAN SETIA DAGANG BANDAR SETIA ALAM,SEKSYEN U13 40170 SHAH ALAM SELANGOR.'),
(12, 'Parkson NU Sentral', '138', '2014-11-11 11:56:30', 1, 0, 0, 'Lot No. G1, C1, L1.01, L2.01, Lot 364, Jalan Tun Sambanthan, Seksyen 72, Brickfields             50470, Kuala Lumpur W.P'),
(13, 'Parkson Kajang', '141', '2014-11-11 11:57:45', 1, 0, 0, 'PARKSON KAJANG  METRO KAJANG, JLN TUN ABD AZIZ, 43000 KAJANG, SELANGOR.'),
(14, 'Parkson Rawang', '143', '2014-11-11 11:57:52', 1, 0, 0, 'PARKSON RIA RAWANG NO.7,Persiaran Bandar Rawang Pusat Bandar Rawang 48000 Rawang'),
(15, 'Parkson OUG Plaza', '152', '2014-11-11 11:57:59', 1, 0, 0, 'PARKSON GRAND OUG PLAZA  Ground, 1st, 2nd & 3rd Floor OUG Plaza, Taman OUG, Jalan Mega Off Jalan Klang Lama, 58200 Kuala Lumpur.'),
(16, 'Parkson Terminal One', '154', '2014-11-11 11:58:10', 1, 0, 0, 'PARKSON TERMINAL ONE Lot 1, Terminal 1 Shopping Plaza 20B, Jalan Lintang, 70000 Seremban Negari Sembilan'),
(17, 'Parkson Seremban Prima', '210', '2014-11-11 11:58:23', 1, 0, 0, 'PARKSON GRAND SEREMBAN PRIMA Lot 4973, Jalan Dato Yam Tuan 70000 Seremban, N. Sembilan Darul Khusus.'),
(18, 'Headquarters', 'Headquarters', '2014-11-18 09:13:21', 1, 1, 1, 'Parkson Perda City Mall Lot No. 95, F78 & S68, Perda City Mall, Jalan Perda Timur, Bandar Perda, 14000, Penang'),
(19, 'Parkson Mahkota Parade', '231', '2014-11-18 09:19:50', 1, 0, 0, 'Parkson Mahkota Parade Mahkota Parade Jalan Taman Bandar Hilir 75000 Melaka'),
(20, 'Parkson Melaka Mall', '232', '2014-11-18 09:20:00', 1, 0, 0, 'PARKSON MELAKA MALL G26&F31 Melaka Mall Complex  Lebuh Ayer Keroh 75450,Melaka'),
(21, 'Parkson Holiday Plaza', '262', '2014-11-18 09:20:11', 1, 0, 0, 'PARKSON GRAND HOLIDAY PLAZA G1,f1,2f1&2f2 Holiday Plaza Jln Dato Sulaiman,Taman Century 80250 Johor Bharu, Johor Darul Takzim'),
(22, 'Parkson Square One Batu Pahat', '272', '2014-11-18 09:20:36', 1, 0, 0, 'PARKSON SQUARE ONE BATU PAHAT Lvl G23,Lvl 2 F22, Lvl 3 S1, Lvl 4 T1, Square One Shopping Mall, NO. 1-1, Jln Flora Utama 4, Taman Flora Utama, 83000 Batu Pahat, Johor Darul Takzim'),
(23, 'Parkson Kluang Parade', '273', '2014-11-18 09:20:54', 1, 0, 0, 'PARKSON KLUANG PARADE Ground, 1st & 2nd Floor, Kluang Parade, No.2, Jalan Sentul 86000 Kluang,Johor.'),
(24, 'Parkson Megamall Kuantan', '280', '2014-11-18 09:21:05', 1, 0, 0, 'PARKSON BERJAYA MEGAMALL  LG.01 & G.01, Berjaya Megamall Jalan Tun Ismail, Sri Dagangan, 25000 Kuantan Pahang Darul Makmur.'),
(25, 'Parkson Kota Bharu TC', '283', '2014-11-18 09:21:17', 1, 0, 0, 'PARKSON KOTA BHARU  TRADE CENTER Lot No G27, 127,220 Ground, 1st and 2nd Floor Jalan Parit Dalam 15000 Kota Bharu, Kelantan Darul Naim'),
(26, 'Parkson East Coast Mall', '284', '2014-11-18 09:21:25', 1, 0, 0, 'Parkson East Coast Mall Ground Level, Level 1, Level 2 ( Zone 1 ) Jalan Putra Square 6 Putra Square 25200 Kuantan Pahang Darul Makmur'),
(27, 'Parkson Ipoh Parade', '310', '2014-11-18 09:21:34', 1, 0, 0, 'PARKSON IPOH PARADE  G01,F01,S01 Ipoh Parade 105,Jalan Sultan Abdul Jalil Green Town,30450 Ipoh Perak Darul Ridzuan.'),
(28, 'Parkson Wawasan Plaza', '350', '2014-11-18 09:21:41', 1, 0, 0, 'PARKSON WAWASAN PLAZA  Level 1-2,Wisma SEDCO Wawasan Plaza Lot TL017545274 Coastal Highway 88300 Kota Kinabalu,Sabah'),
(29, 'Parkson One Borneo', '352', '2014-11-18 09:21:51', 1, 0, 0, 'PARKSON 1 BORNEO LOT G 200 & LOT F 200,  GROUND & FIRST FLOOR, 1 BORNEO HYPERMALL,  JALAN SULAMAN, 88400 KOTA KINABALU, SABAH'),
(30, 'Parkson Labuan', '369', '2014-11-18 09:22:00', 1, 0, 0, 'PARKSON LABUAN Ground & 1st Floor Podium Level Financial Park Labuan Complex Jalan Merdeka 87000 Labuan,Sabah'),
(31, 'Parkson Riverside Kuching', '370', '2014-11-18 09:22:11', 1, 0, 0, 'PARKSON GRAND KUCHING Lot 280 , Section 48, K.T.L.D. Jalan Tuanku Abdul Rahman 93100 Kuching, Sarawak.'),
(32, 'Parkson Miri', '371', '2014-11-18 09:22:20', 1, 0, 0, 'PARKSON GRAND BINTANG PLAZA MIRI  Lot 1051 & 1219,Block 9,M.C.L.D Miri Pujut Road 98000 Miri, Sarawak'),
(33, 'Parkson The Spring', '372', '2014-11-18 09:22:27', 1, 0, 0, 'Parkson The Spring Shopping Mall Lot no G47, 132, 213 & 302, Ground, First, Second & Third Floor, The Spring Shopping Mall, Jalan Simpang Tiga, 93350 Kuching, Sarawak Malaysia'),
(34, 'Parkson Plaza Merdeka', '373', '2014-11-18 09:22:36', 1, 0, 0, 'PARKSON PLAZA MERDEKA (373) G-88, L-88 & L3-88 88, Pearl Street 9300 Kuching, Sarawak'),
(35, 'Parkson Sibu', '381', '2014-11-18 09:22:46', 1, 0, 0, 'Parkson Ria Sibu Level 2 – 4,Wisma Sanyan,   Lot 699,Block 5,Jalan Sanyan, 96000 Sibu,Sarawak'),
(36, 'Parkson Gurney Plaza', '410', '2014-11-18 09:22:57', 1, 0, 0, 'PARKSON GURNEY PLAZA  170-G-15, 01-18, 02-17 Plaza Gurney, Gurney Drive 10250 Penang.'),
(37, 'Parkson Prangin Mall', '420', '2014-11-18 09:23:07', 1, 0, 0, 'PARKSON GRAND PRANGIN MALL Lots 33-SB-01, G52 1-123A, 2-123, 3-123C, 4-92 Prangin Mall Komtar Jalan Dr. Lim Chwee Leong 10100 Penang.'),
(38, 'Parkson First Avenue', '421', '2014-11-18 09:23:19', 1, 0, 0, 'Parkson 1st Avenue Penang G-01, 1-01, 2-01, 3-01, 1st Avenue 182, Jalan Magazine 10300 Pulau Pinang.'),
(39, 'Parkson Sunway Carnival', '430', '2014-11-18 09:23:32', 1, 0, 0, 'Parkson Sunway Carnival UG-01, Upper Ground Floor Sunway Carnival Mall 3068, Jalan Todak Pusat Bandar Seberang Jaya 13700 Seberang Jaya Pulau Pinang.'),
(40, 'Parkson Petani Parade', '431', '2014-11-18 09:23:42', 1, 0, 0, 'PARKSON PETANI PARADE  Lot 136 – 179, Petani Parade Taman Sejati Indah, 08000 Sungai Petani, Kedah Darul Aman.'),
(41, 'Parkson Sg Wang Plaza', '120', '2014-11-18 15:55:07', 1, 1, 1, ''),
(42, 'Parkson Sg Wang', '120', '2014-11-27 07:43:15', 1, 1, 1, ''),
(43, 'Parkson HQ', '001', '2014-11-28 08:16:23', 1, 0, 0, ''),
(44, 'Parkson IOI City Mall', '127', '2014-11-28 09:28:58', 1, 0, 0, 'PARKSON IOI CITY MALL LOT AT-3 , L1-AT3 , L2-AT3 , GR , 1ST & 2ND  FLOOR, IOI CITY MALL,LEBUH IRC , IOI RESORT CITY, 62502 PUTRAJAYA,SEPANG, SELANGOR DARUL EHSAN.'),
(45, 'Parkson Perda City Mall', '432', '2015-01-29 07:49:27', 1, 0, 0, 'Parkson Perda City Mall Lot No. 95, F78 & S68, Perda City Mall, Jalan Perda Timur, Bandar Perda, 14000, Penang'),
(46, 'Parkson Imago KK Times Square', '353', '2015-01-29 07:50:01', 1, 0, 0, 'Parkson Imago KK Times Square Lot No. G001, F001 & S001, Imago Shopping Mall, KK Times Square PH2, Off Coastal Highway, 88100 Kota Kinabalu, Sabah'),
(47, 'Parkson Online', '110', '2015-04-07 16:15:39', 1, 0, 0, ''),
(48, 'Parkson Maju Junction', '139', '2015-06-30 11:08:55', 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `temp_password` varchar(255) COLLATE utf8_bin NOT NULL,
  `location_id` int(11) NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `designation` int(11) NOT NULL,
  `auth_level` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `role` tinyint(2) NOT NULL DEFAULT '2' COMMENT '1=admin, 2=staff',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_password_created` tinyint(4) NOT NULL DEFAULT '0',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `temp_password`, `location_id`, `first_name`, `last_name`, `designation`, `auth_level`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `role`, `created`, `is_password_created`, `modified`, `created_by`, `is_deleted`, `deleted_by`) VALUES
(1, 'admin', '$2a$08$U/gkv2eLJOQQBsZFfaEPwOgCkiRVclOS4TCME.PZ/JhTaVxd3G84.', '0', 18, 'admin', 'admin', 0, 0, 'him.developer@gmail.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '::1', '2018-05-10 15:47:11', 1, '2014-11-04 06:36:04', 1, '2018-05-10 13:47:11', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_autologin`
--

INSERT INTO `user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('03fe9c13500a7ff9b4fdbe8f48e00db6', 274, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '115.132.180.119', '2014-12-10 22:39:20'),
('03ffe4f767b17fb521f5fd85a2468d23', 312, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0)', '115.134.240.252', '2014-12-15 00:40:51'),
('05b0ff8c96873cee98c3cccdbb7642d5', 313, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '124.13.77.138', '2015-01-15 20:17:06'),
('07505f64f65ca8659093d97fdfd81ef5', 106, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '219.95.246.26', '2015-01-16 23:13:35'),
('15dd53d190c70876d4c84a509619bc8f', 313, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36', '124.13.77.138', '2015-01-16 04:07:09'),
('180a0bc9737826d0f278abf41b71c9fd', 313, 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0', '124.13.77.138', '2015-01-17 20:22:45'),
('1a6db3b8a71b0d496ae50a88e2bea2d3', 295, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36', '203.121.116.139', '2014-12-17 19:55:05'),
('1d522ff6f498c44a0c99ec9afbfd3656', 181, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '118.100.216.69', '2015-01-13 20:21:33'),
('1f0fc8972b0290ca7f21b35e26ecb886', 181, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '115.135.199.196', '2015-01-11 03:28:28'),
('1f6feaaf2bf9892b9902bd5b912c1f57', 197, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '1.9.106.97', '2015-01-11 03:45:09'),
('228aa16cc817b95b279cfe155454c7ef', 66, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '60.51.27.185', '2015-01-13 23:53:11'),
('2382813ff5877346aa6c389ef61aba9c', 90, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36', '175.139.224.81', '2015-01-07 01:34:46'),
('3a45f64b264692ed4b24367ce03bc3d3', 181, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '175.137.195.37', '2014-12-17 07:56:11'),
('484e3e71d0e8877ed37771f171a12060', 300, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36', '1.9.105.97', '2015-01-18 20:44:48'),
('490a9e65b66df0ff140eb63015fa9635', 239, 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.', '175.139.137.176', '2014-12-19 01:17:49'),
('6c2fa29263696da3edc2948bd905d580', 253, 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0; MAARJS)', '203.106.200.147', '2014-12-13 22:07:20'),
('802e8727cb5a00ba331896065b88e1a6', 106, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', '219.95.246.26', '2015-01-16 06:35:50'),
('84dcd68b5880dacfd89f3c7ad0c06ec3', 239, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', '175.139.137.176', '2014-12-18 01:51:39'),
('8c3f3cf6b2bae6ca0bd9b2033a075e4e', 133, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36', '1.9.102.13', '2015-01-19 21:35:40'),
('914f02159c1a9b4895a89281c3c0f8be', 295, 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Cente', '115.132.8.218', '2014-12-12 21:06:24'),
('96fb6f16f4361da5cee41443c1eefd18', 182, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '175.137.177.237', '2015-01-04 20:58:09'),
('a028e50f12f76824af0e2f1efa3d9dbb', 355, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '118.101.255.6', '2015-01-16 23:56:58'),
('b5f2a354dae8214fa15b46e2f9ae0cb9', 191, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36', '1.9.106.97', '2014-12-11 01:56:19'),
('bb29a42ff9b2a4b49ad0155d8ea1d509', 229, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '118.100.169.140', '2015-01-16 22:22:05'),
('d79fac58d35a407e143a6fba3cc4f03e', 345, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '60.51.70.2', '2015-01-05 22:01:33'),
('e76f94d28f8cf64356c8619b30baf39f', 260, 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0; MAARJS)', '1.9.103.84', '2014-12-12 07:43:42'),
('e7fb2acf6de21b21e9be9b5b56c34b9a', 191, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; MAARJS; rv:11.0) like Gecko', '1.9.106.97', '2014-12-16 07:08:17'),
('f05a708c06490f0efb393869a750e1df', 295, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36', '115.132.8.218', '2014-12-13 19:17:40'),
('f0b7bff773816fb9fb932f39f1bf1fef', 238, 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', '175.139.136.227', '2014-12-15 22:54:14'),
('f37a15367be5c82efd457337cfd258b9', 345, 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko', '60.51.65.43', '2015-01-17 00:57:53'),
('f58c7adaa1c612e5d49bff0a72518b98', 293, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36', '175.145.150.66', '2014-12-08 22:05:00'),
('fc60e3af3d8dcc276922218ba3b33c46', 260, 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0; MAARJS)', '1.9.102.236', '2015-01-02 07:20:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_level`
--
ALTER TABLE `auth_level`
  ADD PRIMARY KEY (`auth_level_id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`designation_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `is_deleted` (`is_deleted`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `user_autologin`
--
ALTER TABLE `user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_level`
--
ALTER TABLE `auth_level`
  MODIFY `auth_level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25948;
--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `designation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=359;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

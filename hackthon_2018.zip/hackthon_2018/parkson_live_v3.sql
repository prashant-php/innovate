-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2018 at 07:53 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `parkson_live_v3`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_level`
--

CREATE TABLE IF NOT EXISTS `auth_level` (
  `auth_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_level_code` int(11) NOT NULL,
  `auth_level_name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_by` int(11) NOT NULL,
  PRIMARY KEY (`auth_level_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `auth_level`
--

INSERT INTO `auth_level` (`auth_level_id`, `auth_level_code`, `auth_level_name`, `created`, `created_by`, `is_deleted`, `deleted_by`) VALUES
(1, 1, 'Operation Manager/Senior Str Manager', '2014-11-07 00:00:00', 1, 0, 0),
(2, 2, 'Asst Store Manager / Store Manager', '2014-11-07 00:00:00', 1, 0, 0),
(3, 3, 'Authorize Floor Executive', '2014-11-07 00:00:00', 1, 0, 0),
(4, 4, 'Floor Executive/Supervisor', '2014-11-07 00:00:00', 1, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
if($details)
{
$default_race = array('Malay','Chinese','Indian');
$custome_race = array(
    'name' => 'custome_race',
    'id' => 'custome_race',
    'class' => 'form-control',
    'value' => $details[0]['race'],
    'placeholder' => 'Other Race'
   
);

$name_title = array(
    'Mr' => 'Mr',
    'Mrs' => 'Mrs',
    'Ms' => 'Ms',
    'Dato’' => 'Dato’',
    'Tan_Sri' => 'Tan Sri',
    'Puan_Sri' => 'Puan Sri',
    'Tun' => 'Tun',
    'Che’Puan' => 'Che’Puan',
    'Datin' => 'Datin',
    'Datuk' => 'Datuk',
    'Dato Sri' => 'Dato Sri',
    'Datuk Seri' => 'Datuk Seri',
    'Dato Paduka' => 'Dato Paduka',
    'Dr' => 'Dr',
    'Mdm' => 'Mdm'
);

$race = array(
    '0' => '--Race--',
    'Malay' => 'Malay',
    'Chinese' => 'Chinese',
    'Indian' => 'Indian',
    'Other' => 'Other',
);

$card_status = array(
    'Active' => 'Active',
    'Blacklisted' => 'Blacklisted',
    'Terminated' => 'Terminated',
    'Blocked' => 'Blocked',
);



$f_name = array(
    'name' => 'first_name',
    'id' => 'f_name1',
    'class' => 'form-control',
    'value' => $details[0]['first_name'],
    'placeholder' => 'Name'
   
);

$name_on_card = array(
    'name' => 'name_on_card',
    'id' => 'edit_name_on_card',
    'class' => 'form-control',
    'value' => $details[0]['name_on_card'],
    'placeholder' => 'Prefered Name On Card',
); 
$l_name = array(
    'name' => 'last_name',
    'id' => 'l_name1',
    'class' => 'form-control',
    'placeholder' => 'Last Name',
    'value' => $details[0]['last_name']
    
);

$membership_num = array(
    'name' => 'membership_no',
    'id' => 'membership_num1',
    'class' => 'form-control',
    'value' => $details[0]['membership_no'],
    'placeholder' => 'Parkson Card Number',
    'maxlength' => '16'
    
);



$dob = array(
    'name' => 'dob',
    'id' => 'dob1',
    'class' => 'form-control',
    'placeholder' => 'Date Of Birth',
    'value' => ($details[0]["dob"]!='0000-00-00')? date("d-m-Y", strtotime($details[0]['dob'])):'',
    'readonly' => 'readonly'
);

$valid_thru = array(
    'name' => 'valid_thru',
    'id' => 'valid_thru1',
    'class' => 'form-control',
    'placeholder' => 'Date of Card validity',
    'value' =>  date('m-Y',strtotime($details[0]['valid_thru'])),
    'readonly' => 'readonly',
    'disabled' => 'disabled'
);

$member_since = array(
    'name' => 'member_since',
    'id' => 'member_since1',
    'class' => 'form-control',
    'placeholder' => 'MM YY',
    'value' => date('m-Y',strtotime($details[0]['member_since'])),
    'readonly' => 'readonly',
    'disabled' => 'disabled'
);

$nric_num_1 = array(
    'name' => 'NRIC_no_1',
    'id' => 'nric_num_1',
    'class' => 'form-control',
    'placeholder' => '',
    'onkeyup' => 'required_validation(this.id)',
    'value' => $details[0]['NRIC_no_1'],
    'maxlength' => '6',
    'style' => 'padding: 6px 6px;'
);

$nric_num_2 = array(
    'name' => 'NRIC_no_2',
    'id' => 'nric_num_2',
    'class' => 'form-control',
    'placeholder' => '',
    'value' => $details[0]['NRIC_no_2'],
    'maxlength' => '2',
    'style' => 'width: 40px;'
);

$nric_num_3 = array(
    'name' => 'NRIC_no_3',
    'id' => 'nric_num_3',
    'class' => 'form-control',
    'placeholder' => '',
    'value' => $details[0]['NRIC_no_3'],
    'maxlength' => '4',
    'onkeyup' => 'required_validation(this.id)',
    'style' => 'width: 57px;'
);

$nationality = array(
    'name' => 'nationality',
    'id' => 'nationality1',
    'class' => 'form-control',
    'placeholder' => 'Nationality',
    'value' => $details[0]['nationality'],
);

$passport_num = array(
    'name' => 'passport_no',
    'id' => 'passport_num',
    'class' => 'form-control',
    'placeholder' => 'Passport Number',
     'value' => $details[0]['passport_no'],
);


$address_1 = array(
    'name' => 'address_1',
    'id' => 'address_11',
    'class' => 'form-control',
    'placeholder' => 'Address',
    'value' => $details[0]['address_1'],
);
$address_2 = array(
    'name' => 'address_2',
    'id' => 'address_2',
    'class' => 'form-control',
    'placeholder' => 'Address',
      'value' => $details[0]['address_2'],
);

$address_3 = array(
    'name' => 'address_3',
    'id' => 'address_3',
    'class' => 'form-control',
    'placeholder' => 'Address',
      'value' => $details[0]['address_3'],
);

$Bonuslink_num = array(
    'name' => 'bonus_link_no',
    'id' => 'Bonuslink_num',
    'class' => 'form-control',
    'placeholder' => 'Bonuslink Number',
    'value' => $details[0]['bonus_link_no'],
    'maxlength' => '16'
    
);
$card_num = array(
    'name' => 'card_no',
    'id' => 'card_num',
    'class' => 'form-control',
    'placeholder' => 'Membership Number',
    'value' => $details[0]['card_no'],
    'readonly' => 'true',
);

$registration_num = array(
    'name' => 'registration_no',
    'id' => 'registration_num',
    'class' => 'form-control',
    'placeholder' => 'Registration Form Number',
     'value' => $details[0]['registration_no'],
);

$post_code = array(
    'name' => 'postcode',
    'id' => 'post_code',
    'class' => 'form-control',
    'placeholder' => 'Post Code',
      'value' => $details[0]['postcode'],
);


$city = array(
    'name' => 'city',
    'id' => 'city',
    'class' => 'form-control',
    'placeholder' => 'City',
      'value' => $details[0]['city'],
);
$state = array(
    'name' => 'state',
    'id' => 'state',
    'class' => 'form-control hide',
    'placeholder' => 'State',
      'value' => $details[0]['state'],
);

$p_card_holder = array(
    'name' => 'p_card_holder',
    'id' => 'p_card_holder',
    'class' => 'form-control disabled',
    'placeholder' => 'Principal Card Holder Name',
    'readonly' =>'true',
    'value' =>  ($details[0]['membership_type'] =='supplementary') ? @$details[1]['p_holder_fname']." ".@$details[1]['p_holder_lname']:'',
);

$p_card_number = array(
    'name' => 'p_card_number',
    'id' => 'p_card_number',
    'class' => 'form-control disabled',
    'placeholder' => 'Parkson Card Number',
    'readonly' =>'true',
    'value' => ($details[0]['membership_type'] =='supplementary')? @$details[1]['p_card_no']:'',
);

$email = array(
    'name' => 'email',
    'id' => 'email_2',
    'class' => 'form-control',
    'placeholder' => 'Email',
    'value' => $details[0]['email'],
);

$mobile_num_1 = array(
    'name' => 'mobile_1',
    'id' => 'mobile_num_1',
    'class' => 'form-control',
    'placeholder' => '',
    'value' => $details[0]['mobile_1'],
    'maxlength' => '4'
);

$mobile_num_2 = array(
    'name' => 'mobile_2',
    'id' => 'mobile_num_2',
    'class' => 'form-control',
    'placeholder' => '',
    'value' => $details[0]['mobile_2'],
    'maxlength' => '8'
);




$malaysian_states = array(
    "0" => '--Select State--',
    'Kuala Lumpur' => 'Kuala Lumpur',
    'Labuan' => 'Labuan',
    'Putrajaya' => 'Putrajaya',
    'Johor Darul Takzim' => 'Johor Darul Takzim',
    'Kedah Darul Aman' => 'Kedah Darul Aman',
    'Kelantan Darul Naim' => 'Kelantan Darul Naim',
    'Malacca' => 'Malacca',
    'Negeri Sembilan Darul Khusus' => 'Negeri Sembilan Darul Khusus',
    'Pahang Darul Makmur' => 'Pahang Darul Makmur',
    'Perak Darul Ridzuan' => 'Perak Darul Ridzuan',
    'Perlis Indera Kayangan' => 'Perlis Indera Kayangan',
    'Pulau Pinang' => 'Pulau Pinang',
    'Sabah' => 'Sabah',
    'Sarawak' => 'Sarawak',
    'Selangor Darul Ehsan' => 'Selangor Darul Ehsan',
    'Terengganu Darul Iman' => 'Terengganu Darul Iman'
    );

   $company_name = array(
    'name' => 'company_name',
    'id' => 'company_name',
    'class' => 'form-control',
    'value' => $details[0]['company_name'],
    'placeholder' => 'Company Name'
);
?>
<noscript>
	<h3 style="margin-left: 230px;">JavaScript is disabled! Please enable JavaScript in your web browser.</h3>
    <style type="text/css">
		.right-side { display:none; }
	</style>
</noscript>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">                
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1 class="pull-left">
<?php echo @$title; ?>
</h1>
<div class="clearfix"></div>
    </section>
    <div class="clearfix"></div>
   <!-- Main content -->
    <section class="content">

        <div class="row">
            <div class="col-md-12">
                <div class="well-lg" style="overflow: auto;">
                    <div id="alert_area_bonus_err"></div> 
                    <div id="alert_area_edit_by_admin_frm"></div> 
<?php echo form_open(site_url('membership/edit_customer_save'), array('class' => 'form-horizontal', 'role' => 'form', 'id' => 'customer_profile_edit_form')); ?>
                   
                   <div class="col-md-6 padding-left-none"  id="form_left_section">
                   <div class="form-group">
                        <div class="col-lg-2 padding-right-none" >
                            <label class="control-label">Title</label>
<?php echo form_dropdown('title', $name_title, $details[0]['title'], "class=form-control id=title style=padding:0px;font-size:12px;  "); ?> 
                        </div>
                        <div class="col-lg-3 padding-right-none">
                            <label class="control-label">Name*</label>
                            <?php echo form_input($f_name); ?> 
                            <span style="color: red;"><?php echo form_error($f_name['name']); ?><?php echo isset($errors[$f_name['name']]) ? $errors[$f_name['name']] : ''; ?> </span>
                        </div>
                        <div class="col-lg-3 padding-left-none">
                            <label class="control-label">&nbsp;</label>
                            <?php echo form_input($l_name); ?> 
                            <span style="color: red;"><?php echo form_error($l_name['name']); ?><?php echo isset($errors[$l_name['name']]) ? $errors[$l_name['name']] : ''; ?> </span>
                        </div>
                         <div class="col-lg-4 padding-left-none">
                            <label class="control-label">Prefered Name On Card</label>
                            <?php echo form_input($name_on_card); ?> 
                            <span style="color: red;"><?php echo form_error($name_on_card['name']); ?><?php echo isset($errors[$name_on_card['name']]) ? $errors[$name_on_card['name']] : ''; ?> </span>
                             </div> 
                      
                     </div><!-- form-group -->
                    <div class="form-group">
                      <?php 
                          if(in_array($details[0]['race'], $default_race)){
                        ?>
                        <div class="col-lg-6">
                            <label class="control-label">Race*</label>
                            <?php echo form_dropdown('race', $race, $details[0]['race'], "class=form-control id=race1 onblur=required_validation(this.id)"); ?> 
                            <span style="color: red;"><?php echo form_error('race'); ?><?php echo isset($errors['race']) ? $errors['race'] : ''; ?></span>
                        </div>
                        <div class="col-lg-3 padding-left-none" id="custome_race_div" style="display: none" >
                         <label class="control-label">&nbsp;</label>
                          <?php echo form_input($custome_race); ?>  
                         </div>
                        <?php 
                          }
                        else {
                             ?>
                        <div class="col-lg-3">
                            <label class="control-label">Race*</label>
                            <?php echo form_dropdown('race', $race, 'Other', "class=form-control id=race1 onblur=required_validation(this.id)"); ?> 
                            <span style="color: red;"><?php echo form_error('race'); ?><?php echo isset($errors['race']) ? $errors['race'] : ''; ?></span>
                        </div>
                        <div class="col-lg-3 " id="custome_race_div" >
                         <label class="control-label">&nbsp;</label>
                          <?php echo form_input($custome_race); ?>  
                         </div>
                        
                        <?php
                        }
                        ?>
                     <div class="col-lg-6">
                            <label class="control-label">Nationality*</label>
                            <?php echo form_input($nationality); ?> 
                            <span style="color: red;"><?php echo form_error($nationality['name']); ?><?php echo isset($errors[$nationality['name']]) ? $errors[$nationality['name']] : ''; ?></span>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                     
                     <div class="form-group">
                       <div class="col-lg-6">
                           <label class="control-label ">NRIC Number*</label>
                            <div class="row">
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-4 padding-right-none"><?php echo form_input($nric_num_1); ?></div>
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-4 padding-left-none padding-right-none" style="width: auto;"><?php echo form_input($nric_num_2); ?></div>
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-4 padding-left-none padding-right-none" style="width: auto;"><?php echo form_input($nric_num_3); ?></div>
                            <div class="or pass_or">--OR--</div>
                            </div>
                            <span style="color: red;">
                                <?php echo form_error($nric_num_1['name']); ?><?php echo isset($errors[$nric_num_1['name']]) ? $errors[$nric_num_1['name']] : ''; ?>
                                 <?php echo form_error($nric_num_2['name']); ?><?php echo isset($errors[$nric_num_2['name']]) ? $errors[$nric_num_2['name']] : ''; ?>
                                 <?php echo form_error($nric_num_3['name']); ?><?php echo isset($errors[$nric_num_3['name']]) ? $errors[$nric_num_3['name']] : ''; ?>
                            </span>
                         </div>
                          <div class="col-lg-6 pass_section">
                            <label class="control-label">Passport  Number*</label>
                            <?php echo form_input($passport_num); ?> 
                        </div>
                        
                    </div>
                    <div class="form-group">
                        <div class="col-lg-6">
                            <label class="control-label ">Gender*</label>
                            <div class="clearfix"></div>
                           <label class="radio-inline">
                              <?php 
                              if($details[0]['gender'] == 'male')
                              echo form_radio('gender', 'male', true,' id="gender_male" '); 
                              else
                              echo form_radio('gender', 'male', false,' id="gender_male"  '); 
                              ?> Male
                            </label>
                            <label class="radio-inline">
                              <?php 
                              if($details[0]['gender'] == 'female')
                              echo form_radio('gender', 'female', true,' id="gender_female" ');
                              else
                              echo form_radio('gender', 'female', false,' id="gender_female" '); 
                              ?> Female
                            </label>
                          <span style="color: red;"><?php echo form_error('gender'); ?><?php echo isset($errors['gender']) ? $errors['gender'] : ''; ?></span>
                        </div>
                        <div class="col-lg-6">
                            <label class="control-label">Date Of Birth</label>
                            <?php echo form_input($dob); ?> 
                        </div>
                         
                    </div>
                    
                    
                    <div class="form-group">
                     <div class="col-lg-6">
                         
                            <label class="control-label">Mobile Number </label>
                            <div class="row">
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-4 padding-right-none"><?php echo form_input($mobile_num_1); ?></div>
                            <div class="col-md-8 col-sm-8 col-lg-8 col-xs-8 padding-left-none"><?php echo form_input($mobile_num_2); ?></div>
                            </div>
                            <span style="color: red;">
                                 <?php echo form_error($mobile_num_1['name']); ?><?php echo isset($errors[$mobile_num_1['name']]) ? $errors[$mobile_num_1['name']] : ''; ?>
                                 <?php echo form_error($mobile_num_2['name']); ?><?php echo isset($errors[$mobile_num_2['name']]) ? $errors[$mobile_num_2['name']] : ''; ?>
                            </span>
                        </div>
                       
                        <div class="col-lg-6">
                            <label class="control-label">Email</label>
                            <?php echo form_input($email); ?> 
                            <span style="color: red;"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']]) ? $errors[$email['name']] : ''; ?></span>
                        </div>
                    </div> <!-- form-group -->       
                    
                       
                    
                     <div class="form-group">
                        <div class="col-lg-6">
                            <label class="control-label">Address 1*</label>
<?php echo form_input($address_1); ?> 
                            <span style="color: red;"><?php echo form_error($address_1['name']); ?><?php echo isset($errors[$address_1['name']]) ? $errors[$address_1['name']] : ''; ?></span>
                        </div>
                        <div class="col-lg-6">
                            <label class="control-label">Address 2</label>
<?php echo form_input($address_2); ?> 
                        </div>
                    </div> 
                    <div class="form-group">
                    
                        <div class="col-lg-8">
                            <label class="control-label">Address 3</label>
                            <?php echo form_input($address_3); ?> 
                        </div>
                        <div class="col-lg-4">
                            <label class="control-label">Post Code </label>
                                <?php echo form_input($post_code); ?> 
                        </div>
                      </div>   <!-- form-group -->       
                      
                       <div class="form-group">
                        <div class="col-lg-4">
                            <label class="control-label">Country  </label>


<select name="country" id="country" class="form-control"  >
    <option value="0">--Select Country--</option>
    <option value="Afghanistan">Afghanistan</option>
    <option value="Albania">Albania</option>
    <option value="Algeria">Algeria</option>
    <option value="American Samoa">American Samoa</option>
    <option value="Andorra">Andorra</option>
    <option value="Angola">Angola</option>
    <option value="Anguilla">Anguilla</option>
    <option value="Antartica">Antarctica</option>
    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
    <option value="Argentina">Argentina</option>
    <option value="Armenia">Armenia</option>
    <option value="Aruba">Aruba</option>
    <option value="Australia">Australia</option>
    <option value="Austria">Austria</option>
    <option value="Azerbaijan">Azerbaijan</option>
    <option value="Bahamas">Bahamas</option>
    <option value="Bahrain">Bahrain</option>
    <option value="Bangladesh">Bangladesh</option>
    <option value="Barbados">Barbados</option>
    <option value="Belarus">Belarus</option>
    <option value="Belgium">Belgium</option>
    <option value="Belize">Belize</option>
    <option value="Benin">Benin</option>
    <option value="Bermuda">Bermuda</option>
    <option value="Bhutan">Bhutan</option>
    <option value="Bolivia">Bolivia</option>
    <option value="Bosnia and Herzegowina">Bosnia and Herzegowina</option>
    <option value="Botswana">Botswana</option>
    <option value="Bouvet Island">Bouvet Island</option>
    <option value="Brazil">Brazil</option>
    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
    <option value="Brunei Darussalam">Brunei Darussalam</option>
    <option value="Bulgaria">Bulgaria</option>
    <option value="Burkina Faso">Burkina Faso</option>
    <option value="Burundi">Burundi</option>
    <option value="Cambodia">Cambodia</option>
    <option value="Cameroon">Cameroon</option>
    <option value="Canada">Canada</option>
    <option value="Cape Verde">Cape Verde</option>
    <option value="Cayman Islands">Cayman Islands</option>
    <option value="Central African Republic">Central African Republic</option>
    <option value="Chad">Chad</option>
    <option value="Chile">Chile</option>
    <option value="China">China</option>
    <option value="Christmas Island">Christmas Island</option>
    <option value="Cocos Islands">Cocos (Keeling) Islands</option>
    <option value="Colombia">Colombia</option>
    <option value="Comoros">Comoros</option>
    <option value="Congo">Congo</option>
    <option value="Congo">Congo, the Democratic Republic of the</option>
    <option value="Cook Islands">Cook Islands</option>
    <option value="Costa Rica">Costa Rica</option>
    <option value="Cota D'Ivoire">Cote d'Ivoire</option>
    <option value="Croatia">Croatia (Hrvatska)</option>
    <option value="Cuba">Cuba</option>
    <option value="Cyprus">Cyprus</option>
    <option value="Czech Republic">Czech Republic</option>
    <option value="Denmark">Denmark</option>
    <option value="Djibouti">Djibouti</option>
    <option value="Dominica">Dominica</option>
    <option value="Dominican Republic">Dominican Republic</option>
    <option value="East Timor">East Timor</option>
    <option value="Ecuador">Ecuador</option>
    <option value="Egypt">Egypt</option>
    <option value="El Salvador">El Salvador</option>
    <option value="Equatorial Guinea">Equatorial Guinea</option>
    <option value="Eritrea">Eritrea</option>
    <option value="Estonia">Estonia</option>
    <option value="Ethiopia">Ethiopia</option>
    <option value="Falkland Islands">Falkland Islands (Malvinas)</option>
    <option value="Faroe Islands">Faroe Islands</option>
    <option value="Fiji">Fiji</option>
    <option value="Finland">Finland</option>
    <option value="France">France</option>
    <option value="France Metropolitan">France, Metropolitan</option>
    <option value="French Guiana">French Guiana</option>
    <option value="French Polynesia">French Polynesia</option>
    <option value="French Southern Territories">French Southern Territories</option>
    <option value="Gabon">Gabon</option>
    <option value="Gambia">Gambia</option>
    <option value="Georgia">Georgia</option>
    <option value="Germany">Germany</option>
    <option value="Ghana">Ghana</option>
    <option value="Gibraltar">Gibraltar</option>
    <option value="Greece">Greece</option>
    <option value="Greenland">Greenland</option>
    <option value="Grenada">Grenada</option>
    <option value="Guadeloupe">Guadeloupe</option>
    <option value="Guam">Guam</option>
    <option value="Guatemala">Guatemala</option>
    <option value="Guinea">Guinea</option>
    <option value="Guinea-Bissau">Guinea-Bissau</option>
    <option value="Guyana">Guyana</option>
    <option value="Haiti">Haiti</option>
    <option value="Heard and McDonald Islands">Heard and Mc Donald Islands</option>
    <option value="Holy See">Holy See (Vatican City State)</option>
    <option value="Honduras">Honduras</option>
    <option value="Hong Kong">Hong Kong</option>
    <option value="Hungary">Hungary</option>
    <option value="Iceland">Iceland</option>
    <option value="India">India</option>
    <option value="Indonesia">Indonesia</option>
    <option value="Iran">Iran (Islamic Republic of)</option>
    <option value="Iraq">Iraq</option>
    <option value="Ireland">Ireland</option>
    <option value="Israel">Israel</option>
    <option value="Italy">Italy</option>
    <option value="Jamaica">Jamaica</option>
    <option value="Japan">Japan</option>
    <option value="Jordan">Jordan</option>
    <option value="Kazakhstan">Kazakhstan</option>
    <option value="Kenya">Kenya</option>
    <option value="Kiribati">Kiribati</option>
    <option value="Democratic People's Republic of Korea">Korea, Democratic People's Republic of</option>
    <option value="Korea">Korea, Republic of</option>
    <option value="Kuwait">Kuwait</option>
    <option value="Kyrgyzstan">Kyrgyzstan</option>
    <option value="Lao">Lao People's Democratic Republic</option>
    <option value="Latvia">Latvia</option>
    <option value="Lebanon">Lebanon</option>
    <option value="Lesotho">Lesotho</option>
    <option value="Liberia">Liberia</option>
    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
    <option value="Liechtenstein">Liechtenstein</option>
    <option value="Lithuania">Lithuania</option>
    <option value="Luxembourg">Luxembourg</option>
    <option value="Macau">Macau</option>
    <option value="Macedonia">Macedonia, The Former Yugoslav Republic of</option>
    <option value="Madagascar">Madagascar</option>
    <option value="Malawi">Malawi</option>
    <option value="Malaysia">Malaysia</option>
    <option value="Maldives">Maldives</option>
    <option value="Mali">Mali</option>
    <option value="Malta">Malta</option>
    <option value="Marshall Islands">Marshall Islands</option>
    <option value="Martinique">Martinique</option>
    <option value="Mauritania">Mauritania</option>
    <option value="Mauritius">Mauritius</option>
    <option value="Mayotte">Mayotte</option>
    <option value="Mexico">Mexico</option>
    <option value="Micronesia">Micronesia, Federated States of</option>
    <option value="Moldova">Moldova, Republic of</option>
    <option value="Monaco">Monaco</option>
    <option value="Mongolia">Mongolia</option>
    <option value="Montserrat">Montserrat</option>
    <option value="Morocco">Morocco</option>
    <option value="Mozambique">Mozambique</option>
    <option value="Myanmar">Myanmar</option>
    <option value="Namibia">Namibia</option>
    <option value="Nauru">Nauru</option>
    <option value="Nepal">Nepal</option>
    <option value="Netherlands">Netherlands</option>
    <option value="Netherlands Antilles">Netherlands Antilles</option>
    <option value="New Caledonia">New Caledonia</option>
    <option value="New Zealand">New Zealand</option>
    <option value="Nicaragua">Nicaragua</option>
    <option value="Niger">Niger</option>
    <option value="Nigeria">Nigeria</option>
    <option value="Niue">Niue</option>
    <option value="Norfolk Island">Norfolk Island</option>
    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
    <option value="Norway">Norway</option>
    <option value="Oman">Oman</option>
    <option value="Pakistan">Pakistan</option>
    <option value="Palau">Palau</option>
    <option value="Panama">Panama</option>
    <option value="Papua New Guinea">Papua New Guinea</option>
    <option value="Paraguay">Paraguay</option>
    <option value="Peru">Peru</option>
    <option value="Philippines">Philippines</option>
    <option value="Pitcairn">Pitcairn</option>
    <option value="Poland">Poland</option>
    <option value="Portugal">Portugal</option>
    <option value="Puerto Rico">Puerto Rico</option>
    <option value="Qatar">Qatar</option>
    <option value="Reunion">Reunion</option>
    <option value="Romania">Romania</option>
    <option value="Russia">Russian Federation</option>
    <option value="Rwanda">Rwanda</option>
    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
    <option value="Saint LUCIA">Saint LUCIA</option>
    <option value="Saint Vincent">Saint Vincent and the Grenadines</option>
    <option value="Samoa">Samoa</option>
    <option value="San Marino">San Marino</option>
    <option value="Sao Tome and Principe">Sao Tome and Principe</option> 
    <option value="Saudi Arabia">Saudi Arabia</option>
    <option value="Senegal">Senegal</option>
    <option value="Seychelles">Seychelles</option>
    <option value="Sierra">Sierra Leone</option>
    <option value="Singapore">Singapore</option>
    <option value="Slovakia">Slovakia (Slovak Republic)</option>
    <option value="Slovenia">Slovenia</option>
    <option value="Solomon Islands">Solomon Islands</option>
    <option value="Somalia">Somalia</option>
    <option value="South Africa">South Africa</option>
    <option value="South Georgia">South Georgia and the South Sandwich Islands</option>
    <option value="Span">Spain</option>
    <option value="SriLanka">Sri Lanka</option>
    <option value="St. Helena">St. Helena</option>
    <option value="St. Pierre and Miguelon">St. Pierre and Miquelon</option>
    <option value="Sudan">Sudan</option>
    <option value="Suriname">Suriname</option>
    <option value="Svalbard">Svalbard and Jan Mayen Islands</option>
    <option value="Swaziland">Swaziland</option>
    <option value="Sweden">Sweden</option>
    <option value="Switzerland">Switzerland</option>
    <option value="Syria">Syrian Arab Republic</option>
    <option value="Taiwan">Taiwan, Province of China</option>
    <option value="Tajikistan">Tajikistan</option>
    <option value="Tanzania">Tanzania, United Republic of</option>
    <option value="Thailand">Thailand</option>
    <option value="Togo">Togo</option>
    <option value="Tokelau">Tokelau</option>
    <option value="Tonga">Tonga</option>
    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
    <option value="Tunisia">Tunisia</option>
    <option value="Turkey">Turkey</option>
    <option value="Turkmenistan">Turkmenistan</option>
    <option value="Turks and Caicos">Turks and Caicos Islands</option>
    <option value="Tuvalu">Tuvalu</option>
    <option value="Uganda">Uganda</option>
    <option value="Ukraine">Ukraine</option>
    <option value="United Arab Emirates">United Arab Emirates</option>
    <option value="United Kingdom">United Kingdom</option>
    <option value="United States">United States</option>
    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
    <option value="Uruguay">Uruguay</option>
    <option value="Uzbekistan">Uzbekistan</option>
    <option value="Vanuatu">Vanuatu</option>
    <option value="Venezuela">Venezuela</option>
    <option value="Vietnam">Viet Nam</option>
    <option value="Virgin Islands (British)">Virgin Islands (British)</option>
    <option value="Virgin Islands (U.S)">Virgin Islands (U.S.)</option>
    <option value="Wallis and Futana Islands">Wallis and Futuna Islands</option>
    <option value="Western Sahara">Western Sahara</option>
    <option value="Yemen">Yemen</option>
    <option value="Yugoslavia">Yugoslavia</option>
    <option value="Zambia">Zambia</option>
    <option value="Zimbabwe">Zimbabwe</option>
</select>
                        </div>
                        <div class="col-lg-4">
                            <label class="control-label">State  </label>
                            
                            <?php
                            // if($details[0]['country'] == 'Malaysia')
                             {
                             echo form_dropdown('m_state', $malaysian_states, $details[0]['state'], "class=form-control hide id=m_state");
                             }
                           //  else
                             {
                             echo form_input($state);
                             }
                             ?> 
                            
                        </div>
                        <div class="col-lg-4">
                            <label class="control-label">City</label>
                            <?php echo form_input($city); ?> 
                        </div>
                        
                        
                        
                    </div>  <!-- form-group -->   
                   </div><!-- col-md-6 -->
                   
                   
                   <div class="col-md-6 padding-right-none">
                        <div class="form-group hide">
                            <div class="col-md-6 pull-right">
                                <label class="control-label">Registration Form Number</label>
                                <?php echo form_input($registration_num); ?> 
                            </div>
                           
                        </div><!-- form-group -->
                        <div class="clearfix"></div>
                         <div class="form-group">
                        
                        <div class="col-md-6">
                                <label class="control-label">Parkson Card Number*</label>
                                 <?php echo form_input($membership_num); ?> 
                                <span style="color: red;"><?php echo form_error($membership_num['name']); ?><?php echo isset($errors[$membership_num['name']]) ? $errors[$membership_num['name']] : ''; ?> </span>
                            </div>
                             <div class="col-md-6">
                            <label class="control-label">Member Since*  </label>
                                <?php echo form_input($member_since); ?> 
                            </div>
                          
                    </div>
                    <div class="clearfix"></div>
                        
                        
                        <div class="form-group">
                        <div class="col-lg-6 padding-right-none" >
                            <label class="control-label ">Membership Tier</label>
                           <div class="clearfix"></div>
                            <label class="radio-inline">
                              <?php
                              if($details[0]['membership_tier'] =='gold')
                              echo form_radio('membership_tier', 'gold', TRUE);
                              else
                              echo form_radio('membership_tier', 'gold');
                              ?> Gold
                            </label>
                           
                            <label class="radio-inline">
                              <?php 
                              if($details[0]['membership_tier'] =='platinum')
                              echo form_radio('membership_tier', 'platinum',TRUE);
                              else
                              echo form_radio('membership_tier', 'platinum');
                              ?> Platinum
                            </label>
                            <label class="radio-inline">
                              <?php 
                               if($details[0]['membership_tier'] =='diamond')
                               echo form_radio('membership_tier', 'diamond',TRUE);
                               else
                               echo form_radio('membership_tier', 'diamond');
                              ?> Diamond
                            </label>
                           
                        </div>  
                        <div class="col-lg-3 padding-right-none">
                            <label class="control-label">Card Status </label>
<?php echo form_dropdown('card_status', $card_status, $details[0]['card_status'], "class=form-control id=card_status "); ?> 
                        </div>    
                        <div class="col-lg-3">
                            <label class="control-label">Valid Thru </label>
<?php echo form_input($valid_thru); ?>
                        </div>
                    </div><!-- form-group -->
                        
                        <div class="form-group">
                        
                        <div class="col-lg-6">
                            <label class="control-label">Membership Number </label>
                            <?php echo form_input($card_num); ?> 
                        </div>
                        <div class="col-lg-6">
                            <label class="control-label">Bonuslink Number </label>
                            <?php echo form_input($Bonuslink_num); ?> 
                        </div>  
                        
                     </div>  <!-- form-group -->
                     
                     
                      <div class="form-group">
                        <div class="col-lg-6">
                            <label class="control-label ">Member Type :</label>
                            <div class="clearfix"></div>
                           <label class="radio-inline">
                              <?php
                              if($details[0]['membership_type'] =='primary')
                              echo form_radio('membership_type','primary',TRUE,'id = member_type_primary'); 
                              else
                              echo form_radio('membership_type','primary',FALSE,'id = member_type_primary');    
                              ?> Primary
                            </label>
                            <label class="radio-inline">
                             <?php 
                             if($details[0]['membership_type'] =='supplementary')
                              echo form_radio('membership_type','supplementary',TRUE,'id = member_type_supplementary'); 
                              else
                              echo form_radio('membership_type','supplementary',FALSE,'id = member_type_supplementary'); 
                             ?> Supplementary
                            </label>
                          </div>
                        <div class="col-lg-6" id="find_primary_men_holder" <?php if($details[0]['membership_type'] =='supplementary') echo 'style="display: block"'; else echo 'style="display: none"'  ?>  >
                        If sign up as supplementary please choose  the principle card holder
                            <input type="button"  class="btn btn-sm btn-primary" name="find_primary_men" data-customer_id="<?php echo $details[0]['customer_id'] ?>" id="find_primary_men" value="Find Membership"/>
                        </div>
                    </div> <!-- form-group -->
                    <div class="clearfix"></div>
                     <div class="form-group" id="parent_card" <?php if($details[0]['membership_type'] =='supplementary') echo 'style="display: block"'; else echo 'style="display: none"'  ?>>
                        <div class="col-lg-6">
                            <label class="control-label">Principal Card holder Name  </label>
                        <?php echo form_input($p_card_holder); ?> 
                        <!--<input type="hidden" name="p_card_holder_id" id="p_card_holder_id" />-->
                        </div>
                        <div class="col-lg-6">
                            <label class="control-label">Parkson Card Number  </label>
                        <?php echo form_input($p_card_number); ?> 
                        </div>
                    </div>  <!-- form-group -->
                     <div class="clearfix"></div>
                     
                     <div class="form-group">

                        <div class="col-lg-6">
                            <label class="control-label">Subscribe To Mobile Alert</label>
                            <div class="clearfix"></div>
                                <label class="radio-inline">
                                  <?php 
                                  if($details[0]['mobile_alert']=='1')
                                  echo form_radio('mobile_alert', '1', TRUE); 
                                  else
                                  echo form_radio('mobile_alert', '1');
                                  ?> Yes
                                </label>
                                <label class="radio-inline">
                                  <?php
                                  if($details[0]['mobile_alert']=='0')
                                  echo form_radio('mobile_alert', '0', TRUE);
                                  else   
                                  echo form_radio('mobile_alert', '0');   
                                  ?> No
                                </label>
                        </div>   
                        <div class="col-lg-6">
                            <label class="control-label">Subscribe To Newsletter</label>
                            <div class="clearfix"></div>
                            <label class="radio-inline">
                              <?php 
                              if($details[0]['newsletter']=='1')
                              echo form_radio('newsletter', '1', TRUE);
                              else 
                              echo form_radio('newsletter', '1');
                              ?> Yes
                            </label>
                            <label class="radio-inline">
                              <?php
                              if($details[0]['newsletter']=='0')
                              echo form_radio('newsletter', '0',TRUE);
                              else
                              echo form_radio('newsletter', '0');
                              ?> No
                            </label>
                        </div> 

                    </div> <!-- form-group -->
                          
                     <div class="clearfix"></div>
                    <div class="form-group">
                       <div class="col-lg-12">
                            <label class="control-label">Remarks</label>
                            <div class="clearfix"></div>
                             <textarea class="form-control" name="remarks" id="remarks" rows="4" maxlength="500"><?php echo $details[0]['remarks'] ?></textarea>   
                        </div>   
                    </div> <!-- form-group -->
                    <div class="clearfix"></div>
                    <div class="form-group">
                      <div class="col-lg-6">
                            <label class="control-label">Company Name </label>
                            <?php echo form_input($company_name); ?> 
                        </div> 
                    </div> <!-- form-group -->
                   </div><!-- col-md-6 -->
                   <input name="parent_id" id="parent_id" value="<?php echo $details[0]['parent_id'] ?>" type="text" style="display: none;" >
                   <input name="customer_id" value="<?php echo $details[0]['customer_id'] ?>"  type="hidden" >

           
                   <div class="clearfix"></div>
                    <div class="form-group form-actions">
                        <div class="col-lg-12">
                            <input type="submit" name='edit_customer_byadmin' id='add_location' class="btn btn-success pull-right" value="Save Changes"/>
                        </div>
                        <div class="clearfix"></div>
                    </div>






<?php echo form_close(); ?>
                </div>

            </div>

        </div>


    </section><!-- /.content -->
</aside><!-- /.right-side -->


<div class="modal fade" id="findModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width: 90%;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Find Membership</h4>
      </div>
      <div class="modal-body">
        <div id="find_response"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script src="<?php echo base_url('assets/js/moment.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.mask.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>
<script>
var ajaxInProgress = false;
    $(function () {
        $("#dob1").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            yearRange: "-100:+0",
            maxDate:new Date(<?php echo (date('Y',time())-18); ?>,11,31),
            
        });
        
         $('#membership_num1').mask('0000000000000000');
         $('#Bonuslink_num').mask('0000000000000000');
         
check_for_malaysian();
 //prevent enter key 
  $('#membership_num1').keypress(function(event) {
        if (event.keyCode == 13) {
            event.preventDefault();
        }
    });
    
   $('#Bonuslink_num').keypress(function(event) {
        if (event.keyCode == 13) {
            event.preventDefault();
        }
   });
      });

   
    function bonuslink_validation()
    {
        var Bonuslink_num = $.trim($('#Bonuslink_num').val());
        if ( Bonuslink_num.length > 0) {
              if ( Bonuslink_num.length > 16) {
                    $('#Bonuslink_num').css('border', '1px solid red');
                    $('#Bonuslink_num').focus();
                    return false;
                }
                else {
                    $('#Bonuslink_num').css('border', '1px solid #cccccc');
                    return true;
                }
      }
      else {
        $('#Bonuslink_num').css('border', '1px solid #cccccc');
        return true;
      }             
    }
    

    $(document).on('click', '#member_type_supplementary', function (e) {
        $('#find_primary_men_holder').show();
        $('#parent_card').slideDown('fast');
        
    });

    $(document).on('click', '#member_type_primary', function (e) {
        $('#find_primary_men_holder').hide();
        $('#parent_card').slideUp('fast');
         $('#parent_id').val('0');
    });

   

    function email_validation(id)
    {
        var el_val = $.trim($("#" + id).val());
        if (el_val == "" || el_val == 0){ 
        $("#" + id).css('border', '1px solid red');
        return false;
        }
            var atpos = el_val.indexOf("@");
            var dotpos = el_val.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= el_val.length) {
                $("#" + id).css('border', '1px solid red');
                return false;
            }
            else
            {
                $("#" + id).css('border', '1px solid #cccccc');
                 return true;
            }
        
    }

    function mobile_validaton(id)
    {
        var el_val = $.trim($("#" + id).val());
           
           if (el_val == "" || el_val == 0) 
            {
                $("#" + id).css('border', '1px solid red');
                return false;
            }

            else
            {
                $("#" + id).css('border', '1px solid #cccccc');
                return true;
            }
       
    }
    
     function passport_validaton()
    {
        var el_val = $.trim($("#passport_num").val());
       
            if (el_val == "" || el_val == 0) 
            {
                $("#passport_num").css('border', '1px solid red');
                return false;
            }
            else
            {
                $("#passport_num").css('border', '1px solid #cccccc');
                return true;
            }
       
    }
    
    
function parkson_card_num( id) 
{
    
       
         var el_val = $.trim( $("#" + id).val() );
        if ( el_val.length > 16 || el_val == "" || el_val == 0) {
            $("#" + id).css('border', '1px solid red');
            return false;
        }
        else {
            $("#" + id).css('border', '1px solid #cccccc');
             return true;
            }
     
    
}


     
     

    
function required_validation( id )
{
    
    if(typeof id==='string')
    var id = [id];
    var bad = 0;
     $.each(id,function(i){
       // alert(id[i]);
         var el_val = $.trim($("#" + id[i]).val());
        if (el_val == "" || el_val == 0) {
            $("#" + id[i]).css('border', '1px solid red');
            bad =1;
        }
        else {
            $("#" + id[i]).css('border', '1px solid #cccccc');
            
            //auto fill dob on the basis on NRIC1
             //if we have got a perfect 6, then we will autofill DOB
             if(id[i]=='nric_num_1' && el_val.length==6) {
                    var nric_1_val = $.trim($('#nric_num_1').val());
                    var year = String(19)+ String(nric_1_val[0])+String(nric_1_val[1]);
                    var month = parseInt(String(nric_1_val[2])+String(nric_1_val[3]));
                    var day = String(nric_1_val[4])+String(nric_1_val[5]);
                    $('#dob1').val(day+"-"+month+"-"+year);   
            }
            
            
            //auto fill gender on the basis on NRIC3
             //if we have got a perfect 6, then we will autofill DOB
             if(id[i]=='nric_num_3' && el_val.length==4) {
                    var nric_3_val = $.trim($('#nric_num_3').val());
                    if(parseInt(nric_3_val)%2==0)
                    $('#gender_female').trigger('click');
                    else
                    $('#gender_male').trigger('click');
            }
            return true;
        }
    });
    
    if(bad==1) return false;
    return true;
  
}

$(document).on('submit', '#customer_profile_edit_form', function (e) {
   
        e.preventDefault();
        
        //validate form
          if($('#race1').val()=='Other')
          {
              var required = ['f_name1','nationality1','address_11','custome_race','member_since1'];
          }
          else
          {
              var required = ['f_name1','nationality1','address_11','race1','member_since1'];
          }
        
        if($('#member_type_supplementary').is(':checked'))
        {
            required.push('p_card_holder');
            required.push('p_card_number');
        }
        
        
      var r1 =   required_validation(required);
      if(!passport_validaton() || $.trim($('#nationality1').val())=='Malaysian' || $.trim($('#nationality1').val())=='malaysian') {//only one is required between NRIC and PASSPORT 
        var r5 =   nric_width();
      }
      else{
        var r5 = true;
        $('#nric_num_1').css('border', '1px solid #cccccc');
        $('#nric_num_2').css('border', '1px solid #cccccc');
        $('#nric_num_3').css('border', '1px solid #cccccc');
      }
      
      if(!r5)
      {
         var r8 =   passport_validaton();
      }
      else{
        $("#passport_num").css('border', '1px solid #cccccc');    
        var r8 = true;
      }
     
      
      var r6 =   parkson_card_num('membership_num1');
      var r9 = bonuslink_validation();
      
      if(!r1 || !r5 || !r6 || !r8 || !r9)
      return false;
      
      
  
      //checking age for under 100 age
      if($.trim($('#dob1').val()).length > 0){
       var val = $('#dob1').val()//dd-mm-yyyy
       var split_date = val.split('-');
       var dd = split_date[0] ;
       var mm = split_date[1];
       var yyyy = split_date[2]; 
       var r8 =  validateDate(yyyy+"-"+mm+"-"+dd);
       if(!r8)
       return false;
       }
         
      
      $("#Bonuslink_num").css('border', '1px solid #cccccc');
        
        var from_values = $(this).serialize();
        
        if(ajaxInProgress) return;
        ajaxInProgress = true;
        
        $.ajax({
            url: '<?php echo site_url('membership/edit_customer_byadmin') ?>',
            dataType: 'json',
            type: 'POST',
            data: from_values,
            success: function (result)
            {
                if (result.status == 1) {
                    
                    $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-success  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    setTimeout(function () {
                        $('#disappear').fadeOut('slow')
                    }, 3000);
                }
                else if (result.status == 2) {
                    $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-info  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    setTimeout(function () {
                        $('#disappear').fadeOut('slow')
                    }, 3000);
                }
                else
                {
                    $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    
                }
                $('html, body').animate({scrollTop : 0},800);
                
                ajaxInProgress = false;
                
            }
        });
    });


//for hide/show of state dropdown vs text box
$(document).on('change','#country',function(){
   
   if(this.value=='Malaysia')
  {
    $('#state').val('');
    $('#state').addClass('hide');
    $('#m_state').removeClass('hide');
  } 
  else
  {
      $('#m_state').val('0');
      $('#m_state').addClass('hide');
      $('#state').removeClass('hide');
  }
   
});

//find membership dialog box
$(document).on('click','#find_primary_men',function(e){
    e.preventDefault();
    var c_id = $(this).attr('data-customer_id');
    $.ajax({
       url:'<?php echo site_url('membership/customer_list_for_find_dialog_box/') ?>'+'/'+c_id,
       dataType: 'html',
       success:function(result)
       {
        $('#find_response').empty().html(result);
       } 
    });
    $('#findModal').modal('show');
    
});

//select a member from find dialog
$(document).on('click','.select_member',function(e){
    e.preventDefault();
   
     var return_val;
    $.ajax({
        url: '<?php echo site_url('membership/is_supp_limit_reached') ?>/'+$(this).data('customer_id'),
        dataType: 'json',
        async: false,
        success: function (result)
        {
            if (result.status == 1) {
                return_val = false;
                $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                $('html, body').animate({scrollTop : 0},800);
            }
            else{
                $('#alert_area_edit_by_admin_frm').empty();
                return_val = true;
            }
         }
    });
    if(!return_val) {
        
     $('#findModal').modal('hide');
     $('#p_card_holder').val('');
     $('#p_card_number').val('');
     $('#p_card_holder_id').val('');
     return false;
    }
   
    $('#p_card_holder').val($(this).data('name'));
    $('#p_card_number').val($(this).data('card_no'));
    $('#p_card_holder_id').val($(this).data('customer_id'));
    
    $('#parent_id').val($(this).data('customer_id'));
    
    $('#findModal').modal('hide');
    
});
$(document).ready(function (){
   var DDval ='<?php echo $details[0]['country'] ?>';
   $('#country option[value="' + DDval + '"]').prop('selected', true); 
   
   //code for disply dd or input box of state
   
   var countryVal = $('#country').val();
   if(countryVal == 'Malaysia')
   {
    $('#state').addClass('hide');
    $('#m_state').removeClass('hide');
   }
   else
   {
      $('#m_state').addClass('hide');
      $('#state').removeClass('hide');
   }
   
   
   
});
//fill dob into nric_1 

$(document).on('change','#dob1x',function(e){
   var val = $(this).val();//00-00-0000
   var split_date = val.split('-');
   var dd = split_date[0] ;
   var mm = split_date[1];
   var yy = split_date[2].charAt(2)+split_date[2].charAt(3); 
   
   $('#nric_num_1').val(yy+mm+dd);
})

//fill parkson card num value into card field

$(document).on('keyup','#membership_num1',function(){
    $('#card_num').val($(this).val());
})

//manually input Race on seletection other
$(document).on('change','#race1',function(){
   var country = $(this).val();
   if(country =='Other')
   {
       $('#custome_race').val('');
       $(this).parent().removeClass('col-lg-6');
       $(this).parent().addClass('col-lg-3');
        $('#custome_race_div').show();
       
   }
   else
   {
       $('#custome_race_div').hide();
        $(this).parent().removeClass('col-lg-3');
        $(this).parent().addClass('col-lg-6');
   }
    
})
function  nric_width()
{
        var nric_1 = $.trim($('#nric_num_1').val().length);
        var nric_2 = $.trim($('#nric_num_2').val().length);
        var nric_3 = $.trim($('#nric_num_3').val().length);
        var bad = 0;
        if (nric_1 != 6) {
            $('#nric_num_1').css('border', '1px solid red');
            bad = 1;
        }
        else {
            $('#nric_num_1').css('border', '1px solid #cccccc');
        }

         if (nric_2 != 2) {
            $('#nric_num_2').css('border', '1px solid red');
            bad = 1;
        }
        else {
            $('#nric_num_2').css('border', '1px solid #cccccc');
        }
        
         if (nric_3 != 4) {
            $('#nric_num_3').css('border', '1px solid red');
            bad = 1;
        }
        else {
            $('#nric_num_3').css('border', '1px solid #cccccc');
        }
        

       if(bad==1) return false;
      return true;
  
}

function validateDate(date){
   
    var HYearsAgo = moment().subtract(100, "years");
    var birthday = moment(date,"YYYY-MM-DD");
    var minimumAge = moment().subtract(18, "years");
   
    var message;
    if (!birthday.isValid()) {
        message = "Invalid Date of Birth";
        $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +message + '</div>');
        $('html, body').animate({scrollTop : 0},800);
        return false;                   
    }
    else if (HYearsAgo.isAfter(birthday)) {
        message = "Customer's age should be under 100 years.";
        $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +message + '</div>');
        $('html, body').animate({scrollTop : 0},800);
        return false;     
    }
    else if (minimumAge.isBefore(birthday)) {
        message = "Customer should be at least 18 years old.";
        $('#alert_area_edit_by_admin_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear1"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +message + '</div>');
        $('html, body').animate({scrollTop : 0},800);
        return false;     
    }
    else {
        $('#alert_area_edit_by_admin_frm').empty();
       return true;      
    }
}


//Malysian Nationality

function check_for_malaysian()
{
    if($.trim($('#nationality1').val())=='Malaysian' || $.trim($('#nationality1').val())=='malaysian')
    {
        $('.pass_section').addClass('hide');
        $('.pass_or').addClass('hide');
    }
    else
    {
        $('.pass_section').removeClass('hide');
        $('.pass_or').removeClass('hide');
    }
}

$(document).on('keyup','#nationality1',check_for_malaysian);

</script>

<?php
//print_r($details);
}
?>


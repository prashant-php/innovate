<?php
if($details)
{
 
    $date_format = $this->config->item('date_format', 'tank_auth');
?>
    <table class="table table-bordered table-striped">
    <tr>
    <th>Column Name</th>
    <th>Old Value</th>
    <th>New Value</th>
    </tr>
        <?php foreach($details as $key=>$val)
        {
            if($details[$key]["column_name"]!='parent_id'){
         ?>
            
       
        <tr>
            <td><?php echo htmlspecialchars(ucfirst(str_replace('_',' ',$details[$key]["column_name"]))); ?></td>
            <td><?php echo htmlspecialchars($details[$key]["old_value"]); ?></td>
            <td><?php echo htmlspecialchars($details[$key]["new_value"]); ?></td>
        </tr>
    
       <?php
       }
        } ?>
            
        
       
      
    </table>
   
<?php    
}
?>
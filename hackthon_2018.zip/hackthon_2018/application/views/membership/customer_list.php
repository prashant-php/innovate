<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$f_name = array(
    'name' => 'f_name',
    'id' => 'f_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'First Name',
);
$l_name = array(
    'name' => 'l_name',
    'id' => 'l_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'Last Name',
);
$email = array(
    'name' => 'email',
    'id' => 'email',
    'class' => 'form-control input-sm',
    'placeholder' => 'Email Address',
);
$NRIC_no = array(
    'name' => 'NRIC_no ',
    'id' => 'NRIC_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'NRIC Number',
);
$mobile_no = array(
    'name' => 'mobile_no',
    'id' => 'mobile_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Moblie Number',
);
$passport_no = array(
    'name' => 'passport_no',
    'id' => 'passport_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Passport Number',
);
$card_no = array(
    'name' => 'card_no',
    'id' => 'card_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Membership Number',
);

$membership_no = array(
    'name' => 'membership_no',
    'id' => 'membership_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Parkson Card Number',
);

$bonus_card_no = array(
    'name' => 'bonus_card_no',
    'id' => 'bonus_card_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Bonuslink Card Number',
    'maxlength' => "16"
);
$address = array(
    'name' => 'address',
    'id' => 'address',
    'class' => 'form-control input-sm',
    'placeholder' => 'Address',
);
$city = array(
    'name' => 'city',
    'id' => 'city',
    'class' => 'form-control input-sm',
    'placeholder' => 'City',
);
$company_name = array(
    'name' => 'company_name',
    'id' => 'company_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'Company name',
);

$card_min_val = array(
    'name' => 'card_min_val',
    'id' => 'card_min_val',
    'class' => 'form-control input-sm pull-left',
    'style' => 'width:50%',
    'placeholder' => 'From',
);

$card_max_val = array(
    'name' => 'card_max_val',
    'id' => 'card_max_val',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'To',
    'style' => 'width:50%',
    'onblur'=>'return chk_card_range()'
);


$date_form = array(
    'name' => 'date_form',
    'id' => 'date_form',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'From Date',
    'style' => 'width:50%',
    'readonly' => 'readonly'
);

$date_to = array(
    'name' => 'date_to',
    'id' => 'date_to',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'To Date',
    'style' => 'width:50%',
    'readonly' => 'readonly'
);

$Export_date_form = array(
    'name' => 'export_date_form',
    'id' => 'export_date_form',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'From',
    'style' => 'width:30%;',
    'readonly' => 'readonly'
);

$Export_date_to = array(
    'name' => 'export_date_to',
    'id' => 'export_date_to',
    'class' => 'form-control  pull-left input-sm',
    'placeholder' => 'To',
    'style' => 'width:30%;',
    'readonly' => 'readonly'
);

$Date_of_export_history_form = array(
    'name' => 'history_export_date_form',
    'id' => 'history_export_date_form',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'From',
    'style' => 'width:30%;',
    'readonly' => 'readonly'
);

$Date_of_export_history_to = array(
    'name' => 'history_export_date_to',
    'id' => 'history_export_date_to',
    'class' => 'form-control  pull-left input-sm',
    'placeholder' => 'To',
    'style' => 'width:30%;',
   'readonly' => 'readonly'
);






$store_location[0] = 'Select location of store';
foreach ($location as $location)
{
    $store_location[$location['location_id']] = $location['location_name'];
}




?>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">                
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1 class="pull-left">
<?php echo @$title; ?>
<img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id="progress" style="margin-left: 10px;" />
        </h1>
        <div class="pull-right">
         <button type="button" class="btn btn-default " data-toggle="collapse" data-target="#export_csv_box" >  <i class="fa fa-list"></i>  Export</button>
         <a href="<?php echo site_url('membership/archive_customer_list');?>"  class="btn btn-default" > <i class="fa fa-folder"></i>   Archive List  </a>  
         <button type="button" class="btn btn-default " data-toggle="collapse" data-target="#adv_search">
            <i class="fa fa-filter"></i>  Advanced Search
        </button> 
        </div>
        <div class="clearfix"></div>
    </section>
    <div class="clearfix"></div>
   <!-- Main content -->
    <section class="content">
         <div class="row">
            <div class="col-md-12" class="btn">
               
                    <div id="alert_area">
              <?php
              $msg = $this->session->flashdata('text');
              $class = $this->session->flashdata('class');
              if($msg)
              {
              ?>  
                <div class="alert alert-<?php echo $class; ?> alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <?php echo $msg; ?>
                </div>
              <?php  
              }
              ?>
        </div>
                
                <div class="export_csv_box collapse" id="export_csv_box" style="overflow: auto;">
               <?php echo form_open(site_url('membership/generate_csv'), array('class' => '', 'role' => 'form', 'id' => 'export_csv_form')); ?>
                      <div class="form-group col-md-6">
                           <h5>Export Members CSV</h5>
                           <div class="clearfix"></div>
                             <?php echo form_input($Export_date_form); ?>
                             <?php echo form_input($Export_date_to); ?>
                             <input type="hidden" name="hidden_f_name"        id="hidden_f_name"/>
                             <input type="hidden" name="hidden_l_name"        id="hidden_l_name"/>
                             <input type="hidden" name="hidden_email"         id="hidden_email"/>
                             <input type="hidden" name="hidden_mobile_no"     id="hidden_mobile_no"/>
                             <input type="hidden" name="hidden_NRIC_no"       id="hidden_NRIC_no"/>
                             <input type="hidden" name="hidden_passport_no"   id="hidden_passport_no"/>
                             <input type="hidden" name="hidden_bonus_card_no" id="hidden_bonus_card_no"/>
                             <input type="hidden" name="hidden_issue_store"   id="hidden_issue_store"/>
                             <input type="hidden" name="hidden_address"       id="hidden_address"/>
                             <input type="hidden" name="hidden_city"          id="hidden_city"/>
                             <input type="hidden" name="hidden_company_name"  id="hidden_company_name"/>
                             <input type="hidden" name="hidden_card_no"       id="hidden_card_no"/> 
                             <input type="hidden" name="hidden_membership_no" id="hidden_membership_no"/>
                             <input type="hidden" name="hidden_card_min_val"  id="hidden_card_min_val"/> 
                             <input type="hidden" name="hidden_card_max_val"  id="hidden_card_max_val"/>
                             <input type="hidden" name="hidden_card_tier"  id="hidden_card_tier"/> 
                             <input type="hidden" name="hidden_card_type"  id="hidden_card_type"/>
                             <button type="submit" class="btn btn-success btn-sm" style="margin-left: 5px;"><i class="fa fa-download"> Download</i> </button>
                     
                     </div>  
                     
               <?php echo form_close(); ?>  
                  <?php echo form_open(site_url('membership/generate_customer_history_csv'), array('class' => '', 'role' => 'form', 'id' => 'export_customer_history_csv_form')); ?>
                      <div class="form-group col-md-6">
                           <h5>Export Members History CSV</h5>
                           <div class="clearfix"></div>
                             <?php echo form_input($Date_of_export_history_form); ?>
                             <?php echo form_input($Date_of_export_history_to); ?>
                              <input type="hidden" name="hidden_f_name"        id="hidden_f_name_h"/>
                             <input type="hidden" name="hidden_l_name"        id="hidden_l_name_h"/>
                             <input type="hidden" name="hidden_email"         id="hidden_email_h"/>
                             <input type="hidden" name="hidden_mobile_no"     id="hidden_mobile_no_h"/>
                             <input type="hidden" name="hidden_NRIC_no"       id="hidden_NRIC_no_h"/>
                             <input type="hidden" name="hidden_passport_no"   id="hidden_passport_no_h"/>
                             <input type="hidden" name="hidden_bonus_card_no" id="hidden_bonus_card_no_h"/>
                             <input type="hidden" name="hidden_issue_store"   id="hidden_issue_store_h"/>
                             <input type="hidden" name="hidden_address"       id="hidden_address_h"/>
                             <input type="hidden" name="hidden_city"          id="hidden_city_h"/>
                             <input type="hidden" name="hidden_company_name"  id="hidden_company_name_h"/>
                             <input type="hidden" name="hidden_card_no"       id="hidden_card_no_h"/> 
                             <input type="hidden" name="hidden_membership_no" id="hidden_membership_no_h"/> 
                             <input type="hidden" name="hidden_card_min_val"  id="hidden_card_min_val_h"/> 
                             <input type="hidden" name="hidden_card_max_val"  id="hidden_card_max_val_h"/>
                             <input type="hidden" name="hidden_card_tier"  id="hidden_card_tier_h"/> 
                             <input type="hidden" name="hidden_card_type"  id="hidden_card_type_h"/>
                        
                             <button type="submit" class="btn btn-success btn-sm" style="margin-left: 5px;"><i class="fa fa-download"> Download</i> </button>
                     <div class="clearfix"></div>
                     </div>  
                      <div class="clearfix"></div>
               <?php echo form_close(); ?>    
                </div>
             
     
                
                
                
                
                    <div class="adv_search_box collapse" id="adv_search">
                    <?php echo form_open(site_url('membership/customer_list'), array('class' => '', 'role' => 'form', 'id' => 'customer_search_form')); ?>
                      <div class="form-group col-md-3">
                            <label class="control-label">First Name </label>
                            <?php echo form_input($f_name); ?> 
                       </div> 
                       <div class="form-group col-md-3">
                             <label class="control-label">Last Name </label>
                             <?php echo form_input($l_name); ?> 
                      </div>  
                       <div class="form-group col-md-3">
                            <label class="control-label">Email</label>
                             <?php echo form_input($email); ?>
                       </div>
                     <div class="form-group col-md-3">
                            <label class="control-label">Mobile No</label>
                             <?php echo form_input($mobile_no); ?>
                    </div>
                    <div class="clearfix"></div>
                    
                    
                    <div class="form-group col-md-3">
                            <label class="control-label">NRIC </label>
                            <?php echo form_input($NRIC_no); ?> 
                       </div> 
                       <div class="form-group col-md-3">
                             <label class="control-label">Passport No </label>
                             <?php echo form_input($passport_no); ?> 
                      </div>  
                       <div class="form-group col-md-3">
                            <label class="control-label">Parkson Card Number</label>
                             <?php echo form_input($membership_no); ?>
                       </div>
                     <div class="form-group col-md-3">
                            <label class="control-label">Bonuslink Card No</label>
                             <?php echo form_input($bonus_card_no); ?>
                    </div>
                    <div class="clearfix"></div>
                    
                    
                      <div class="form-group col-md-3">
                           <label class="control-label">Issuing Store</label>
                            <?php echo form_dropdown('issue_store', $store_location, '0', 'class="form-control input-sm" id="location" '); ?> 
                       </div> 
                       <div class="form-group col-md-3">
                             <label class="control-label">Address</label>
                             <?php echo form_input($address); ?>
                      </div>  
                       <div class="form-group col-md-2">
                            <label class="control-label">City</label>
                             <?php echo form_input($city); ?>
                       </div>
                       <div class="form-group col-md-2">
                            <label class="control-label">Company Name</label>
                             <?php echo form_input($company_name); ?>
                       </div>
                        <div class="form-group col-md-1">
                            <label class="control-label">Tier</label>
                            <select name="tier_dd" id="tier_dd" class="form-control input-sm">
                                <option value="0">All</option>
                                <option value="gold">Gold</option>
                                <option value="platinum">Platinum</option>
                                <option value="diamond">Diamond</option>
                            </select>
                       </div>
                        <div class="form-group col-md-1">
                            <label class="control-label">Type</label>
                              <select name="type_dd" id="type_dd" class="form-control input-sm">
                                <option value="0">All</option>
                                <option value="primary">Primary</option>
                                <option value="supplementary">Supplementary</option>
                                
                            </select>
                       </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-md-3">
                            <label class="control-label">Membership Number</label>
                             <?php echo form_input($card_no); ?>
                       </div>
                    <div class="form-group col-md-3">
                             <label class="control-label">Card Number Range</label>
                             <div class="clearfix"></div>
                              <?php echo form_input($card_min_val); ?>
                              <?php echo form_input($card_max_val); ?>
                    </div>
                    
                     <div class="form-group col-md-3">
                             <label class="control-label">Date Range</label>
                             <div class="clearfix"></div>
                             <?php echo form_input($date_form); ?>
                             <?php echo form_input($date_to); ?>
                     </div>
                     <div class="form-group col-md-3">
                     <br />
                    <input type="submit" name='search_customer' id='search_customer' class="btn btn-primary pull-right " value="Search"/>
                     </div>
                    <div class="clearfix"></div>
                    
                    
                  <?php echo form_close(); ?>                   
                  </div>  
                   <div class="clearfix"></div> 
                    <table id="ajax_datatable" class="table table-bordered table-striped dataTable">
                        <thead>
                            <tr class="tableheader tableheader-blue">
                                <th style="width: 140px;" >Date Joined</th>
                                <th >First Name</th>
                                <th >Last Name</th>
                                <th >Parkson Card Number</th>
                                <th >Membership Type</th>
                                <th >Membership Tier</th>
                                <th >Expiration Date</th>
                                <th>Captured By:</th>
                                <th style="width: 120px;">Actions</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
       

    </section><!-- /.content -->
</aside><!-- /.right-side -->

   <!--View Modal -->
<div class="modal fade" id="view_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="width: 80%;" >
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Membership Details</h4>
      </div>
      <div class="modal-body">
       <div id="response_view"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary pull-left hide" data-customer_id="0" id="supplementary">Show Supplementary</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Back</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

  
 <!--Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
  <div class="modal-dialog" style="width: 80%">
    <div class="modal-content"  id="edit_form_response">
     
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.mask.min.js'); ?>"></script>
<script>
    var months = new Array(12);
    months[1] = "January";
    months[2] = "February";
    months[3] = "March";
    months[4] = "April";
    months[5] = "May";
    months[6] = "June";
    months[7] = "July";
    months[8] = "August";
    months[9] = "September";
    months[10] = "October";
    months[11] = "November";
    months[12] = "December";
        
        
        
    
    $(document).ready(function () {
        
        
        $('#progress').hide();
        var f_name = 0;
        var l_name = 0;
        var email = 0;
        var NRIC_no = 0;
        var mobile_no = 0;
        var passport_no = 0;
        var card_no = 0;
        var membership_no = 0;
        var bonus_card_no = 0;
        var address = 0;
        var city = 0;
        var company_name = 0;
        var card_min_val = 0;
        var card_max_val = 0;
        var date_form = 0;
        var date_to = 0;
        var location = 0;
        var tier = 0;
        var type = 0;
        
         $(document).on('submit','#export_csv_form',function(e){
              $('#hidden_f_name').val(f_name);                                 
              $('#hidden_l_name').val(l_name);                   
              $('#hidden_email').val(email);              
              $('#hidden_mobile_no').val(mobile_no);                 
              $('#hidden_NRIC_no').val(NRIC_no);                    
              $('#hidden_passport_no').val(passport_no);                
              $('#hidden_bonus_card_no').val(bonus_card_no);                  
              $('#hidden_issue_store').val(location);                  
              $('#hidden_address').val(address);                   
              $('#hidden_city').val(city);                  
              $('#hidden_card_no').val(card_no); 
              $('#hidden_membership_no').val(membership_no); 
              $('#hidden_card_min_val').val(card_min_val);                 
              $('#hidden_card_max_val').val(card_max_val);    
              $('#hidden_card_tier').val(tier);    
              $('#hidden_card_type').val(type);                
     
              
     
                var required = ['export_date_form','export_date_to'];
                 var r1 =   required_validation(required);
                 if(!r1)
                   return false;
 });
 
   $(document).on('submit','#export_customer_history_csv_form',function(e){
              $('#hidden_f_name_h').val(f_name);                                 
              $('#hidden_l_name_h').val(l_name);                   
              $('#hidden_email_h').val(email);              
              $('#hidden_mobile_no_h').val(mobile_no);                 
              $('#hidden_NRIC_no_h').val(NRIC_no);                    
              $('#hidden_passport_no_h').val(passport_no);                
              $('#hidden_bonus_card_no_h').val(bonus_card_no);                  
              $('#hidden_issue_store_h').val(location);                  
              $('#hidden_address_h').val(address);                   
              $('#hidden_city_h').val(city);                  
              $('#hidden_card_no_h').val(card_no);
              $('#hidden_membership_no_h').val(membership_no); 
              $('#hidden_card_min_val_h').val(card_min_val);                 
              $('#hidden_card_max_val_h').val(card_max_val);    
              $('#hidden_card_tier_h').val(tier);    
              $('#hidden_card_type_h').val(type);                
     
              
     
                var required = ['history_export_date_form','history_export_date_to'];
                 var r1 =   required_validation(required);
                 if(!r1)
                   return false;
 });
        
     
        ajax_datatable = $('table#ajax_datatable').dataTable({
            "bServerSide": true,
            "sAjaxSource": "<?php echo site_url('membership/get_customer_list'); ?>",
            "sPaginationType": "full_numbers",
             "fnServerData": function (sSource, aoData, fnCallback)
            {
                $('#progress').show();
                aoData.push({name: "f_name", value: f_name});
                aoData.push({name: "l_name", value: l_name});
                aoData.push({name: "email", value: email});
                aoData.push({name: "NRIC_no", value: NRIC_no});
                aoData.push({name: "mobile_no", value: mobile_no});
                aoData.push({name: "passport_no", value: passport_no});
                aoData.push({name: "bonus_card_no", value: bonus_card_no});
                aoData.push({name: "card_no", value: card_no});
                aoData.push({name: "membership_no", value: membership_no});
                aoData.push({name: "address", value: address});
                aoData.push({name: "city", value: city});
                aoData.push({name: "company_name", value: company_name});
                aoData.push({name: "card_min_val", value: card_min_val});
                aoData.push({name: "card_max_val", value: card_max_val});
                aoData.push({name: "date_form", value: date_form});
                aoData.push({name: "date_to", value: date_to});
                aoData.push({name: "location", value: location});
                aoData.push({name: "membership_tier", value: tier});
                aoData.push({name: "membership_type", value: type});
                $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": sSource,
                    "data": aoData,
                    "success": fnCallback
                });
            },
            "fnDrawCallback": function () {
                $('#progress').fadeOut();
            },
            "fnRowCallback": function (nRow, aData, iDisplayIndex) {
                var links = "";

                links += '<a href="#" data-customer_id="' + aData[8] + '" title="View Customer" class="btn btn-primary btn-xs view_customer" style="margin-right:5px;" ><span class="fa fa-search"></span></a>';
                links += '<a href="#" data-customer_id="' + aData[8] + '" data-is_admin="<?php echo $this->tank_auth->is_admin(); ?>" data-is_manager="<?php echo $this->tank_auth->is_manager(); ?>"  title="Edit Customer" class="btn btn-primary btn-xs edit_customer"  style="margin-right:5px;"><span class="fa fa-pencil"></span></a>';
                links += '<a href="#" data-customer_id="' + aData[8] + '" title="Archive Customer" class="btn btn-warning btn-xs archive_customer"><span class="fa  fa-folder"></span></a>';
                $('td:eq(8)', nRow).html(links);



                var dateSplit = aData[0].split("-");
                day = dateSplit[2].split(' ');
                var curr_date = day[0];
                   
                if(dateSplit[1].replace(/^0+/, '').length=="1")
                dateSplit[1]= dateSplit[1].replace(/^0+/, '');
                
                var curr_month = months[dateSplit[1]]; //Months are zero based
                var curr_year = dateSplit[0];
               $('td:eq(0)', nRow).html(curr_date + " " + curr_month + " " + curr_year);
              
                var dateSplit = aData[6].split("-");
                day = dateSplit[2].split(' ');
                var curr_date = day[0];
                var curr_month = months[dateSplit[1]]; //Months are zero based
                var curr_year = dateSplit[0];
                $('td:eq(6)', nRow).html(curr_month + " " + curr_year);

                //staff name
                // $('td:eq(7)', nRow).html(aData[7]+" "+aData[9]);
                
                return nRow;
            },
            aaSorting : [[0, 'desc']],
            aoColumnDefs: [
              {
                 bSortable: false,
                 aTargets: [8]
              }
            ]
             
        });
    //ajax_datatable.fnSort( [ [0,'desc']] );   
    
    
    $(document).on('submit','#customer_search_form',function(e){
    e.preventDefault();
    f_name = $("#f_name").val();
    l_name = $("#l_name").val();
    email =$("#email").val();
    NRIC_no =$("#NRIC_no").val();
    mobile_no = $("#mobile_no").val();
    passport_no =$("#passport_no").val();
    card_no = $("#membership_no").val();   
    membership_no = $("#card_no").val();   
    bonus_card_no =$("#bonus_card_no").val();
    address = $("#address").val();
    city = $("#city").val();
    company_name  = $("#company_name").val();
    card_citymin_val = $("#card_min_val").val();
    card_max_val = $("#card_max_val").val();
    date_form = $("#date_form").val();
    date_to = $("#date_to").val();
    location =$("#location").val();
    tier = $("#tier_dd").val();
    type =$("#type_dd").val();
    
       
    
    if(chk_card_range())
     ajax_datatable.fnDraw();
   
   })
    
    <?php 
    if($this->uri->segment(3))
    {
        echo "ajax_datatable.fnFilter('".$this->uri->segment(3)."');";
    }
    ?>
    
    //find_ajax_datatable_filter
    $('#ajax_datatable_filter input')
    .unbind('keypress keyup')
    .bind('keyup', function(e){
      if ($(this).val().length >= 3 && e.keyCode == 13)
      ajax_datatable.fnFilter($(this).val());
      else return true;
    });
    
    
    
    }); //ready
    
 $(function() {
$( "#date_form" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
onClose: function( selectedDate ) {
$( "#date_to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#date_to" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
onClose: function( selectedDate ) {
$( "#date_form" ).datepicker( "option", "maxDate", selectedDate );
}
});
});
    
//for export csv 
$(document).ready(function(e){
$( "#export_date_form" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
maxDate: "0",
onClose: function( selectedDate ) {
$( "#export_date_to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#export_date_to" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
maxDate: "0",
onClose: function( selectedDate ) {
$( "#export_date_form" ).datepicker( "option", "maxDate", selectedDate );
}
});
$( "#export_date_form" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
maxDate: "0",
onClose: function( selectedDate ) {
$( "#export_date_to" ).datepicker( "option", "minDate", selectedDate );
}
});
 
 });
    
     
//for export csv 
$(document).ready(function(e){
$( "#history_export_date_form" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
maxDate: "0",
onClose: function( selectedDate ) {
$( "#history_export_date_to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#history_export_date_to" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
maxDate: "0",
onClose: function( selectedDate ) {
$( "#history_export_date_form" ).datepicker( "option", "maxDate", selectedDate );
}
});



$( "#history_export_date_form" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
maxDate: "0",
onClose: function( selectedDate ) {
$( "#history_export_date_to" ).datepicker( "option", "minDate", selectedDate );
}
});
 
 });   
    
    
    
    
function chk_card_range()
{
    var min_val =$('#card_min_val').val();
    var max_val =$('#card_max_val').val();
    
    if((min_val > max_val) )
    {
        $("#card_max_val").css('border', '1px solid red');
            $("#card_max_val").focus();
            return false;
    }
    else
    {
        $("#card_max_val").css('border', '1px solid #cccccc');
             return true;
    }
}

//function for view customer details
$(document).on('click','.view_customer',function(e){
    e.preventDefault();
    id = $(this).attr('data-customer_id');
   customer_id= $('#supplementary').attr('data-customer_id',id);
    
    $.ajax({
       url:'<?php echo site_url('membership/view_customer/') ?>/'+id,
       dataType: 'html',
       success:function(result)
       {
        $('#response_view').html(result);
        
        var dtoptions = {"sPaginationType": "full_numbers","iDisplayLength":5,"bFilter":false,"bLengthChange": false}
        
        if($('#print_history_table').length>0)
        $('#print_history_table').dataTable(dtoptions);
        
        if($('#edit_history_table').length>0)
        $('#edit_history_table').dataTable(dtoptions);
        
       } 
    });
    $('#view_modal').modal('show');
    $('#view_modal').on('hidden.bs.modal', function () {
  // do something�
  $('.modal-backdrop').remove();
})
})
//function for view customer supplementary details
$(document).on('click','#supplementary',function(e){
    e.preventDefault();
     id= $(this).attr('data-customer_id');
   
    $.ajax({
       url:'<?php echo site_url('membership/view_customer_supplementry/') ?>/'+id,
       dataType: 'html',
       success:function(result)
       {
        
        $('#response_view_supplenmentry').html(result);
          $('#view_modal').animate({scrollTop: $('#view_modal_supplenmentry').offset().top-600}, 600);
                       
       } 
    });
    $('#view_modal_supplenmentry').modal('show');
    
})


//function for edit customer details
$(document).on('click','.edit_customer',function(e){
    e.preventDefault();
    id = $(this).attr('data-customer_id');
    
    if($(this).data('is_admin')=="1")
    {
        top.location.href='<?php echo site_url('membership/edit_customer/') ?>/'+id;
        return false;
    }
    
    if($(this).data('is_manager')=="1")
    {
        top.location.href='<?php echo site_url('membership/edit_customer/') ?>/'+id;
        return false;
    }
    
     
     $.ajax({
       url:'<?php echo site_url('membership/edit_customer/') ?>/'+id,
       dataType: 'html',
       success:function(result)
       {
        $('#edit_form_response').empty().html(result);
       } 
    });
    $('#editModal').modal('show');
    
    
})
//function for archive customer details
$(document).on('click','.archive_customer',function(e){
    e.preventDefault();
   
    var response = confirm('Are you sure want to archive this customer?');
    if(response){
    id = $(this).attr('data-customer_id');
    $.ajax({
       url:'<?php echo site_url('membership/archive_customer/') ?>/'+id,
       dataType: 'json',
       success:function(result)
       {
        if(result.status==1)
        {
            $('#alert_area').empty().html('<div class="alert alert-success  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result.message+'</div>');
            setTimeout(function(){$('#disappear').fadeOut('slow')},3000);
            ajax_datatable.fnDraw();
        }
        else
        {
            $('#alert_area').empty().html('<div class="alert alert-danger  alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result.message+'</div>');
        }
       } 
    });
    }
    return false;
});

//Edit form handler
$(document).on('submit', '#customer_profile_editbystaff_form', function (e) {
    
    e.preventDefault();
    var r1 =   required_validation('address_1');
   
    
     /**
       Email & mobile validation removed as per requested by parkson on 10 FEB (asana)
            if(!email_validation('email_1')) {//only one is required between mobile and email
            var r2 =   mobile_validaton('mobile_num_1');
            var r4 =   mobile_validaton('mobile_num_2');
            }
            else
            {
                $("#mobile_num_1").css('border', '1px solid #cccccc');    
                $("#mobile_num_2").css('border', '1px solid #cccccc'); 
                var r2 = true;
                var r4 = true;   
            }
            
            
            if(!r2 && !r4) //only one is required between mobile and email
            var r3 =   email_validation('email_1');
            else{
                $("#email_1").css('border', '1px solid #cccccc');    
                var r3 = true;
            }
     **/ 
     
        var r2 = true;
        var r3 = true;
        var r4 = true;    
    var r9 = bonuslink_validation();
       
    if(!r1 || !r2 || !r3 || !r4|| !r9)
    return false;
    
    var r5 = check_for_uniqueness();
    if(!r5)
    return false;

    var from_values = $(this).serialize();
        $.ajax({
            url: '<?php echo site_url('membership/edit_customer_bystaff') ?>',
            dataType: 'json',
            type: 'POST',
            data: from_values,
            success: function (result)
            {

                if (result.status == 1) {
                    $('#alert_area_edit_by_staff_frm').empty().html('<div class="alert alert-success  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    setTimeout(function () {
                        $('#disappear').fadeOut('slow')
                    }, 3000);
                }
                else if (result.status == 2) {
                    $('#alert_area_edit_by_staff_frm').empty().html('<div class="alert alert-info  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    setTimeout(function () {
                        $('#disappear').fadeOut('slow')
                    }, 3000);
                }
                else
                {
                    $('#alert_area_edit_by_staff_frm').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    setTimeout(function () {
                        $('#disappear').fadeOut('slow')
                    }, 3000);
                }

            }
        });
    });

   

    var return_val;
    function check_for_uniqueness()
    {
        var customer_id = $('#current_editing_customer').val();
        //new value
        var Bonuslink_num = $.trim($("#Bonuslink_num").val());
        $('#Bonuslink_num').css('border', '1px solid #cccccc');
            var form_data = {bonuslink:Bonuslink_num};
            $.ajax({
                url: '<?php echo site_url('membership/search_unique') ?>/'+customer_id,
                dataType: 'json',
                async: false,
                data:form_data,
                type:'POST',
                success: function (result)
                {
                    if (result.status == 1) {
                        return_val = false;
                        $('#alert_area_bonus_err').empty().html('<div class="alert alert-danger  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + result.message + '</div>');
                    }
                    else
                    {
                        return_val = true;
                    }


                }
            });
            return return_val;
         

    }
    
    
    function bonuslink_validation()
    {
        var Bonuslink_num = $.trim($('#Bonuslink_num').val());
        if ( Bonuslink_num.length > 0) {
              if ( Bonuslink_num.length > 16) {
                    $('#Bonuslink_num').css('border', '1px solid red');
                    $('#Bonuslink_num').focus();
                    return false;
                }
                else {
                    $('#Bonuslink_num').css('border', '1px solid #cccccc');
                    return true;
                }
      }
      else {
        $('#Bonuslink_num').css('border', '1px solid #cccccc');
        return true;
      }             
    }

 

    function email_validation(id)
    {
       
        var el_val = $.trim($("#" + id).val());
        
        if (el_val == "" || el_val == 0){ 
        $("#" + id).css('border', '1px solid red');
        return false;
        }
            var atpos = el_val.indexOf("@");
            var dotpos = el_val.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= el_val.length) {
                $("#" + id).css('border', '1px solid red');
                return false;
            }
            else
            {
                $("#" + id).css('border', '1px solid #cccccc');
                 return true;
            }
        
    }

    function mobile_validaton(id)
    {
        var el_val = $.trim($("#" + id).val());
       
        
            if (el_val == "" || el_val == 0) 
            {
                $("#" + id).css('border', '1px solid red');
                return false;
            }

            else
            {
                $("#" + id).css('border', '1px solid #cccccc');
                return true;
            }
       
    }
    
function required_validation( id )
{
    if(typeof id==='string')
    var id = [id];
    var bad = 0;
     $.each(id,function(i){
       // alert(id[i]);
         var el_val = $.trim($("#" + id[i]).val());
        if (el_val == "" || el_val == 0) {
            $("#" + id[i]).css('border', '1px solid red');
            bad =1;
        }
        else {
            $("#" + id[i]).css('border', '1px solid #cccccc');
             return true;
        }
    });
    
    if(bad==1) return false;
    return true; 
}

//view user stuff
 function fetch_user(user_id)
{
   $.ajax({
       url:'<?php echo site_url('membership/view_edit_history/') ?>/'+user_id,
       dataType: 'html',
       success:function(result)
       {
        $('#response').html(result);
       } 
    });
    $('#viewModal').modal('show'); 
    
}

 //View User
 $(document).on('click','.view_user',function(e){
    e.preventDefault();
    id = $(this).attr('data-user_id');
    fetch_user(id);
 });   

//export csv






//for hide/show of state dropdown vs text box
$(document).on('change','#country',function(){
   
   if(this.value=='Malaysia')
  {
    $('#state').val('');
    $('#state').addClass('hide');
    $('#m_state').removeClass('hide');
  } 
  else
  {
      $('#m_state').val('0');
      $('#m_state').addClass('hide');
      $('#state').removeClass('hide');
  }
   
});




</script>        
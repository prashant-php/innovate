<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$f_name = array(
    'name' => 'f_name',
    'id' => 'f_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'First Name',
);
$l_name = array(
    'name' => 'l_name',
    'id' => 'l_name',
    'class' => 'form-control input-sm',
    'placeholder' => 'Last Name',
);
$email = array(
    'name' => 'email',
    'id' => 'email',
    'class' => 'form-control input-sm',
    'placeholder' => 'Email Address',
);
$NRIC_no = array(
    'name' => 'NRIC_no ',
    'id' => 'NRIC_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'NRIC Number',
);
$mobile_no = array(
    'name' => 'mobile_no',
    'id' => 'mobile_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Moblie Number',
);
$passport_no = array(
    'name' => 'passport_no',
    'id' => 'passport_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Passport Number',
);
$card_no = array(
    'name' => 'card_no',
    'id' => 'card_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Membership Number',
);

$membership_no = array(
    'name' => 'membership_no',
    'id' => 'membership_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Parkson Card Number',
);

$bonus_card_no = array(
    'name' => 'bonus_card_no',
    'id' => 'bonus_card_no',
    'class' => 'form-control input-sm',
    'placeholder' => 'Bonuslink Card Number',
);
$address = array(
    'name' => 'address',
    'id' => 'address',
    'class' => 'form-control input-sm',
    'placeholder' => 'Address',
);
$city = array(
    'name' => 'city',
    'id' => 'city',
    'class' => 'form-control input-sm',
    'placeholder' => 'City',
);


$card_min_val = array(
    'name' => 'card_min_val',
    'id' => 'card_min_val',
    'class' => 'form-control input-sm pull-left',
    'style' => 'width:50%',
    'placeholder' => 'From',
);

$card_max_val = array(
    'name' => 'card_max_val',
    'id' => 'card_max_val',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'To',
    'style' => 'width:50%',
    'onblur'=>'return chk_card_range()'
);


$date_form = array(
    'name' => 'date_form',
    'id' => 'date_form',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'From Date',
    'style' => 'width:50%',
    'readonly' => 'readonly'
);

$date_to = array(
    'name' => 'date_to',
    'id' => 'date_to',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'To Date',
    'style' => 'width:50%',
    'readonly' => 'readonly'
);

$Export_date_form = array(
    'name' => 'export_date_form',
    'id' => 'export_date_form',
    'class' => 'form-control input-sm pull-left',
    'placeholder' => 'From',
    'style' => 'width:30%;',
    'readonly' => 'readonly'
);

$Export_date_to = array(
    'name' => 'export_date_to',
    'id' => 'export_date_to',
    'class' => 'form-control  pull-left input-sm',
    'placeholder' => 'To',
    'style' => 'width:30%;',
    'readonly' => 'readonly'
);



$store_location[0] = 'Select location of store';
foreach ($location as $location)
{
    $store_location[$location['location_id']] = $location['location_name'];
}

?>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">                
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1 class="pull-left">
<?php echo @$title; ?>
<img src="<?php echo base_url('assets/images/loading.gif'); ?>"  id="progress" />
        </h1>
        <div class="pull-right">
       <a href="<?php echo site_url('membership/customer_list');?>" class="btn btn-default"><i class="fa fa-bolt"></i>  Current list   </a> 
        <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#adv_search">
            <i class="fa fa-filter"></i>  Advanced Search
        </button> 
        
       </div>
        <div class="clearfix"></div>
    </section>
    <div class="clearfix"></div>
   <!-- Main content -->
    <section class="content">
         <div class="row">
            <div class="col-md-12" class="btn">
               
                    <div id="alert_area"></div> 
                    
                    <div class="adv_search_box collapse" id="adv_search">
                    <?php echo form_open(site_url('membership/customer_list'), array('class' => '', 'role' => 'form', 'id' => 'customer_search_form')); ?>
                      <div class="form-group col-md-3">
                            <label class="control-label">First Name </label>
                            <?php echo form_input($f_name); ?> 
                       </div> 
                       
                       <div class="form-group col-md-3">
                             <label class="control-label">Last Name </label>
                             <?php echo form_input($l_name); ?> 
                      </div>  
                       <div class="form-group col-md-3">
                            <label class="control-label">Email</label>
                             <?php echo form_input($email); ?>
                       </div>
                     <div class="form-group col-md-3">
                            <label class="control-label">Mobile No</label>
                             <?php echo form_input($mobile_no); ?>
                    </div>
                    <div class="clearfix"></div>
                    
                    
                    <div class="form-group col-md-3">
                            <label class="control-label">NRIC </label>
                            <?php echo form_input($NRIC_no); ?> 
                       </div> 
                       <div class="form-group col-md-3">
                             <label class="control-label">Passport No </label>
                             <?php echo form_input($passport_no); ?> 
                      </div>  
                       <div class="form-group col-md-3">
                            <label class="control-label">Parkson Card Number</label>
                             <?php echo form_input($membership_no); ?>
                       </div>
                     <div class="form-group col-md-3">
                            <label class="control-label">Bonuslink Card No</label>
                             <?php echo form_input($bonus_card_no); ?>
                    </div>
                    <div class="clearfix"></div>
                    
                    
                      <div class="form-group col-md-3">
                           <label class="control-label">Issuing Store</label>
                            <?php echo form_dropdown('issue_store', $store_location, '0', 'class="form-control input-sm" id="location" '); ?> 
                       </div> 
                       <div class="form-group col-md-3">
                             <label class="control-label">Address</label>
                             <?php echo form_input($address); ?>
                      </div>  
                       <div class="form-group col-md-3">
                            <label class="control-label">City</label>
                             <?php echo form_input($city); ?>
                       </div>
                     
                    <div class="clearfix"></div>
                    <div class="form-group col-md-3">
                            <label class="control-label">Membership Number</label>
                             <?php echo form_input($card_no); ?>
                       </div>
                    <div class="form-group col-md-3">
                             <label class="control-label">Card Number Range</label>
                             <div class="clearfix"></div>
                              <?php echo form_input($card_min_val); ?>
                              <?php echo form_input($card_max_val); ?>
                    </div>
                    
                     <div class="form-group col-md-3">
                             <label class="control-label">Date Range</label>
                             <div class="clearfix"></div>
                             <?php echo form_input($date_form); ?>
                             <?php echo form_input($date_to); ?>
                     </div>
                     <div class="form-group col-md-3">
                     <br />
                    <input type="submit" name='search_customer' id='search_customer' class="btn btn-primary pull-right " value="Search"/>
                     </div>
                    <div class="clearfix"></div>
                    
                    
                  <?php echo form_close(); ?>                   
                  </div>  
                   <div class="clearfix"></div> 
                    <table id="ajax_datatable" class="table table-bordered table-striped dataTable">
                        <thead>
                            <tr class="tableheader tableheader-blue">
                                <th style="width: 140px;" >Date Joined</th>
                                <th >First Name</th>
                                <th >Last Name</th>
                                <th >Parkson Card Number</th>
                                <th >Membership Type</th>
                                <th >Membership Tier</th>
                                <th >Expiration Date</th>
                                <th >Captured by</th>
                                <th style="width: 120px; text-align: center">Actions</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
       

    </section><!-- /.content -->
</aside><!-- /.right-side -->

   <!--View Modal -->
<div class="modal fade" id="view_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="width: 80%;" >
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Membership Details</h4>
      </div>
      <div class="modal-body">
       <div id="response_view"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Back</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>
<script>
    var months = new Array(12);
    months[1] = "January";
    months[2] = "February";
    months[3] = "March";
    months[4] = "April";
    months[5] = "May";
    months[6] = "June";
    months[7] = "July";
    months[8] = "August";
    months[9] = "September";
    months[10] = "October";
    months[11] = "November";
    months[12] = "December";
    
    
    $(document).ready(function () {
        $('#progress').hide();
         var f_name = 0;
        var l_name = 0;
        var email = 0;
        var NRIC_no = 0;
        var mobile_no = 0;
        var passport_no = 0;
        var card_no = 0;
        var membership_no = 0;
        var bonus_card_no = 0;
        var address = 0;
        var city = 0;
        var card_min_val = 0;
        var card_max_val = 0;
        var date_form = 0;
        var date_to = 0;
        var location = 0;
        ajax_datatable = $('table#ajax_datatable').dataTable({
            "bServerSide": true,
            "sAjaxSource": "<?php echo site_url('membership/get_archive_cutomer_list'); ?>",
            "sPaginationType": "full_numbers",
             "fnServerData": function (sSource, aoData, fnCallback)
            {
                $('#loader1').show();
               aoData.push({name: "f_name", value: f_name});
                aoData.push({name: "l_name", value: l_name});
                aoData.push({name: "email", value: email});
                aoData.push({name: "NRIC_no", value: NRIC_no});
                aoData.push({name: "mobile_no", value: mobile_no});
                aoData.push({name: "passport_no", value: passport_no});
                aoData.push({name: "bonus_card_no", value: bonus_card_no});
                aoData.push({name: "card_no", value: card_no});
                aoData.push({name: "membership_no", value: membership_no});
                aoData.push({name: "address", value: address});
                aoData.push({name: "city", value: city});
                aoData.push({name: "card_min_val", value: card_min_val});
                aoData.push({name: "card_max_val", value: card_max_val});
                aoData.push({name: "date_form", value: date_form});
                aoData.push({name: "date_to", value: date_to});
                aoData.push({name: "location", value: location});
                $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": sSource,
                    "data": aoData,
                    "success": fnCallback
                });
            },
            "fnDrawCallback": function () {
                $('#loader1').fadeOut();
            },
            "fnRowCallback": function (nRow, aData, iDisplayIndex) {
                var links = "";

                links += '<a href="#" data-customer_id="' + aData[8] + '" title="View Customer" class="btn btn-primary btn-xs view_customer" style="margin-right:5px;" ><span class="fa fa-search"></span></a>';
               links += '<a href="#" data-customer_id="' + aData[8] + '" title="Archive Customer" class="btn btn-success btn-xs restore_customer"  style="margin-right:5px;"><span class="fa  fa-reply"></span></a>';
                $('td:eq(8)', nRow).html(links);



                var dateSplit = aData[0].split("-");
                day = dateSplit[2].split(' ');
                var curr_date = day[0];
                if(dateSplit[1].replace(/^0+/, '').length=="1")
                dateSplit[1]= dateSplit[1].replace(/^0+/, '');
                var curr_month = months[dateSplit[1]]; //Months are zero based
                var curr_year = dateSplit[0];
              $('td:eq(0)', nRow).html(curr_date + " " + curr_month + " " + curr_year);
              
                var dateSplit = aData[6].split("-");
                day = dateSplit[2].split(' ');
                var curr_date = day[0];
                var curr_month = months[dateSplit[1]]; //Months are zero based
                var curr_year = dateSplit[0];
                $('td:eq(6)', nRow).html(curr_month + " " + curr_year);

                return nRow;
            },
         
             
        });
    
    $(document).on('submit','#customer_search_form',function(e){
    e.preventDefault();
   f_name = $("#f_name").val();
    l_name = $("#l_name").val();
    email =$("#email").val();
    NRIC_no =$("#NRIC_no").val();
    mobile_no = $("#mobile_no").val();
    passport_no =$("#passport_no").val();
    card_no = $("#card_no").val();
    membership_no = $("#membership_no").val();
    bonus_card_no =$("#bonus_card_no").val();
    address = $("#address").val();
    city = $("#city").val();
    card_min_val = $("#card_min_val").val();
    card_max_val = $("#card_max_val").val();
    date_form = $("#date_form").val();
    date_to = $("#date_to").val();
    location =$("#location").val();
    
    
    if(chk_card_range())
     ajax_datatable.fnDraw();
   
   })
    
    
    
    });
    
 $(function() {
$( "#date_form" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
onClose: function( selectedDate ) {
$( "#date_to" ).datepicker( "option", "minDate", selectedDate );
}
});
$( "#date_to" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
changeYear: true,
onClose: function( selectedDate ) {
$( "#date_form" ).datepicker( "option", "maxDate", selectedDate );
}
});
});
    
function chk_card_range()
{
    var min_val =$('#card_min_val').val();
    var max_val =$('#card_max_val').val();
    
    if((min_val > max_val) )
    {
        $("#card_max_val").css('border', '1px solid red');
            $("#card_max_val").focus();
            return false;
    }
    else
    {
        $("#card_max_val").css('border', '1px solid #cccccc');
             return true;
    }
}

//function for view customer details
$(document).on('click','.view_customer',function(e){
    e.preventDefault();
    id = $(this).attr('data-customer_id');
    $.ajax({
       url:'<?php echo site_url('membership/view_customer/') ?>/'+id,
       dataType: 'html',
       success:function(result)
       {
        $('#response_view').html(result);
       } 
    });
    $('#view_modal').modal('show');
})


//function for restore customer details
$(document).on('click','.restore_customer',function(e){
    e.preventDefault();
   
    var response = confirm('Are you sure want to restore this customer?');
    if(response){
    id = $(this).attr('data-customer_id');
    $.ajax({
       url:'<?php echo site_url('membership/restore_customer/') ?>/'+id,
       dataType: 'json',
       success:function(result)
       {
        if(result.status==1)
        {
            $('#alert_area').empty().html('<div class="alert alert-success  alert-dismissable" id="disappear"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result.message+'</div>');
            setTimeout(function(){$('#disappear').fadeOut('slow')},3000);
            ajax_datatable.fnDraw();
        }
        else
        {
            $('#alert_area').empty().html('<div class="alert alert-danger  alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result.message+'</div>');
        }
       } 
    });
    }
    return false;
});


//view user stuff
 function fetch_user(user_id)
{
   $.ajax({
       url:'<?php echo site_url('membership/view_edit_history/') ?>/'+user_id,
       dataType: 'html',
       success:function(result)
       {
        $('#response').html(result);
       } 
    });
    $('#viewModal').modal('show'); 
    
}

 //View User
 $(document).on('click','.view_user',function(e){
    e.preventDefault();
    id = $(this).attr('data-user_id');
    fetch_user(id);
 });   


</script>        
<?php
if($details)
{
    $date_format = $this->config->item('date_format', 'tank_auth');
    $date_format = 'd-m-Y';
   
?>
<a href="<?php echo site_url('membership/print_customer_card/'.$details[0]['customer_id']); ?>" target="_blank" class="btn btn-xs btn-info pull-right"><i class="fa fa-credit-card"></i> Print to Card</a>
<a href="<?php echo site_url('membership/print_customer_details/'.$details[0]['customer_id']); ?>"  target="_blank"  class="btn btn-xs btn-info pull-right" style="margin-right: 5px;margin-bottom: 5px;"><i class="fa fa-print"></i> Print</a>
<a href="<?php echo site_url('membership/print_qr_code/'.$details[0]['customer_id']); ?>"  target="_blank"  class="btn btn-xs btn-info pull-right hide" style="margin-right: 5px;margin-bottom: 5px;"><i class="fa fa-print"></i> Print OR Code</a>

<div class="clearfix"></div>
<div class="col-md-6" id="details">
<table class="table table-bordered table-striped table-condensed" >
        <tr>
        <th colspan="4" class="text-center">Personal Details</th>
        </tr>
        <tr>
            <td><strong>Name:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["title"])." ". htmlspecialchars($details[0]["first_name"]); ?></td>
            
        </tr>
        <tr>
             <td><strong>Last Name:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["last_name"]); ?></td></tr>
         <tr>
             <td><strong>Prefered Name On Card:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["name_on_card"]); ?></td></tr>
        <tr>
            <td><strong>Gender:</strong></td>
            <td><?php echo htmlspecialchars(ucfirst($details[0]["gender"])); ?></td>
            
        </tr>
        <tr>
            <td><strong>DOB:</strong></td>
            <td><?php echo date($date_format,strtotime($details[0]["dob"])); ?></td>
        
        </tr>
        <tr>
            <td><strong>Nationality:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["nationality"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Race:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["race"]);?></td>
        
        </tr>
         <tr>
            <td><strong>NRIC Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["NRIC_no"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Passport Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["passport_no"]); ?></td>
        
        </tr>
        <tr>
            <td><strong>Moblie Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["mobile"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Email:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["email"]); ?></td>
        
        </tr>
         <tr>
            <td><strong>Address 1:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["address_1"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Address 2:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["address_2"]); ?></td>
        
        </tr>
         <tr>
            <td><strong>Address 3:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["address_3"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Post Code:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["postcode"]); ?></td>
        
        </tr>
         <tr>
            <td><strong>Country:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["country"]); ?></td>
            
        </tr>
        <tr>
        
        <td><strong>State:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["state"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>City:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["city"]); ?></td>
            
        </tr>
    </table>
    </div>
    <div class="col-md-6">
    <table class="table table-bordered table-striped table-condensed">
        
         <tr>
        
        <th colspan="4" class="text-center">Card Details</th>
        </tr>
        <tr class="hide">
            <td><strong>Registration Form Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["registration_no"]); ?></td>
            
        </tr>
        <tr>
            <td><strong>Parkson Card Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["membership_no"]); ?></td>
            
        </tr>
        <tr>
            <td><strong>Membership Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["card_no"]); ?></td>
            
        </tr>
        <tr>
        <td><strong>Member Since:</strong></td>
            <td><?php echo date('m-Y',strtotime($details[0]["member_since"])); ?></td>
        </tr>
        <tr>
            <td><strong>Membership Tier:</strong></td>
            <td><?php echo htmlspecialchars(ucfirst($details[0]["membership_tier"])); ?></td>
            
        </tr>
        <tr>
        <td>
            <strong>Card Status:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["card_status"]); ?></td>
        </tr>
        <tr>
            <td><strong>Valid Thru:</strong></td>
            <td><?php echo date('m-Y',strtotime($details[0]["valid_thru"])); ?></td>
            
        </tr>
        <tr>
            <td><strong>Member Type :</strong></td>
            <td><?php echo htmlspecialchars(ucfirst($details[0]["membership_type"])); ?></td>
         </tr>
        <tr>
            <td><strong>Bonuslink Number:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["bonus_link_no"]); ?></td>
         </tr>
         <?php
         if($details[0]["membership_type"]=='supplementary'){
         ?>
         <tr>
            <td><strong>Parent Holder Name:</strong></td>
            <td><?php echo htmlspecialchars($details[1]["p_holder_fname"]." ".$details[1]["p_holder_lname"]); ?></td>
         </tr>
         <tr>
            <td><strong>Parent Parkson Card Number:</strong></td>
            <td><?php echo htmlspecialchars($details[1]["p_card_no"]); ?></td>
         </tr>
         <?php } ?>
        <tr>
            <td><strong>Subscribe To Mobile Alert:</strong></td>
            <td><?php if($details[0]["mobile_alert"]==1) echo "Yes"; else echo "NO"; ?></td>
            
        </tr>
        <tr>
            <td><strong>Subscribe To Newsletter:</strong></td>
           <td><?php if($details[0]["newsletter"]==1) echo "Yes"; else echo "NO"; ?></td>
        
        </tr>
        
    </table>
    <table class="table table-bordered table-striped table-condensed">
         <tr>
            <th colspan="4" class="text-center">Other Details</th>
        </tr>
         <tr>
            <td><strong>Store:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["location_name"]."-".$details[0]["store_code"]); ?></td>
         </tr>
         <tr>
            <td><strong>Captured By:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["staff_fname"]." ".$details[0]["staff_lname"]." (".$details[0]["username"].")"); ?></td>
         </tr>
          <tr>
            <td><strong>Captured On:</strong></td>
            <td><?php echo date($date_format.' H:i:s',strtotime($details[0]["created"])); ?></td>
         </tr>
         <tr>
            <td><strong>Last Modified On:</strong></td>            
            <td><?php if($details[0]["last_modified"]!="" && $details[0]["last_modified"]!='0000-00-00 00:00:00') echo date($date_format.' H:i:s',strtotime($details[0]["last_modified"])); else echo "-"; ?></td>
         </tr>
         <tr>
            <td><strong>Remarks:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["remarks"]); ?></td>
         </tr>
         <tr>
            <td><strong>Company Name:</strong></td>
            <td><?php echo htmlspecialchars($details[0]["company_name"]); ?></td>
         </tr>
    </table>
    </div>
   
    <div class="clearfix"></div>
 <?php
 if($this->tank_auth->is_admin()){
 ?>
    
    <div class="col-md-12">
    <h4 class="modal-title">Edit History</h4>
     <?php if(count($history)>0) {
     ?>
     <table id="edit_history_table" class="table table-bordered table-condensed table-striped">
     <thead>
     <tr>
     <th>Edited On</th>
     <th>Edited By</th>
     <th>Action</th>
     </tr>
     </thead>
     <?php   
     foreach($history as $val)
     { ?>
     
        <tr>
            <td><?php echo date($date_format.' H:i:s',strtotime($val["edited_on"])); ?></td>
            <td><?php echo htmlspecialchars($val["fname"]." ".$val["lname"]." (".$val["username"].")"); ?></td>
            <td><a href="#" data-user_id="<?php echo $val["edit_history_id"] ?>" title="View Details" class="btn btn-primary btn-xs view_user" ><i class="fa fa-search"></i></a></td>
        </tr>
        <?php } }
        else echo 'No data available.'
        ?>
     </table>
     <div class="clearfix"></div>
     </div>
     <!--print_to card history-->
    <div class="col-md-12">
    <h4 class="modal-title">Print To Card History</h4>
    
     
     <?php if(count($print_history)>0) {
     ?>
      <table  id="print_history_table" class="table table-bordered table-condensed table-striped">
     <thead>
     <tr>
     <th>Printed On</th>
     <th>Printed By</th>
     </tr>
     </thead>
     <?php   
     foreach($print_history as $val)
     { ?>
     
        <tr>
            <td><?php echo date($date_format.' H:i:s',strtotime($val["created"])); ?></td>
            <td><?php echo htmlspecialchars($val["fname"]." ".$val["lname"]." (".$val["username"].")"); ?></td>
        </tr>
        <?php } }
        else echo 'No data available.'
        ?>
     </table>
     <div class="clearfix"></div>
     </div>
    
    
    
 <?php } ?>    
    <div class="clearfix"></div>
<?php
}
?>
<!--View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top: 30%;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">History</h4>
      </div>
      <div class="modal-body" style="overflow:auto;">
       <div id="response"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" onclick="$('#viewModal').modal('hide');$('body').addClass('modal-open');" >Back</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
 <!--View Modal for  customer supplementry details -->
<div class="modal fade" id="view_modal_supplenmentry" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="width: 80%;" >
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Supplementry Details</h4>
      </div>
      <div class="modal-body">
       <div id="response_view_supplenmentry"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default"  onclick="$('#view_modal_supplenmentry').modal('hide');$('body').addClass('modal-open');">Back</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

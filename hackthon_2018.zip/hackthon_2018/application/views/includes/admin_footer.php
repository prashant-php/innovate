 </div><!-- ./wrapper -->


       
        <!-- Bootstrap -->
        <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>" type="text/javascript"></script>  
         <!-- App -->      
        <script src="<?php echo base_url('assets/js/app.js') ?>" type="text/javascript"></script> 
        <script src="<?php echo base_url('assets/js/jquery.placeholder.js'); ?>"  type="text/javascript"></script>
        <script>
 $(document).ready(function(){
       $('input, textarea').placeholder();
       $.ajaxSetup({ cache: false });
    });
    </script>
        </body>
</html>
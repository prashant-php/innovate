

        <!-- jQuery 2.0.2 -->
        <script src="<?php echo base_url('assets/js/jquery-1.10.2.min.js') ?>"></script>
        <!-- Bootstrap -->
        <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>" type="text/javascript"></script>        
 <script src="<?php echo base_url('assets/js/jquery.placeholder.js'); ?>"  type="text/javascript"></script>
        <script>
 $(document).ready(function(){
       $('input, textarea').placeholder();
    });
    </script>
    </body>
</html>
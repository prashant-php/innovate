<div class="form-box" id="login-box">
           <div class="header"> <img src="<?php echo base_url('assets/images/logo.png'); ?>" style="width: 150px;"/></div>
          
							<div class="body bg-gray"style="overflow: auto;">
                            	<div class="form-group">
                                     
									<div class="col-lg-12 text-center">
                                     <?php echo $message; ?>
									</div>
                                    
								
								</div>
								</div>
                                <div class="footer">  
                                        <a href="<?php echo site_url(''); ?>" class="btn btn-default">Home</a>  
                                        
                                    </div>
                

        </div>





















<?php
$login = array(
	'name'	=> 'login',
	'id'	=> 'login',
	'value' => set_value('login'),
	'maxlength'	=> 80,
	'size'	=> 30,
    'class'=>'form-control',
    'placeholder'=>'Username',
    'autofocus' => 'autofocus',
);
if ($login_by_username AND $login_by_email) {
	$login_label = 'Email or login';
} else if ($login_by_username) {
	$login_label = 'Login';
} else {
	$login_label = 'Email';
}
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'size'	=> 30,
    'class'=>'form-control',
    'placeholder'=>'Password'
);
$remember = array(
	'name'	=> 'remember',
	'id'	=> 'remember',
	'value'	=> 1,
	'checked'	=> set_value('remember'),
	'style' => 'margin:0;padding:0',
    
);
$captcha = array(
	'name'	=> 'captcha',
	'id'	=> 'captcha',
	'maxlength'	=> 8,
    'class'=>'form-control'
);

?>



        <div class="form-box" id="login-box">
            <div class="header"> Innovate48</div>
            <?php echo form_open(site_url('auth/login')); ?>
                <div class="body bg-gray">
                
                    <div class="form-group">
                        <?php echo form_input($login); ?>
						<span style="color: red;"><?php echo form_error($login['name']); ?><?php echo isset($errors[$login['name']])?$errors[$login['name']]:''; ?></span>
                    </div>
                    <div class="form-group">
                        <?php echo form_password($password); ?>
                        <span style="color: red;"><?php echo form_error($password['name']); ?><?php echo isset($errors[$password['name']])?$errors[$password['name']]:''; ?></span>
                    </div> 
          
                    
                             
                    <div class="form-group">
                        <?php echo form_checkbox($remember); ?>
                        <?php echo form_label('Remember me', $remember['id']); ?>
                    </div>
                </div>
                <div class="footer">    
                <button type="submit" class="btn bg-olive btn-block">Login	</button>                                                           
                 <p class="hide">	<?php echo anchor('/auth/forgot_password/', 'Forgot password?'); ?></p>
                    
                    
                </div>
            	<?php echo form_close(); ?>

        </div>




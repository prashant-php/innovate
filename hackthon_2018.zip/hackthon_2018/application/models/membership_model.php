<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class membership_model extends CI_Model {

    public function __construct() {
        $this->load->database(); //LOADS THE DATABASE AND CREATES DATABASE OBJECT
    }
    
    /** get total records of the customers table
      * @param void
      */
    public function get_total_records(){
        $this->db->select('customer_id');
        $this->db->where('customers.is_archive',0);
        $query = $this->db->get('customers');
		if ($query->num_rows()>0) 
        return $query->num_rows();
		return 0;
    }  
    
    /** return filtered records
      *
      */
    public function get_filtered_records($condition,$search,$orderby,$direction,$start,$limit){   
        
         $data = array();
         $filtered_rows=0;
         $this->db->select('customers.customer_id',FALSE);
        
         $this->db->join ('users','users.id = customers.staff_id',"left");
         if(!empty($search))
         {
           $condition .= 'AND ( ';
           $condition .= " customers.first_name = '$search' ";
           $condition .= " OR customers.last_name = '$search' ";
           $condition .= " OR customers.membership_no = '$search' ";
           $condition .= " OR users.first_name = '$search' ";
           $condition .= ' )'; 
         }
         $this->db->where($condition,null,FALSE);
         $this->db->order_by($orderby, $direction);
         $query = $this->db->get('customers');
         
         
         if ($query->num_rows()> 0) 
         { 
          $filtered_rows = $query->num_rows(); 
          
          $this->db->select('DATE(customers.created) as created_date,
                            customers.first_name as fname,
                            customers.last_name as lname,
                            customers.membership_no,
                            customers.membership_type,
                            customers.membership_tier,
                            customers.valid_thru,
                            CONCAT_WS( \' \',users.first_name, users.last_name ) as staff_username,
                            customers.customer_id',FALSE);
         
         $this->db->join ('users','users.id = customers.staff_id',"left");
         if(!empty($search))
         {
           $condition .= 'AND ( ';
           $condition .= " customers.first_name = '$search' ";
           $condition .= " OR customers.last_name = '$search' ";
           $condition .= " OR customers.membership_no = '$search' ";
           $condition .= " OR users.first_name = '$search' ";
           $condition .= ' )'; 
           //$this->db->or_like('customers.first_name',$search);
//           $this->db->or_like('customers.last_name',$search);
//           $this->db->or_like('customers.membership_no',$search);
//           $this->db->or_like('users.first_name',$search);
         }
         $this->db->where($condition,null,FALSE);
         $this->db->order_by($orderby, $direction);
          $this->db->limit($limit,$start);
          $query2 = $this->db->get('customers');
          foreach($query2->result() as $row)
          { 
            $data[] = array($row->created_date,$row->fname,$row->lname,$row->membership_no,$row->membership_type,$row->membership_tier,$row->valid_thru,$row->staff_username,$row->customer_id); 
          }
         }
         
        return array('data' => $data, 'filtered_records' => $filtered_rows);
		
    }  
    
    /*
     * serach bonuslink number exist in db or not for ajax calls
     * param int 
     * retrun boolean
     */
    public function search_unique($customer_id)
    {
        $nric_num = trim($this->input->post('nric'));
        $bonuslink_num = trim($this->input->post('bonuslink'));
        $pasport_num = trim($this->input->post('passport'));
        $membership_num = trim($this->input->post('membership_num'));
        $meg_str = '';
        
        
        if($membership_num){
        $this->db->select('*');
        $this->db->where('membership_no', $membership_num);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str = 'Parkson Card Number already exists.<br />';
        }
        
        
        
        
        
        if($bonuslink_num){
        $this->db->select('*');
        $this->db->where('bonus_link_no', $bonuslink_num);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str .= 'Bonuslink Number already exists.<br />';
        }
        
       
       
       
       
        if($nric_num){
         $this->db->select('*');
        $this->db->where('NRIC_no', $nric_num);
        
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str .= ' NRIC Number already exists.<br /> ';
        }
        
        
        
        
        
        
        if($pasport_num){
        $this->db->select('*');
        $this->db->where('passport_no', $pasport_num);
        
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str .= 'Passport Number already exists.<br />';
        }
        
         if($meg_str == '')
             return 'OK';
         else
             return $meg_str;
        
    }
    
    
    
      public function search_unique_server_side($nric_num=0, $bonuslink_num=0, $pasport_num=0, $membership_num=0, $customer_id=0)
    {
        $meg_str = '';
        
        if($membership_num){
            
        $this->db->select('*');
        $this->db->where('membership_no', $membership_num);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str = 'Parkson Card Number already exists.<br />';
        }
        
        
        
        
        
        if($bonuslink_num){
        $this->db->select('*');
        $this->db->where('bonus_link_no', $bonuslink_num);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str .= 'Bonuslink Number already exists.<br />';
        }
        
       
       
       
       
        if($nric_num){
         $this->db->select('*');
        $this->db->where('NRIC_no', $nric_num);
        
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str .= ' NRIC Number already exists.<br /> ';
        }
        
        
        
        
        
        
        if($pasport_num){
        $this->db->select('*');
        $this->db->where('passport_no', $pasport_num);
        
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() >= 1)
           $meg_str .= 'Passport Number already exists.<br />';
        }
        
         if($meg_str == '')
             return 'OK';
         else
             return $meg_str;
        
    }
    
    
    
     /*
     * add all details of customer
     * param void
     * retrun boolean
     */
    public function add_customer()
    {
        
        $data['title']=$this->input->post('title');
        $data['first_name']=$this->input->post('f_name');
        //$data['membership_no']=$this->input->post('membership_num');
        $data['last_name']=$this->input->post('l_name');
	$data['account_no']=$this->input->post('account_no');
        $data['balance']=$this->input->post('balance');
        //$data['membership_no']=$this->input->post('membership_num');
        $data['userid']=$this->input->post('userId');
        
//        $data['NRIC_no']=$this->input->post('nric_num_1');
//        $data['NRIC_no'] .=$this->input->post('nric_num_2');
//        $data['NRIC_no'] .=$this->input->post('nric_num_3');
//        
        
        $data['gender']=$this->input->post('gender');
        
//        $data['race']=$this->input->post('race');
        
//        if($data['race'] == 'Other')
//            $data['race']=$this->input->post('custome_race');
//        
 //       $data['nationality']=$this->input->post('nationality');
 //       $data['passport_no']=$this->input->post('passport_num');
        $data['address_1']=$this->input->post('address_1');
 //       $data['bonus_link_no']=$this->input->post('Bonuslink_num');
        $data['address_2']=$this->input->post('address_2');
        
//        $data['card_no']=$this->input->post('card_num');
//        if(!$data['card_no'])
//            $data['card_no'] = $data['membership_no'];
//            
//        $data['registration_no']=$this->input->post('registration_num');
        
        $data['address_3']=$this->input->post('address_3');
        //$data['card_status']=$this->input->post('card_status');
        $data['postcode']=$this->input->post('post_code');
        $data['city']=$this->input->post('city');
        $data['country']=$this->input->post('country');
       
       
        //$valid_thru = str_replace(' ','-','31-'.$this->input->post('valid_thru'));
       // $data['valid_thru'] = date('Y-m-d',  strtotime($valid_thru));
        //$data['valid_thru'] = '2017-12-31';
        
        
        if($data['country'] == 'India')
        {
           $data['state'] = $this->input->post('m_state'); 
        }
        else
        {
            $data['state'] = $this->input->post('state'); 
        }

        //$member_since = str_replace(' ','-',$this->input->post('member_since')).'-01';
       // $data['member_since']=date('Y-m-d', time());
        
       // $data['parent_id']=$this->input->post('p_card_holder_id');
        
       // $data['mobile']  =$this->input->post('mobile_num_1');
       // $data['mobile'] .=$this->input->post('mobile_num_2');
        
        
        $data['email']=$this->input->post('email');
        //$data['mobile_alert']=$this->input->post('mobile_alert');
        //$data['newsletter']=$this->input->post('news_letter');

        if($this->input->post('dob') =='')
        { 
            $data['dob']='-';
        }
        else
        {
           $data['dob']=date('Y-m-d',  strtotime($this->input->post('dob')));
        }


        //$data['membership_type']=$this->input->post('member_type');
         
//         if($data['membership_type']=='primary')
//         $data['parent_id']=0;
         
       // $data['membership_tier']=$this->input->post('member_tire');
        $location_id = $this->get_loaction_id($this->tank_auth->get_user_id());
        $data['location_id']=$location_id['0']['location_id'];
        $data['staff_id']=$this->tank_auth->get_user_id();
        $data['created']= date('Y-m-d H:i:s', time());
        $data['password']= md5($this->input->post('password'));
       // $data['name_on_card']=$this->input->post('name_on_card');
        //$data['added_via_agent'] = $_SERVER['HTTP_USER_AGENT'];
        //$data['remarks'] = $this->input->post('remarks');
        //$data['company_name'] = $this->input->post('company_name');
//       echo "<pre>";
//       print_r($)
      if($this->db->insert('customers', $data) ){
	  unset($data);
	  $last_inserted_id = $this->db->insert_id();
	  $security_questions = array(
		'1' => 'Where did you go the first time you flew on a plane?',
		'2' => 'What is the last name of your favorite elementary school teacher?',
		'3' => 'What is your favorite children’s book?',
		'4' => 'In what city did your parents meet?',
		'5' => 'Who has gifted you the first watch?'
	      
	  );
	  for($i = 1;$i<4;$i++){
	      $data['customer_id'] = $last_inserted_id;
	      $data['challenge_question'] = $security_questions[$this->input->post('security-question-'.$i)];
	      $data['answer'] = $this->input->post('answer_'.$i);
	      $this->db->insert('customer_challenge_question', $data);
	  }
	  
	  
	  
	  return TRUE;
	  
      }
          
      return FALSE;
        
    }
    
   

    /*
     * return list of loction with id
     * param void
     * return array
     */
    
    public function get_location_list()
    {
        $this->db->select('location_id,location_name');
        $this->db->where('is_deleted',0);
        $query = $this->db->get('locations');
        return $query->result_array();
    }
    
    
    /*
     * get location id by user id
     * param int
     * return int
     */
    public function get_loaction_id($user_id)
    {
        $this->db->select('location_id');
        $this->db->where('id',$user_id);
        $query = $this->db->get('users');
        return $query->result_array();
    }
    
    /*
     * function get all details of customer by id
     * param ing
     * return array
     */
    
    public function view_customer($cid)
    {   
        $this->db->select('customers.*, locations.location_name, locations.store_code, users.username, users.first_name as staff_fname, users.last_name as staff_lname ');
        $this->db->where('customer_id',$cid);
        $this->db->join('locations','customers.location_id = locations.location_id','LEFT');
        $this->db->join('users','customers.staff_id = users.id','LEFT');
        
        $query = $this->db->get('customers');
        
        $result = $query->result_array();
       
        if($result[0]['parent_id'] !='0')
        {
             $this->db->select('first_name as p_holder_fname ,last_name as p_holder_lname ,membership_no as p_card_no');
             $this->db->where('customer_id',$result[0]['parent_id']);
             $query = $this->db->get('customers');
             $result1 = $query->result_array();  
             $result =  array_merge($result,$result1);
        }
        
        return $result;
        
         
    }
    
    
    public function generate_query_csv_for_customer_history($export_form_date,$export_form_to)
    {
        $conditions = array();
          $first_name = $this->input->post('hidden_f_name');
          $last_name = $this->input->post('hidden_l_name');
          $email = $this->input->post('hidden_email');
          $mobile = $this->input->post('hidden_mobile_no');
          $NRIC_no = $this->input->post('hidden_NRIC_no');
          $passport_no = $this->input->post('hidden_passport_no');
          $bonus_link_no = $this->input->post('hidden_bonus_card_no');
          $location = $this->input->post('hidden_issue_store');
          $address = $this->input->post('hidden_address');
          $city = $this->input->post('hidden_city');
          $card_no = $this->input->post('hidden_card_no');
          $membership_no = $this->input->post('hidden_membership_no');
          $card_min_val = $this->input->post('hidden_card_min_val');
          $card_max_val = $this->input->post('hidden_card_max_val');
          
              
        $condition = "customers.is_archive = 0";
        if($first_name) $condition.=" AND customers.first_name LIKE '%$first_name%' ";
        if($last_name) $condition.=" AND customers.last_name LIKE '%$last_name%' ";
        if($email) $condition.=" AND customers.email LIKE '%$email%' ";
        if($NRIC_no) $condition.=" AND customers.NRIC_no LIKE '%$NRIC_no%' ";
        if($mobile) $condition.=" AND customers.mobile LIKE '%$mobile%' ";
        if($passport_no) $condition.=" AND customers.passport_no LIKE '%$passport_no%' ";
        if($card_no) $condition.=" AND customers.membership_no LIKE '%$card_no%' "; //card number is membership number
        if($membership_no) $condition.=" AND customers.membership_no LIKE '%$membership_no%' "; //card number is membership number
        if($bonus_link_no) $condition.=" AND customers.bonus_link_no LIKE '%$bonus_link_no%' ";
        if($address) $condition.=" AND customers.address_1 LIKE '%$address%' ";
        if($city) $condition.=" AND customers.city LIKE '%$city%' ";
        if($location) $condition.=" AND customers.location_id = $location ";
        if($card_min_val && $card_max_val )  $condition.=" AND customers.card_no >= $card_min_val AND customers.card_no <= $card_max_val ";
        $parent_id = 'parent_id';
       
        $this->db->select('customers.card_no,edit_history_column.column_name,edit_history_column.old_value,edit_history_column.new_value,users.username,edit_history.edited_on');
        $this->db->from('customers');
        $this->db->join ('edit_history','customers.customer_id = edit_history.customer_id',"left");
        $this->db->join ('users','users.id = edit_history.edited_by',"left");
        $this->db->join ('edit_history_column','edit_history.edit_history_id = edit_history_column.edit_history_id',"left");
        $this->db->where('date(edit_history.edited_on)  >= ',$export_form_date );
        $this->db->where('date(edit_history.edited_on)  <= ',$export_form_to );
        $this->db->where($condition);
        $this->db->where('edit_history_column.column_name !=','parent_id');
        $quer = $this->db->get();
        //echo $this->db->last_query();
        return $quer;
    }
    
    public function archive_customer($cid)
    {   
        $data["is_archive"] = 1;
         $data["archive_by"] = $this->tank_auth->get_user_id();
           $this->db->where('customer_id',$cid);
            $result = $this->db->update('customers',$data); 
        
             if($result)
                {
                   return true; 
                } 
                else
                {
                    return false; 
        
                } 
    }
    
    /**
     * Restore customer-prashant 
     * @param customer_id
     *  @return bool
     */
    
     public function restore_customer($cid)
    {   
        $data["is_archive"] = 0;
        $data["restore_by"] = $this->tank_auth->get_user_id();
        $this->db->where('customer_id',$cid);
        $result = $this->db->update('customers',$data); 
        if($result)
        return true; 
        else
        return false; 
    }
    
    
    public function edit_history($cid)
    {
        $this->db->select('edit_history.*');
        $this->db->select('users.username, users.first_name as fname, users.last_name as lname');
        $this->db->from('edit_history');
        $this->db->join('users',' users.id = edit_history.edited_by','LEFT');
        $this->db->where('customer_id',$cid);
        $this->db->order_by('edit_history.edited_on','DESC');
        $query = $this->db->get();
       if ($query->num_rows() >0) 
        return $query->result_array();
	           return NULL;
    	
    }
    
    public function print_history($cid)
    {
        $this->db->select('print_out_history.*');
        $this->db->select('users.username, users.first_name as fname, users.last_name as lname');
        $this->db->from('print_out_history');
        $this->db->join('users',' users.id = print_out_history.staff_id','LEFT');
        $this->db->where('customer_id',$cid);
        $this->db->order_by('print_out_history.created','DESC');
        $query = $this->db->get();
        
        if ($query->num_rows() >0) 
        return $query->result_array();
	           return NULL;
    	
    }
    
    
    public function view_edit_history($history_id)
    {
        $this->db->select('edit_history.*');
        $this->db->select('edit_history_column.*');
       
        $this->db->from('edit_history_column');
        $this->db->join('edit_history','edit_history_column.edit_history_id=edit_history.edit_history_id','LEFT');
        $this->db->where('edit_history_column.edit_history_id',$history_id);
        $query = $this->db->get();
        
        if ($query->num_rows() >0) 
        return $query->result_array();
	           return NULL;
    }
    
    
    
    public function add_print_out($customer_id)
    {
        $data['customer_id'] = $customer_id;
        $data['staff_id']=$this->tank_auth->get_user_id();
        $data['created']= date('Y-m-d H:i:s', time());
        if($this->db->insert('print_out_history', $data) )
          return TRUE;
       return FALSE;
    }
    
    public function is_supp_limit_reached($customer_id)
    {
        $this->db->select('customer_id');
        $this->db->where('parent_id',$customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows()>9)
        return true;
        return false; 
    }
    
    
    
    
    function is_pcn_duplicate($membership_num,$customer_id)
    {
        if($membership_num){
        $this->db->select('*');
        $this->db->where('membership_no', $membership_num);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() > 0)
        return true;
        return false; 
        }
        
    }
    
    
    
     function is_bl_duplicate($bonuslink_num,$customer_id)
    {
        if($bonuslink_num){
        $this->db->select('*');
        $this->db->where('bonus_link_no', $bonuslink_num);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() > 0)
        return true;
        return false;  
         
        }
    }
    
    function is_passport_duplicate($passport,$customer_id)
    {
        if($passport){
        $this->db->select('*');
        $this->db->where('passport_no', $passport);
       
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() > 0)
        return true;
        return false;  
         
        }
    }
    
    
    
    
     function is_nric_duplicate($nric_num,$customer_id)
    {
        if($nric_num){
            
        $this->db->select('*');
        $this->db->where('NRIC_no', $nric_num);
        
        if($customer_id)
        $this->db->where('customer_id !=', $customer_id);
        
        $query = $this->db->get('customers');
        if ($query->num_rows() > 0)
        return true;
        return false;  
         
        }
    }
    
    
 /*
     * function get all details of customer supplementry by id
     * param ing
     * return array
     */
    
    public function view_customer_supplementry($cid)
    {   
        $this->db->select('customers.*,users.username, users.first_name as staff_fname, users.last_name as staff_lname ');
        $this->db->where('parent_id',$cid);
        $this->db->where('is_archive',0);
         $this->db->join('users','customers.staff_id = users.id','LEFT');
        
        $query = $this->db->get('customers');      
        
       if ($query->num_rows() >0) 
        return $query->result_array();
	           return NULL;
    }  
    
}

<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class dashboard_model extends CI_Model
{
    public function __construct()
	{
	    $this->load->database(); //LOADS THE DATABASE AND CREATES DATABASE OBJECT
	}    
     
     
     /**
      * dashboard_model::get_membership_customer()
      * 
      * @param mixed $store_id
      * @param mixed $start_date
      * @param mixed $end_date
      * @return
      */
     function get_membership_customer($store_id,$start_date,$end_date)
        {
           
            $this->db->select('date(customers.created) as date');
            $this->db->select('count(*) AS hits');
            $this->db->from('customers');
            $this->db->join('locations', 'customers.location_id = locations.location_id','LEFT');
        
            $this->db->where('customers.created >=',$start_date);
            $this->db->where('customers.created <',$end_date);
            if($store_id)
            $this->db->where('locations.location_id',$store_id);
            $this->db->group_by('date(customers.created)');
           
           $query = $this->db->get();
          return $query->result_array();
        }
       
       
        
        /**
         * get location id using staff id
         * 
         * */
        public function get_location_id($staff_id)
        {
          $this->db->select("location_id");
          $this->db->from('users');
          $this->db->where('id',$staff_id); 
          $query=$this->db->get(); 
          if($query->num_rows()>0){
             $row = $query->row();
    		return $row->location_id;
            }
    		return false;
        }

        /**
         * dashboard_model::get_csv()
         * 
         * @param mixed $csv_id
         * @return
         */
        public function get_csv($csv_id)
        {
          $this->db->where('export_id',$csv_id);
          $query = $this->db->get('auto_export');
           return $query->result_array();       
        }
        /**
         * dashboard_model::get_history_csv()
         * 
         * @param mixed $csv_id
         * @return
         */
        public function get_history_csv($csv_id)
        {
          $this->db->where('history_export_id',$csv_id);
          $query = $this->db->get('auto_export_history');
           return $query->result_array();       
        }
        /**
         * function for generate query for auto_csv
         * @return str
         */
        public function generate_query_auto_csv()
        {
          //$this->db->select( 'customers.registration_no,customers.membership_no, customers.title,customers.first_name, customers.last_name, customers.dob, customers.gender, customers.nationality, customers.address_1, customers.address_2, customers.address_3, customers.postcode, customers.city, customers.state, customers.country, customers.mobile, customers.email,  customers.NRIC_no, customers.race, customers.passport_no, customers.bonus_link_no, customers.card_no, customers.member_since, customers.membership_tier, customers.card_status,customers.valid_thru, customers.membership_type,customers.newsletter, customers.mobile_alert,customers.created,locations.location_name  as store_name, users.username as staff_username,
//p.first_name as parent_fname, p.last_name as parent_last_name , p.card_no as parent_card_no');   
 $this->db->select( 'customers.membership_no,
                                  customers.title,
                                  customers.first_name,
                                  customers.last_name,
                                  customers.dob,
                                  customers.gender,
                                  customers.nationality,
                                  customers.address_1,
                                  customers.address_2,
                                  customers.address_3,
                                  customers.postcode,
                                  customers.city,
                                  customers.state,
                                  customers.country,
                                  customers.mobile,
                                  customers.email,
                                  customers.NRIC_no,
                                  customers.race,
                                  customers.passport_no,
                                  customers.bonus_link_no,
                                  customers.card_no,
                                  customers.member_since,
                                  customers.membership_tier,
                                  customers.card_status,
                                  customers.valid_thru,
                                  customers.membership_type,
                                  customers.newsletter,
                                  customers.mobile_alert,
                                  DATE(customers.created) as created_date,
                                  TIME(customers.created) as created_time,
                                  locations.store_code  as store_name,
                                  CONCAT_WS( \'\', users.username, CONCAT_WS( \' \',users.first_name, users.last_name ) ) as staff_username,
                                  p.first_name as parent_fname,
                                  p.last_name as parent_last_name,
                                  p.membership_no as parent_card_no,
                                  customers.name_on_card
                                  ');  
          $this->db->where( "customers.is_archive = 0");
          $this->db->where(' ( DATE(customers.created) = CURDATE() OR  DATE(customers.last_modified) = CURDATE() ) ',NULL,FALSE);
           $this->db->join ('users','users.id = customers.staff_id',"left");
            $this->db->join ('locations','locations.location_id = users.location_id',"left");
            $this->db->join ('customers as p','customers.parent_id = p.customer_id',"left");
            $quer = $this->db->get('customers');
            
            return $quer;  
        }
        
        
        /**
         * dashboard_model::generate_query_auto_csv_custom()
         * 
         * @return
         */
        public function generate_query_auto_csv_custom()
        {
          //$this->db->select( 'customers.registration_no,customers.membership_no, customers.title,customers.first_name, customers.last_name, customers.dob, customers.gender, customers.nationality, customers.address_1, customers.address_2, customers.address_3, customers.postcode, customers.city, customers.state, customers.country, customers.mobile, customers.email,  customers.NRIC_no, customers.race, customers.passport_no, customers.bonus_link_no, customers.card_no, customers.member_since, customers.membership_tier, customers.card_status,customers.valid_thru, customers.membership_type,customers.newsletter, customers.mobile_alert,customers.created,locations.location_name  as store_name, users.username as staff_username,
//p.first_name as parent_fname, p.last_name as parent_last_name , p.card_no as parent_card_no');   
 $this->db->select( 'customers.membership_no,
                                  customers.title,
                                  customers.first_name,
                                  customers.last_name,
                                  customers.dob,
                                  customers.gender,
                                  customers.nationality,
                                  customers.address_1,
                                  customers.address_2,
                                  customers.address_3,
                                  customers.postcode,
                                  customers.city,
                                  customers.state,
                                  customers.country,
                                  customers.mobile,
                                  customers.email,
                                  customers.NRIC_no,
                                  customers.race,
                                  customers.passport_no,
                                  customers.bonus_link_no,
                                  customers.card_no,
                                  customers.member_since,
                                  customers.membership_tier,
                                  customers.card_status,
                                  customers.valid_thru,
                                  customers.membership_type,
                                  customers.newsletter,
                                  customers.mobile_alert,
                                  DATE(customers.created) as created_date,
                                  TIME(customers.created) as created_time,
                                  locations.store_code  as store_name,
                                  CONCAT_WS( \'\', users.username, CONCAT_WS( \' \',users.first_name, users.last_name ) ) as staff_username,
                                  p.first_name as parent_fname,
                                  p.last_name as parent_last_name,
                                  p.membership_no as parent_card_no,
                                  customers.name_on_card
                                  ');  
          $this->db->where( "customers.is_archive <> 1 AND  customers.last_modified =  '2015-10-06 15:49:55' ");
          $this->db->join ('users','users.id = customers.staff_id',"left");
            $this->db->join ('locations','locations.location_id = users.location_id',"left");
            $this->db->join ('customers as p','customers.parent_id = p.customer_id',"left");
            $quer = $this->db->get('customers');
            
            return $quer;  
        }
        
        /**
         * dashboard_model::save_auto_generate_csv()
         * 
         * @param mixed $file_name
         * @return void
         */
        public function save_auto_generate_csv($file_name)
        {
            $data['file_name'] = $file_name;
            $data['created'] =  date('Y-m-d H:i:s', time());
            $this->db->insert('auto_export',$data);
        }
         /**
          * dashboard_model::save_auto_generate_customer_history_csv()
          * 
          * @param mixed $file_name
          * @return void
          */
         public function save_auto_generate_customer_history_csv($file_name)
        {
            $data['file_name'] = $file_name;
            $data['created'] =  date('Y-m-d H:i:s', time());
            $this->db->insert('auto_export_history',$data);
        }
        
        /**
         * dashboard_model::get_total_memberships()
         * 
         * @param mixed $location_id
         * @return
         */
        public function get_total_memberships($location_id)
        {
            
            if($location_id)
            $this->db->where('location_id',$location_id);
            $quer = $this->db->get('customers');
            return $quer->num_rows();
        }
        /**
         * dashboard_model::generate_query_auto_customer_history_csv()
         * 
         * @return
         */
        public function generate_query_auto_customer_history_csv(){
        $this->db->select('customers.card_no,edit_history_column.column_name,edit_history_column.old_value,edit_history_column.new_value,users.username,edit_history.edited_on');
        $this->db->from('customers');
        $this->db->join ('edit_history','customers.customer_id = edit_history.customer_id',"left");
        $this->db->join ('users','users.id = edit_history.edited_by',"left");
        $this->db->join ('edit_history_column','edit_history.edit_history_id = edit_history_column.edit_history_id',"left");
        $this->db->where('(DATE(edit_history.edited_on) = CURDATE()) ',NULL,FALSE);
        $this->db->where('edit_history_column.column_name !=','parent_id');
        $quer = $this->db->get();
        //echo $this->db->last_query();
        return $quer;
        }
        
}
    



?>
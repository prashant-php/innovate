<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_controller
{
    function __construct()
	{
		parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->library('security');
		$this->load->library('tank_auth');
        $this->load->model('dashboard_model');
        $this->load->library('Datatables');
	}
        
        public function index()
        {
            if (!$this->tank_auth->is_logged_in()) {
			         redirect('auth/login');
		      } else {
		          
      
            $data['user_id']	= $this->tank_auth->get_user_id();
      		$data["admin_data"] = $this->session->all_userdata();   
            $data["title"]  = "Dashboard";
            
            if($this->tank_auth->is_admin()) {   
    		    //$this->load->model('locations_model');
                //$data["locations"] = $this->locations_model->get_locations();  
                $dashboard_message = "Welcome TO Bank";
            	$this->load->view('includes/admin_header', $data);
                $this->load->view('dashboard', $data);
                $this->load->view('includes/admin_footer', $data);
            }
            elseif($this->tank_auth->is_staff()){
                $this->load->model('staff_model');
                $data["staff_details"] = $this->staff_model->view_staff($data['user_id']);
                $this->load->view('includes/admin_header', $data);
                $this->load->view('staff_dashboard', $data);
                $this->load->view('includes/admin_footer', $data);
            }
         }
        }
        
        
        public function get_graph_data($start_date=0,$end_date=0,$store_id=0)
        {
              if (!$this->tank_auth->is_logged_in()) {
			         redirect('auth/login');
		      } else {
		      
              
              if($this->tank_auth->is_staff()){
                $staff_id	= $this->tank_auth->get_user_id();
                $this->load->model('staff_model');
                $data["staff_details"] = $this->staff_model->view_staff($staff_id);
                $store_id = $data["staff_details"][0]["location_id"];
              }
                
                if(!$start_date || !$end_date )//missing dates
                {
                    $start_date = date('Y-m-d',strtotime('-7 days')) ;
                    $end_date = date('Y-m-d', strtotime("+1 days"));
                    $end_date1 = date('Y-m-d', strtotime("+0 days"));
                }
                else 
                {
                   $start_date =  str_replace('_',' ',$start_date);
                   $end_date =   str_replace('_',' ',$end_date);
                }
                
               $daterange = $this->createDateRangeArray($start_date,$end_date);
               $datesThatHaveHits = $this->dashboard_model->get_membership_customer($store_id,$start_date,$end_date);
               
               $finalArr = array();
               foreach($datesThatHaveHits as $val)
                    $daterange[$val["date"]] = $val["hits"];
               
               $res["total_membership_storewise"] =  $this->dashboard_model->get_total_memberships($store_id);
               $res["data"] = $daterange;
                echo  json_encode($res);
                die(); 
            }
        }
        
     /**
      * function for generate csv_list
      */   
     public function get_csv_list()
    {
       if (!$this->tank_auth->is_logged_in())
            {
	    redirect('administrator');
            }
            else 
            {
                $this->datatables->select('file_name,created,export_id')
                ->from('auto_export'); 
                echo $this->datatables->generate();
            }     
    }
        
    /**
     * for download csv_file by id
     * @param int $csv_id
     */
        
        public function download_csv($csv_id)
        {
           if (!$this->tank_auth->is_logged_in())
            {
	    redirect('administrator');
            }
            else 
            {
                
               $csv_info = $this->dashboard_model->get_csv($csv_id);
                
                $file_name = $csv_info[0]['file_name'];
                $path      = 'auto_scheduler_files/'.$file_name;
                
                if (ini_get('zlib.output_compression')) 
                {
                ini_set('zlib.output_compression', 'Off');
                }
                $this->load->helper('download');
                $file_data = file_get_contents($path);
                force_download($file_name, $file_data);  
            }
                
            
        }
      
        
        /**
         * function for automatically generate csv
         */
        public function auto_generate_csv()
        {
           //load csv helper
            $this->load->helper('csv');

            //function call that generate query for csv file 
            $quer = $this->dashboard_model->generate_query_auto_csv();
            if (! is_object($quer))
            die('No Records Found');
           
            $seq = (int)file_get_contents('auto_counter.txt');
            $seq = str_pad($seq, 2, '0', STR_PAD_LEFT); 
            $file_name = date('ymd')."_$seq".'PM.csv';
            $path = 'temp/'.$file_name;
            $seq++;
            file_put_contents('auto_counter.txt', $seq);
            
            if(!file_exists('auto_scheduler_files/'))
            mkdir('auto_scheduler_files','775');
            $path = 'auto_scheduler_files/' .$file_name;
           
            query_to_csv($quer,TRUE,$path);
            if($this->dashboard_model->save_auto_generate_csv($file_name));
            echo "ALL Done!";
            die();
            
         }
          
         
          /**
         * function for automatically generate csv
         */
        public function auto_generate_csv_custom()
        {
           //load csv helper
            $this->load->helper('csv');

            //function call that generate query for csv file 
            $quer = $this->dashboard_model->generate_query_auto_csv_custom();
            if (! is_object($quer))
            die('No Records Found');
            
            
            $file_name = date('ymd')."xxx".'PM.csv';
            $path = 'temp/'.$file_name;
            
            
            if(!file_exists('auto_scheduler_files/'))
            mkdir('auto_scheduler_files','775');
            $path = 'auto_scheduler_files/' .$file_name;
            
            query_to_csv($quer,TRUE,$path);
            echo "ALL Done!";
            die();
            
         }
         
         
         
         function createDateRangeArray($strDateFrom,$strDateTo)
        {
            // takes two dates formatted as YYYY-MM-DD and creates an
            // inclusive array of the dates between the from and to dates.
        
            // could test validity of dates here but I'm already doing
            // that in the main script
        
            $aryRange=array();
        
            $iDateFrom=mktime(1,0,0,substr($strDateFrom,5,2),     substr($strDateFrom,8,2),substr($strDateFrom,0,4));
            $iDateTo=mktime(1,0,0,substr($strDateTo,5,2),     substr($strDateTo,8,2),substr($strDateTo,0,4));
        
            if ($iDateTo>=$iDateFrom)
            {
               
                $d = date('Y-m-d',$iDateFrom);
                $aryRange[$d] = 0;
                while ($iDateFrom<$iDateTo)
                {
                    $iDateFrom+=86400; // add 24 hours
                    $d = date('Y-m-d',$iDateFrom);
                    $aryRange[$d] = 0;
                }
            }
            return $aryRange;
        }
        
        public function reset_counters()
        {
            $seq=1;
            file_put_contents('auto_counter.txt', $seq);
            file_put_contents('counter.txt', $seq);
            file_put_contents('auto_counter_btr.txt', $seq);
            file_put_contents('counter_btr.txt', $seq);
            file_put_contents('counter_report.txt', $seq);
            
        }
        
//Datatable To download customer history CSV  
     /**
      * Dashboard::get_history_csv_list()
      * 
      * @return void
      */
     public function get_history_csv_list()
        {
       if (!$this->tank_auth->is_logged_in())
            {
	    redirect('administrator');
            }
            else 
            {
                $this->datatables->select('file_name,created,history_export_id')
                ->from('auto_export_history'); 
                echo $this->datatables->generate();
            }     
        }
        
  
        
        /**
         * Dashboard::download_history_csv()
         * 
         * @param mixed $csv_id
         * @return void
         */
        public function download_history_csv($csv_id)
        {
           if (!$this->tank_auth->is_logged_in())
            {
	    redirect('administrator');
            }
            else 
            {
                
               $csv_info = $this->dashboard_model->get_history_csv($csv_id);
                $file_name = $csv_info[0]['file_name'];
                $path      = 'auto_scheduler_history_files/'.$file_name;
                
                if (ini_get('zlib.output_compression')) 
                {
                ini_set('zlib.output_compression', 'Off');
                }
                $this->load->helper('download');
                $file_data = file_get_contents($path);
                force_download($file_name, $file_data);  
            }
                
            
        }
    
        /**
         * Dashboard::auto_generate_customer_history_csv()
         * 
         * @return void
         */
        public function auto_generate_customer_history_csv()
        {
           //load csv helper
            $this->load->helper('csv');

            //function call that generate query for csv file 
            $quer = $this->dashboard_model->generate_query_auto_customer_history_csv();
            if (! is_object($quer))
            die('No Records Found');
           
            $seq = (int)file_get_contents('auto_counter_history.txt');
            $seq = str_pad($seq, 2, '0', STR_PAD_LEFT); 
            $file_name = date('ymd')."_$seq".'.csv';
            $path = 'temp/'.$file_name;
            $seq++;
            file_put_contents('auto_counter_history.txt', $seq);
            
            if(!file_exists('auto_scheduler_history_files/'))
            mkdir('auto_scheduler_history_files','775');
            $path = 'auto_scheduler_history_files/' .$file_name;
           
            query_to_csv_customer_history($quer,TRUE,$path);
            if($this->dashboard_model->save_auto_generate_customer_history_csv($file_name));
            echo "ALL Done!";
            die();
            
         }
         

}
        
 

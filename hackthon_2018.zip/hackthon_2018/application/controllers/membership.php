<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class membership extends CI_controller {

    function __construct() {
        parent::__construct();

        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('security');
        $this->load->library('tank_auth');
        $this->load->library('datatables');
        $this->load->language('tank_auth');
        $this->load->model('membership_model');
        //$this->load->library('ciqrcode');   
    }
    
    /*
     * this function will load Membership Signup form
     * param void
     * retrun void
     */
    public function index()
    {
        $data["admin_data"] = $this->verify_for_direct_request();
        $data["title"] = "Customer Signup";
        $this->load->view('includes/admin_header', $data);
        $this->load->view('membership/customer_profile', $data);
        $this->load->view('includes/admin_footer', $data);
    }
    
    /*
     * 
     * for add customer
     * param void
     * return array
     */
    
    public function add_customer()
    {
       $data["admin_data"] = $this->verify_for_ajax_request();
        $this->form_validation->set_rules('f_name', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('l_name', 'Last Name', 'trim|required|xss_clean');      
         
        //$this->form_validation->set_rules('nationality', 'Nationality', 'trim|required|xss_clean');
        $this->form_validation->set_rules('address_1', 'Address', 'trim|required|xss_clean');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required|xss_clean');
       
        //Email & mobile validation removed as per requested by parkson on 10 FEB (asana)
        //if(!filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL)){   
        //$this->form_validation->set_rules('mobile_num_1', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //$this->form_validation->set_rules('mobile_num_2', 'Mobile Number', 'trim|numeric|xss_clean|required');
        //}
          
        //if(!$this->input->post('mobile_num_1') && !$this->input->post('mobile_num_2'))
        //$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required|xss_clean');
        
        $this->form_validation->set_rules('mobile_num_1', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('mobile_num_2', 'Mobile Number', 'trim|numeric|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean');
        
       
        
        

        if ($this->form_validation->run())
		{ 
             //validate duplicates
            //$is_duplicates = $this->check_uniqueness(0);
//            if($is_duplicates !== true)
//            {
//                $result["status"] = 0;
//                $result["message"] = $is_duplicates; 
//                echo json_encode($result);
//                die();  
//            } 
                        
			//code for success
                        if($this->membership_model->add_customer()){
                   
                                 $result["status"] = 1;
                                  $result["message"] = $this->lang->line('add_customer');
                              } else {
                                  $result["status"] = 0;
                                  $result["message"] = $this->lang->line('add_customer_err');
                              }
                              echo json_encode($result);
                              die();  
                       
		}
		else
		{
                   
             $data = validation_errors();
             $result["status"] = 0;
             $result["message"] = $data;
             echo json_encode($result);
             die();
		}
    }
   function generate_password(){
      
    if(isset($_POST['dob'])&& !empty($_POST['dob']))
    $dob = date('Y',strtotime($_POST['dob']));
    $date_of_birth = date('d',strtotime($_POST['dob']));
    $month_of_birth = date('m',strtotime($_POST['dob']));
      
      
    $questions_answer_mapping = array(
        $_POST['security-question-1'] => $_POST['answer_1'],
        $_POST['security-question-2'] => $_POST['answer_2'],
        $_POST['security-question-3'] => $_POST['answer_3'],
    );
    $security_answers = array(1, 2, 3, 4, 5);
	$r = 3;
	$n = count($security_answers);
	$possible_combinations = $this->printCombination($security_answers,$n, $r);
   // echo "<pre>";
//    print_r($_POST);
//    die;
    $security_questions = array($_POST['security-question-1'],$_POST['security-question-2'],$_POST['security-question-3']);
    sort($security_questions);
    $security_questions = implode($security_questions);
    //echo $security_questions;die;
    if(('123' == $security_questions)&& ($_POST['project_on_working'] == "Technology")){
        $password_sentence = $questions_answer_mapping[2] . " Is A ". $_POST['project_on_working']. " Addict Since " . $dob;
            //$password_sentence = $password_sentence ."@".$dob;
             $result["status"] = 1;
             $result["message"] = ucfirst($password_sentence);
	     $result["password"] =  $this->getFisrtLettesOfString($password_sentence,$dob,"@");
             echo json_encode($result);
             die();
    }elseif(('234' == $security_questions)&& ($_POST['project_on_working'] == "Finance")){
          $password_sentence = $questions_answer_mapping[2] . " Claimed To Be An Expert ". $_POST['project_on_working'];
          //$password_sentence = $password_sentence ."!".$date_of_birth;
             $result["status"] = 1;
             $result["message"] = ucfirst($password_sentence);
	     $result["password"] =  $this->getFisrtLettesOfString($password_sentence,$date_of_birth,"!");
             echo json_encode($result);
             die();
    }elseif(('345' == $security_questions)&& ($_POST['project_on_working'] == "Admin")){
        $password_sentence = $questions_answer_mapping[3] . " Was My Favourite Book ";
        //if($month_of_birth > 6)
         //$password_sentence .="When I Was At ". $month_of_birth;  
         if($month_of_birth > 6)      
          //$password_sentence = $password_sentence."@".$month_of_birth;
             $result["status"] = 1;
             $result["message"] = ucfirst($password_sentence);
	     $result["password"] =  $this->getFisrtLettesOfString($password_sentence,$month_of_birth,"@");
             echo json_encode($result);
             die();
    }
    
   }
   function getFisrtLettesOfString($string, $dob = "", $special_character = ""){     
     $explodedString = explode(" ",$string); 
     $finalString ="";
     for($i = 0; $i <str_word_count($string); $i++){ 
	 $tempString = substr($explodedString[$i], 0, 1); 
	 $finalString .= $tempString; 
     } 
     $finalString = strtoupper($finalString); 
     if(!empty($dob))
	   $finalString = $finalString . $special_character . $dob;
	 
     return $finalString;
   }
   function printCombination($arr =[],$n, $r){
       $data = array();
       $this->combinationUtil($arr, $data, 0, $n-1, 0, $r);
   }
   function combinationUtil($arr, $data,$start,$end,$index,$r){
       if($index == $r){       
	   //print_r($data);
	   return;
       }
       for($i=$start;(($i<=$end) && ($end-$i+1 >= $r-$index));$i++){
	   $data[$index] = $arr[$i];
	   $this->combinationUtil($arr,$data,$i+1,$end,$index+1,$r);
       }
   }
        /**
     * Verify if user is logged in and is admin (for direct requests)
     * 
     * */
    private function verify_for_direct_request() {
        if (!$this->tank_auth->is_logged_in()) {
            redirect('/auth/login/');
            die();
        }
        if (!$this->tank_auth->is_admin() && !$this->tank_auth->is_staff() ) {
            redirect('/auth/login/');
            die();
        }
        
        return $this->session->all_userdata();
    }
   
     /**
     * Verify if user is logged in and is admin (for ajax requests)
     * 
     * */
    private function verify_for_ajax_request() {
        if (!$this->tank_auth->is_logged_in()) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }

        if (!$this->tank_auth->is_admin() && !$this->tank_auth->is_staff() ) {
            echo "<div class='alert alert-danger'>Invalid Access Or Session Timed Out</div>";
            die();
        }
    }
    
    
    
    
    
    
    
    
}


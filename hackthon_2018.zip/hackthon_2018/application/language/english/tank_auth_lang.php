<?php

// Errors
$lang['auth_incorrect_password'] = 'Incorrect password';
$lang['auth_incorrect_login'] = 'Incorrect login';
$lang['auth_incorrect_email_or_username'] = 'Login or email doesn\'t exist';
$lang['auth_email_in_use'] = 'Email is already used by another user. Please choose another email.';
$lang['auth_username_in_use'] = 'Staff ID already exists.';
$lang['auth_current_email'] = 'This is your current email';
$lang['auth_incorrect_captcha'] = 'Your confirmation code does not match the one in the image.';
$lang['auth_captcha_expired'] = 'Your confirmation code has expired. Please try again.';

// Notifications
$lang['auth_message_logged_out'] = 'You have been successfully logged out.';
$lang['auth_message_registration_disabled'] = 'Registration is disabled.';
$lang['auth_message_registration_completed_1'] = 'You have successfully registered. Check your email address to activate your account.';
$lang['auth_message_registration_completed_2'] = 'You have successfully registered.';
$lang['auth_message_activation_email_sent'] = 'A new activation email has been sent to %s. Follow the instructions in the email to activate your account.';
$lang['auth_message_activation_completed'] = 'Your account has been successfully activated.';
$lang['auth_message_activation_failed'] = 'The activation code you entered is incorrect or expired.';
$lang['auth_message_password_changed'] = 'Your password has been successfully changed.';
$lang['auth_message_new_password_sent'] = 'An email with instructions for creating a new password has been sent to you.';
$lang['auth_message_new_password_activated'] = 'You have successfully reset your password';
$lang['auth_message_new_password_failed'] = 'Your activation key is incorrect or expired. Please check your email again and follow the instructions.';
$lang['auth_message_new_email_sent'] = 'A confirmation email has been sent to %s. Follow the instructions in the email to complete this change of email address.';
$lang['auth_message_new_email_activated'] = 'You have successfully changed your email';
$lang['auth_message_new_email_failed'] = 'Your activation key is incorrect or expired. Please check your email again and follow the instructions.';
$lang['auth_message_banned'] = 'You account has been disabled by the Administrator.';
$lang['auth_message_unregistered'] = 'Your account has been deleted...';

// Email subjects
$lang['auth_subject_welcome'] = 'Welcome to %s!';
$lang['auth_subject_activate'] = 'Welcome to %s!';
$lang['auth_subject_forgot_password'] = 'Forgot your password on %s?';
$lang['auth_subject_reset_password'] = 'Your new password on %s';
$lang['auth_subject_change_email'] = 'Your new email address on %s';

//location 
$lang['add_location'] = 'Record successfully added.';
$lang['edit_location'] = 'Record successfully updated.';
$lang['delete_location'] = 'Record has been successfully deleted.';
$lang['store_code_not_available'] = 'Store code already exists';

//authority level 
$lang['add_authority_level'] = 'Authority level successfully added.';
$lang['edit_authority_level'] = 'Authority level successfully updated.';
$lang['delete_authority_level'] = 'Authority level has been successfully deleted.';
$lang['auth_level_code_not_available'] = 'Authority level code already exists';

//designation
$lang['add_designation'] = 'Designation successfully added.';
$lang['edit_designation'] = 'Designation successfully updated.';
$lang['delete_designation'] = 'Designation has been successfully deleted.';


//date 

$lang['date_empty'] = 'Please select date.';
$lang['result_empty'] = 'No records found.';
$lang['no_col']= 'Please select at least one column.';

//customer
$lang['add_customer'] = 'Record successfully added.';
$lang['add_customer_err'] = 'Error inserting record.';

$lang['edit_customer'] = 'Record successfully updated.';
$lang['edit_customer_err'] = 'Error updating record.';
$lang['edit_customer_empty'] = 'No changes made';

$lang['customer_delete_success'] = 'Record has been archived successfully.';
$lang['customer_delete_failure'] = 'Unable to archive record.';
$lang['customer_restore_success'] = 'Record has been restored successfully.';
$lang['customer_restore_failure'] = 'Unable to restore record.';
//staff
$lang['new_staff_added']='Record successfully added.';
$lang["update_success"] = 'Record successfully updated.';
$lang["update_error"] = 'Error updating record.';
$lang["delete_success"] = 'Record has been successfully deleted.';
$lang["delete_error"] = 'Error deleting record.';
$lang["staff_delete_success"] = 'Staff member successfully deleted.';
$lang['insert_error'] = 'Error inserting record.';

$lang["settings_success"] = 'Record successfully updated.';
$lang["new_pass_created"] = "Your password has been successfully created. Please login.";
$lang["updated_already"] ="Your password has been updated already.";
$lang["staff_disable_success"]="Staff member successfully disabled.";
$lang["staff_enable_success"]="Staff member successfully enabled.";

$lang["supp_limit_reached"] = "Selected membership record already have 9 supplementary records associated with it.";


$lang['add_btr'] = 'Record successfully added.';
$lang['DOB_error_msg'] ='Can\'t update DOB as there is a Birthday Redemption for the current year.';
$lang['NIRC_error_msg'] ='Can\'t update NRIC Number as there is a Birthday Redemption for the current year.';

$lang['unique_voucher_redeemed'] = 'Please enter unique voucher number';
$lang['total_voucher_redeemed'] = 'Sum of voucher\'s not match with redeemed amount';
$lang['duplicate_reward_voucher'] = 'This voucher has already been used.';
$lang['reward_voucher_redeemed'] = 'Voucher has been successfully redeemed.';
$lang['reward_voucher_err'] = 'Error inserting record.';

$lang['duplicate_vouchers'] = 'One or more voucher has already been used ';

$lang['file_structure'] = 'File structure is not match.';
$lang['file_upload_success'] = 'File is successfully imported.';


//Redemption v2

$lang["invalid_form_values"] = 'Invalid form values';
$lang["invalid_coupon_values"] = 'Invalid Coupons Values: Total PDV value do not match.';

$lang["redemption_cancel_success"] = 'Record has been cancelled successfully.';
$lang['redemption_restore_success'] = 'Record has been restored successfully.';

$lang['redemption_cancel_failure'] = 'Unable to cancel record.';
$lang['redemption_restore_failure'] = 'Unable to restore record.';

/* End of file tank_auth_lang.php */
/* Location: ./application/language/english/tank_auth_lang.php */